import { motion } from "framer-motion";
import { CheckCircle2, Award, Users, MapPin } from "lucide-react";

const highlights = [
  {
    icon: Award,
    title: "15+ Years Experience",
    description: "Serving businesses in Chattogram with excellence since 2010",
  },
  {
    icon: Users,
    title: "50+ Corporate Clients",
    description: "Trusted by leading companies for transportation and trading",
  },
  {
    icon: MapPin,
    title: "Chattogram Based",
    description: "Local expertise with strong regional business connections",
  },
];

const values = [
  "Reliable and punctual bus transportation services",
  "Quality garments materials at competitive prices",
  "Transparent billing and payment systems",
  "Dedicated customer support and account management",
  "Modern fleet with GPS tracking capabilities",
  "Flexible contract terms tailored to your needs",
];

const About = () => {
  return (
    <section id="about" className="py-20 lg:py-32 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              About Us
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Your Trusted Enterprise Partner
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Allaha Mohan Enterprise has been a cornerstone of business services in Chattogram, Bangladesh. 
              We specialize in providing monthly corporate bus transportation and trading quality garments materials 
              including yarn, buttons, jhut, and fabric.
            </p>

            {/* Values List */}
            <div className="space-y-3 mb-8">
              {values.map((value, index) => (
                <motion.div
                  key={value}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.4 }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle2 className="w-5 h-5 text-success mt-0.5 flex-shrink-0" />
                  <span className="text-foreground">{value}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Content - Highlights */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            {highlights.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15, duration: 0.5 }}
                className="flex gap-5 p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-elegant"
              >
                <div className="w-14 h-14 gradient-primary rounded-xl flex items-center justify-center flex-shrink-0">
                  <item.icon className="w-7 h-7 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-display text-xl font-bold text-foreground mb-1">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}

            {/* Mission Statement */}
            <div className="p-6 rounded-2xl gradient-hero text-primary-foreground">
              <h4 className="font-display text-lg font-bold mb-2">Our Mission</h4>
              <p className="text-primary-foreground/80">
                To provide exceptional transportation and trading services that empower 
                businesses to operate efficiently while maintaining the highest standards 
                of reliability and customer satisfaction.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
