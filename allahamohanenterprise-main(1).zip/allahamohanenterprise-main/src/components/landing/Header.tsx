import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Bus, LogOut, User, Package, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import RoleBadge from "@/components/RoleBadge";
import { cn } from "@/lib/utils";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMobileServicesOpen, setIsMobileServicesOpen] = useState(false);
  const { user, role, signOut } = useAuth();
  const navigate = useNavigate();

  const services = [
    {
      name: "Bus Service",
      description: "Monthly corporate bus transportation with reliable pickup and drop services",
      icon: Bus,
      href: "/services#bus-service",
    },
    {
      name: "Garments Product Service",
      description: "Quality yarn, buttons, jhut, and fabric from garments factories",
      icon: Package,
      href: "/services#garments-service",
    },
  ];

  const handleServicesClick = () => {
    navigate("/services");
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className="relative w-10 h-10 md:w-12 md:h-12 gradient-primary rounded-xl flex items-center justify-center shadow-md">
              <Bus className="w-5 h-5 md:w-6 md:h-6 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="font-display text-lg md:text-xl font-bold text-foreground leading-tight">
                Allaha Mohan
              </span>
              <span className="text-xs text-muted-foreground tracking-wide">
                Enterprise
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <a
              href="/#home"
              className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors duration-200"
            >
              Home
            </a>
            
            {/* Services with Hover Dropdown */}
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <NavigationMenuTrigger 
                    className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors duration-200 bg-transparent hover:bg-transparent focus:bg-transparent data-[state=open]:bg-transparent h-auto p-0"
                    onClick={handleServicesClick}
                  >
                    Services
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[320px] gap-2 p-4 bg-card border border-border rounded-lg shadow-lg">
                      {services.map((service) => (
                        <li key={service.name}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={service.href}
                              className={cn(
                                "flex items-start gap-3 rounded-lg p-3 hover:bg-secondary transition-colors"
                              )}
                            >
                              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <service.icon className="w-5 h-5 text-primary" />
                              </div>
                              <div>
                                <div className="text-sm font-medium text-foreground">
                                  {service.name}
                                </div>
                                <p className="text-xs text-muted-foreground leading-snug mt-0.5">
                                  {service.description}
                                </p>
                              </div>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>

            <a
              href="/#about"
              className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors duration-200"
            >
              About
            </a>
            <a
              href="/#contact"
              className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors duration-200"
            >
              Contact
            </a>
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="default" size="sm" className="gap-2">
                    <User className="w-4 h-4" />
                    Dashboard
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48 bg-card border-border">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium text-foreground truncate">{user.email}</p>
                    {role && <RoleBadge role={role} size="sm" />}
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="cursor-pointer">
                      Go to Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => signOut()} className="text-destructive cursor-pointer">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link to="/auth">
                <Button variant="default" size="sm">
                  Login
                </Button>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-foreground"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass border-t border-border"
          >
            <div className="container mx-auto px-4 py-4">
              <nav className="flex flex-col gap-1">
                <a
                  href="/#home"
                  onClick={() => setIsMenuOpen(false)}
                  className="py-3 px-2 text-foreground hover:text-primary hover:bg-secondary/50 rounded-lg transition-colors"
                >
                  Home
                </a>
                
                {/* Mobile Services Dropdown */}
                <div>
                  <button
                    onClick={() => setIsMobileServicesOpen(!isMobileServicesOpen)}
                    className="w-full flex items-center justify-between py-3 px-2 text-foreground hover:text-primary hover:bg-secondary/50 rounded-lg transition-colors"
                  >
                    <span>Services</span>
                    <ChevronDown className={cn("w-4 h-4 transition-transform", isMobileServicesOpen && "rotate-180")} />
                  </button>
                  <AnimatePresence>
                    {isMobileServicesOpen && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="pl-4 py-2 space-y-1">
                          {services.map((service) => (
                            <Link
                              key={service.name}
                              to={service.href}
                              onClick={() => {
                                setIsMenuOpen(false);
                                setIsMobileServicesOpen(false);
                              }}
                              className="flex items-center gap-3 py-2 px-3 text-muted-foreground hover:text-primary hover:bg-secondary/50 rounded-lg transition-colors"
                            >
                              <service.icon className="w-4 h-4" />
                              <span className="text-sm">{service.name}</span>
                            </Link>
                          ))}
                          <Link
                            to="/services"
                            onClick={() => {
                              setIsMenuOpen(false);
                              setIsMobileServicesOpen(false);
                            }}
                            className="block py-2 px-3 text-sm text-primary font-medium hover:bg-secondary/50 rounded-lg transition-colors"
                          >
                            View All Services →
                          </Link>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <a
                  href="/#about"
                  onClick={() => setIsMenuOpen(false)}
                  className="py-3 px-2 text-foreground hover:text-primary hover:bg-secondary/50 rounded-lg transition-colors"
                >
                  About
                </a>
                <a
                  href="/#contact"
                  onClick={() => setIsMenuOpen(false)}
                  className="py-3 px-2 text-foreground hover:text-primary hover:bg-secondary/50 rounded-lg transition-colors"
                >
                  Contact
                </a>
                
                <div className="pt-3 mt-2 border-t border-border">
                  {user ? (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 px-2">
                        <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                        {role && <RoleBadge role={role} size="sm" />}
                      </div>
                      <Link to="/dashboard" className="block">
                        <Button className="w-full" onClick={() => setIsMenuOpen(false)}>
                          Dashboard
                        </Button>
                      </Link>
                      <Button 
                        variant="outline" 
                        className="w-full" 
                        onClick={() => {
                          signOut();
                          setIsMenuOpen(false);
                        }}
                      >
                        <LogOut className="w-4 h-4 mr-2" />
                        Logout
                      </Button>
                    </div>
                  ) : (
                    <Link to="/auth" className="block">
                      <Button className="w-full" onClick={() => setIsMenuOpen(false)}>
                        Login
                      </Button>
                    </Link>
                  )}
                </div>
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
