import { motion } from "framer-motion";
import { Bus, Package, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const services = [
  {
    icon: Bus,
    title: "Bus Transportation Service",
    description: "Reliable corporate bus services with 26-day monthly contracts. On-time pickup and drop for your employees with GPS tracking and professional drivers.",
    features: ["Daily Service", "Monthly Billing", "GPS Tracking", "Professional Drivers"],
    color: "primary",
    href: "/services#bus-service",
  },
  {
    icon: Package,
    title: "Garments Product Service",
    description: "Quality yarn, buttons, jhut, and fabric sourced directly from garments factories at competitive wholesale prices for the local market.",
    features: ["Yarn & Thread", "Buttons & Zippers", "Fabric & Jhut", "Wholesale Prices"],
    color: "accent",
    href: "/services#garments-service",
  },
];

const colorClasses = {
  primary: "gradient-primary",
  accent: "gradient-accent",
};

const Services = () => {
  return (
    <section id="services" className="py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            What We Offer
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Our Core Services
          </h2>
          <p className="text-lg text-muted-foreground">
            Two specialized business solutions tailored to meet your transportation and trading needs.
          </p>
        </motion.div>

        {/* Services Grid - Two Side by Side */}
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 max-w-5xl mx-auto">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
              className="group"
            >
              <div className="h-full p-8 lg:p-10 rounded-3xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-elegant">
                {/* Icon */}
                <div className={`w-16 h-16 rounded-2xl ${colorClasses[service.color as keyof typeof colorClasses]} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className="w-8 h-8 text-primary-foreground" />
                </div>

                {/* Content */}
                <h3 className="font-display text-xl lg:text-2xl font-bold text-foreground mb-4">
                  {service.title}
                </h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features */}
                <div className="flex flex-wrap gap-2 mb-8">
                  {service.features.map((feature) => (
                    <span
                      key={feature}
                      className="px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground text-xs font-medium"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                {/* CTA */}
                <Link to={service.href}>
                  <Button variant="outline" className="gap-2 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    Learn More
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View All Services Link */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center mt-12"
        >
          <Link to="/services">
            <Button size="lg" className="gap-2">
              View All Services
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
