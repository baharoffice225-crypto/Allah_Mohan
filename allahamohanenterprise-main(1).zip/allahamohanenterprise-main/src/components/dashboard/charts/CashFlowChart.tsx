import { motion } from "framer-motion";
import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const data = [
  { month: "Jul", inflow: 320000, outflow: 145000, balance: 175000 },
  { month: "Aug", inflow: 380000, outflow: 160000, balance: 395000 },
  { month: "Sep", inflow: 420000, outflow: 155000, balance: 660000 },
  { month: "Oct", inflow: 450000, outflow: 180000, balance: 930000 },
  { month: "Nov", inflow: 470000, outflow: 165000, balance: 1235000 },
  { month: "Dec", inflow: 485000, outflow: 175000, balance: 1545000 },
];

const formatBDT = (value: number) => {
  if (value >= 100000) {
    return `৳${(value / 100000).toFixed(1)}L`;
  }
  return `৳${(value / 1000).toFixed(0)}K`;
};

interface CashFlowChartProps {
  delay?: number;
}

const CashFlowChart = ({ delay = 0 }: CashFlowChartProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className="border-border">
        <CardHeader className="pb-2">
          <CardTitle className="font-display text-lg font-bold">
            Cash Flow Analysis
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Inflow, outflow & running balance
          </p>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={data}
                margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  yAxisId="left"
                  tickFormatter={formatBDT}
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tickFormatter={formatBDT}
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                  }}
                  formatter={(value: number, name: string) => [
                    `৳${value.toLocaleString()}`,
                    name === "inflow"
                      ? "Cash Inflow"
                      : name === "outflow"
                      ? "Cash Outflow"
                      : "Running Balance",
                  ]}
                />
                <Legend
                  formatter={(value) => (
                    <span className="text-sm text-foreground">
                      {value === "inflow"
                        ? "Cash Inflow"
                        : value === "outflow"
                        ? "Cash Outflow"
                        : "Running Balance"}
                    </span>
                  )}
                />
                <Bar
                  yAxisId="left"
                  dataKey="inflow"
                  fill="hsl(158, 64%, 40%)"
                  radius={[4, 4, 0, 0]}
                  name="inflow"
                />
                <Bar
                  yAxisId="left"
                  dataKey="outflow"
                  fill="hsl(0, 70%, 55%)"
                  radius={[4, 4, 0, 0]}
                  name="outflow"
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="balance"
                  stroke="hsl(175, 84%, 32%)"
                  strokeWidth={3}
                  dot={{ fill: "hsl(175, 84%, 32%)", strokeWidth: 2, r: 4 }}
                  name="balance"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CashFlowChart;
