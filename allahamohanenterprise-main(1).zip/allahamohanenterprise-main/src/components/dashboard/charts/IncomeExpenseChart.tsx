import { motion } from "framer-motion";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const data = [
  { month: "Jul", income: 320000, expense: 95000 },
  { month: "Aug", income: 380000, expense: 110000 },
  { month: "Sep", income: 420000, expense: 105000 },
  { month: "Oct", income: 450000, expense: 120000 },
  { month: "Nov", income: 470000, expense: 115000 },
  { month: "Dec", income: 485000, expense: 125000 },
];

const formatBDT = (value: number) => {
  if (value >= 100000) {
    return `৳${(value / 100000).toFixed(1)}L`;
  }
  return `৳${(value / 1000).toFixed(0)}K`;
};

interface IncomeExpenseChartProps {
  delay?: number;
}

const IncomeExpenseChart = ({ delay = 0 }: IncomeExpenseChartProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className="border-border">
        <CardHeader className="pb-2">
          <CardTitle className="font-display text-lg font-bold">
            Income vs Expense Trends
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Last 6 months comparison
          </p>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={data}
                margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(158, 64%, 40%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(158, 64%, 40%)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 12 }}
                  className="text-muted-foreground"
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={formatBDT}
                  tick={{ fontSize: 12 }}
                  className="text-muted-foreground"
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                  }}
                  formatter={(value: number, name: string) => [
                    `৳${value.toLocaleString()}`,
                    name === "income" ? "Income" : "Expense",
                  ]}
                />
                <Legend
                  formatter={(value) => (
                    <span className="text-sm capitalize text-foreground">{value}</span>
                  )}
                />
                <Area
                  type="monotone"
                  dataKey="income"
                  stroke="hsl(158, 64%, 40%)"
                  strokeWidth={2}
                  fill="url(#incomeGradient)"
                  name="income"
                />
                <Area
                  type="monotone"
                  dataKey="expense"
                  stroke="hsl(0, 84%, 60%)"
                  strokeWidth={2}
                  fill="url(#expenseGradient)"
                  name="expense"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default IncomeExpenseChart;
