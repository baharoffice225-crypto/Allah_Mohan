import { motion } from "framer-motion";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const data = [
  { month: "Jul", busService: 180000, trading: 140000, profit: 225000 },
  { month: "Aug", busService: 210000, trading: 170000, profit: 270000 },
  { month: "Sep", busService: 230000, trading: 190000, profit: 315000 },
  { month: "Oct", busService: 250000, trading: 200000, profit: 330000 },
  { month: "Nov", busService: 260000, trading: 210000, profit: 355000 },
  { month: "Dec", busService: 275000, trading: 210000, profit: 360000 },
];

const formatBDT = (value: number) => {
  if (value >= 100000) {
    return `৳${(value / 100000).toFixed(1)}L`;
  }
  return `৳${(value / 1000).toFixed(0)}K`;
};

interface MonthlyComparisonChartProps {
  delay?: number;
}

const MonthlyComparisonChart = ({ delay = 0 }: MonthlyComparisonChartProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className="border-border">
        <CardHeader className="pb-2">
          <CardTitle className="font-display text-lg font-bold">
            Monthly Revenue Comparison
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Revenue by business segment
          </p>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data}
                margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={formatBDT}
                  tick={{ fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                  }}
                  formatter={(value: number, name: string) => [
                    `৳${value.toLocaleString()}`,
                    name === "busService"
                      ? "Bus Service"
                      : name === "trading"
                      ? "Trading"
                      : "Net Profit",
                  ]}
                />
                <Legend
                  formatter={(value) => (
                    <span className="text-sm text-foreground">
                      {value === "busService"
                        ? "Bus Service"
                        : value === "trading"
                        ? "Trading"
                        : "Net Profit"}
                    </span>
                  )}
                />
                <Bar
                  dataKey="busService"
                  fill="hsl(175, 84%, 32%)"
                  radius={[4, 4, 0, 0]}
                  name="busService"
                />
                <Bar
                  dataKey="trading"
                  fill="hsl(38, 92%, 50%)"
                  radius={[4, 4, 0, 0]}
                  name="trading"
                />
                <Bar
                  dataKey="profit"
                  fill="hsl(205, 85%, 50%)"
                  radius={[4, 4, 0, 0]}
                  name="profit"
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default MonthlyComparisonChart;
