import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2 } from "lucide-react";

interface DriverPhotoProps {
  photoPath: string | null;
  name: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const sizeClasses = {
  sm: "w-10 h-10",
  md: "w-16 h-16",
  lg: "w-24 h-24",
};

const textSizeClasses = {
  sm: "text-sm",
  md: "text-lg",
  lg: "text-2xl",
};

export const DriverPhoto = ({ photoPath, name, size = "sm", className = "" }: DriverPhotoProps) => {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  useEffect(() => {
    const fetchSignedUrl = async () => {
      if (!photoPath) {
        setSignedUrl(null);
        return;
      }

      setIsLoading(true);
      try {
        // If it's already a full URL (legacy data), extract the path
        const path = photoPath.includes('driver-photos/') 
          ? photoPath.split('driver-photos/').pop() 
          : photoPath;
        
        if (!path) {
          setSignedUrl(null);
          return;
        }

        const { data, error } = await supabase.storage
          .from("driver-photos")
          .createSignedUrl(path, 3600); // 1 hour expiry

        if (error) {
          console.error("Signed URL error:", error);
          setSignedUrl(null);
        } else {
          setSignedUrl(data.signedUrl);
        }
      } catch (err) {
        console.error("Error fetching signed URL:", err);
        setSignedUrl(null);
      } finally {
        setIsLoading(false);
      }
    };

    fetchSignedUrl();
  }, [photoPath]);

  return (
    <Avatar className={`${sizeClasses[size]} ${className}`}>
      {isLoading ? (
        <AvatarFallback className="bg-primary/10">
          <Loader2 className="w-4 h-4 animate-spin text-primary" />
        </AvatarFallback>
      ) : (
        <>
          <AvatarImage src={signedUrl || undefined} />
          <AvatarFallback className={`bg-primary/10 text-primary ${textSizeClasses[size]}`}>
            {getInitials(name)}
          </AvatarFallback>
        </>
      )}
    </Avatar>
  );
};
