import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface FinancialCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  variant?: "income" | "expense" | "cash" | "dues" | "default";
  trend?: {
    value: string;
    type: "up" | "down" | "neutral";
  };
  delay?: number;
  onClick?: () => void;
}

const variantStyles = {
  income: {
    bg: "bg-success/10 dark:bg-success/20",
    icon: "bg-success text-success-foreground",
    border: "border-success/20",
  },
  expense: {
    bg: "bg-destructive/10 dark:bg-destructive/20",
    icon: "bg-destructive text-destructive-foreground",
    border: "border-destructive/20",
  },
  cash: {
    bg: "bg-info/10 dark:bg-info/20",
    icon: "bg-info text-info-foreground",
    border: "border-info/20",
  },
  dues: {
    bg: "bg-warning/10 dark:bg-warning/20",
    icon: "bg-warning text-warning-foreground",
    border: "border-warning/20",
  },
  default: {
    bg: "bg-primary/10 dark:bg-primary/20",
    icon: "gradient-primary text-primary-foreground",
    border: "border-primary/20",
  },
};

const FinancialCard = ({
  title,
  value,
  subtitle,
  icon: Icon,
  variant = "default",
  trend,
  delay = 0,
  onClick,
}: FinancialCardProps) => {
  const styles = variantStyles[variant];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      whileHover={{ scale: 1.02 }}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      onClick={onClick}
      className={cn(
        "p-5 rounded-xl border transition-all duration-300",
        "bg-card hover:shadow-elegant",
        styles.border,
        onClick && "cursor-pointer"
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-1">
            {title}
          </p>
          <h3 className="text-xl lg:text-2xl font-bold text-foreground truncate">
            {value}
          </h3>
          {subtitle && (
            <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
          )}
          {trend && (
            <div
              className={cn(
                "flex items-center gap-1 mt-2 text-xs font-medium",
                trend.type === "up" && "text-success",
                trend.type === "down" && "text-destructive",
                trend.type === "neutral" && "text-muted-foreground"
              )}
            >
              {trend.type === "up" && "↑"}
              {trend.type === "down" && "↓"}
              {trend.value}
            </div>
          )}
        </div>
        <div
          className={cn(
            "w-11 h-11 rounded-xl flex items-center justify-center shrink-0",
            styles.icon
          )}
        >
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </motion.div>
  );
};

export default FinancialCard;
