import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { ArrowUpCircle, ArrowDownCircle, ArrowUpRight, Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";

interface Transaction {
  id: string;
  type: string;
  quantity: number;
  previous_stock: number;
  new_stock: number;
  notes: string | null;
  created_at: string;
  user_id: string | null;
  inventory: {
    name: string;
    unit: string;
  } | null;
}

interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
}

interface RecentTransactionsWidgetProps {
  delay?: number;
}

const RecentTransactionsWidget = ({ delay = 0 }: RecentTransactionsWidgetProps) => {
  const navigate = useNavigate();

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["recent-inventory-transactions"],
    queryFn: async () => {
      const { data: transactionsData, error: transactionsError } = await supabase
        .from("inventory_transactions")
        .select(`
          id,
          type,
          quantity,
          previous_stock,
          new_stock,
          notes,
          created_at,
          user_id,
          inventory:inventory_id (name, unit)
        `)
        .order("created_at", { ascending: false })
        .limit(5);

      if (transactionsError) throw transactionsError;

      // Fetch profiles for user attribution
      const userIds = [...new Set(transactionsData?.filter(t => t.user_id).map(t => t.user_id) || [])];
      let profilesMap: Record<string, Profile> = {};
      
      if (userIds.length > 0) {
        const { data: profilesData } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", userIds);
        
        if (profilesData) {
          profilesMap = profilesData.reduce((acc, p) => ({ ...acc, [p.id]: p }), {});
        }
      }

      return (transactionsData || []).map(t => ({
        ...t,
        profile: t.user_id ? profilesMap[t.user_id] : null,
      }));
    },
  });

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInHours < 48) return "Yesterday";
    return format(date, "MMM d");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-card rounded-xl border border-border p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Package className="w-5 h-5 text-warning" />
          <h2 className="font-display text-lg font-bold text-foreground">
            Recent Inventory Transactions
          </h2>
        </div>
        <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/inventory")}>
          View All
          <ArrowUpRight className="w-4 h-4 ml-1" />
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center gap-4">
              <Skeleton className="w-10 h-10 rounded-lg" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : transactions.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p className="text-sm">No transactions yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {transactions.map((transaction, index) => (
            <motion.div
              key={transaction.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + 0.1 + index * 0.05 }}
              className="flex items-start gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors"
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                transaction.type === "in" 
                  ? "bg-success/20 text-success" 
                  : "bg-destructive/20 text-destructive"
              }`}>
                {transaction.type === "in" ? (
                  <ArrowUpCircle className="w-5 h-5" />
                ) : (
                  <ArrowDownCircle className="w-5 h-5" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {transaction.inventory?.name || "Unknown Item"}
                </p>
                <p className="text-xs text-muted-foreground">
                  <span className={transaction.type === "in" ? "text-success" : "text-destructive"}>
                    {transaction.type === "in" ? "+" : "-"}{transaction.quantity} {transaction.inventory?.unit || "pcs"}
                  </span>
                  {" • "}
                  {transaction.previous_stock} → {transaction.new_stock}
                  {transaction.notes && ` • ${transaction.notes}`}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {transaction.profile?.full_name || transaction.profile?.email || "System"} • {formatTimeAgo(transaction.created_at)}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
};

export default RecentTransactionsWidget;
