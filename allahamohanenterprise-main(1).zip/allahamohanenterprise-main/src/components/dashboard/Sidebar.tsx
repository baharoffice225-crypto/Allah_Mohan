import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Bus,
  Package,
  Users,
  Building2,
  FileText,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronDown,
  LogOut,
  Plus,
  List,
  UserCheck,
  Calendar,
  ClipboardList,
  Receipt,
  CreditCard,
  DollarSign,
  Lock,
  Activity,
  FolderOpen,
  Shirt,
  ShoppingCart,
  Warehouse,
  FileBarChart,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth, AppRole } from "@/contexts/AuthContext";
import { usePermissions, busServicePermissions, modulePermissions, garmentPermissions } from "@/hooks/usePermissions";
import RoleBadge from "@/components/RoleBadge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface SubItem {
  icon: typeof Plus;
  label: string;
  path: string;
  permissionKey: string;
}

const busServiceSubItems: SubItem[] = [
  { icon: Globe, label: "Website Products", path: "/dashboard/bus-services/products", permissionKey: "busCategories" },
  { icon: Plus, label: "Add Bus", path: "/dashboard/bus-services/add", permissionKey: "addBus" },
  { icon: List, label: "Bus List", path: "/dashboard/bus-services/list", permissionKey: "busList" },
  { icon: UserCheck, label: "Assign Bus", path: "/dashboard/bus-services/assign", permissionKey: "assignBus" },
  { icon: Calendar, label: "Daily Service Entry", path: "/dashboard/bus-services/daily-entry", permissionKey: "dailyEntry" },
  { icon: ClipboardList, label: "Monthly Summary", path: "/dashboard/bus-services/monthly-summary", permissionKey: "monthlySummary" },
  { icon: Receipt, label: "Billing & Invoice", path: "/dashboard/bus-services/billing", permissionKey: "billing" },
  { icon: CreditCard, label: "Payment Status", path: "/dashboard/bus-services/payment-status", permissionKey: "paymentStatus" },
  { icon: FolderOpen, label: "Bus Categories", path: "/dashboard/bus-services/categories", permissionKey: "busCategories" },
  { icon: Users, label: "Driver List", path: "/dashboard/bus-services/drivers", permissionKey: "driverList" },
];

const garmentSubItems: SubItem[] = [
  { icon: Globe, label: "Website Products", path: "/dashboard/garments/website-products", permissionKey: "garmentCategories" },
  { icon: FolderOpen, label: "Product Categories", path: "/dashboard/garments/categories", permissionKey: "garmentCategories" },
  { icon: List, label: "Product List", path: "/dashboard/garments/products", permissionKey: "garmentProducts" },
  { icon: ShoppingCart, label: "Purchase Management", path: "/dashboard/garments/purchases", permissionKey: "garmentPurchases" },
  { icon: Warehouse, label: "Stock Management", path: "/dashboard/garments/stock", permissionKey: "garmentStock" },
  { icon: DollarSign, label: "Sales Management", path: "/dashboard/garments/sales", permissionKey: "garmentSales" },
  { icon: Receipt, label: "Invoice & Billing", path: "/dashboard/garments/invoices", permissionKey: "garmentInvoices" },
  { icon: FileBarChart, label: "Reports", path: "/dashboard/garments/reports", permissionKey: "garmentReports" },
];

interface MenuItem {
  icon: typeof LayoutDashboard;
  label: string;
  path: string;
  permissionKey: string;
  hasSubmenu?: boolean;
  subItems?: SubItem[];
}

import { Globe } from "lucide-react";

const websiteSubItems: SubItem[] = [
  { icon: Settings, label: "General Settings", path: "/dashboard/website/settings", permissionKey: "websiteSettings" },
  { icon: FileText, label: "Pages", path: "/dashboard/website/pages", permissionKey: "websitePages" },
  { icon: FolderOpen, label: "Sliders", path: "/dashboard/website/sliders", permissionKey: "websiteSliders" },
  { icon: LayoutDashboard, label: "Sections", path: "/dashboard/website/sections", permissionKey: "websiteSections" },
  { icon: BarChart3, label: "SEO Settings", path: "/dashboard/website/seo", permissionKey: "websiteSEO" },
];

const menuItems: MenuItem[] = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard", permissionKey: "dashboard" },
  { icon: Bus, label: "Bus Services", path: "/dashboard/bus-services", permissionKey: "busServices", hasSubmenu: true, subItems: busServiceSubItems },
  { icon: Shirt, label: "Garments Products", path: "/dashboard/garments", permissionKey: "garments", hasSubmenu: true, subItems: garmentSubItems },
  { icon: Building2, label: "Clients", path: "/dashboard/clients", permissionKey: "clients" },
  { icon: Package, label: "Inventory", path: "/dashboard/inventory", permissionKey: "inventory" },
  { icon: DollarSign, label: "Sales & Billing", path: "/dashboard/sales", permissionKey: "sales" },
  { icon: Users, label: "User Management", path: "/dashboard/user-management", permissionKey: "userManagement" },
  { icon: Activity, label: "Audit Logs", path: "/dashboard/audit-logs", permissionKey: "userManagement" },
  { icon: FileText, label: "Invoices", path: "/dashboard/invoices", permissionKey: "invoices" },
  { icon: BarChart3, label: "Reports", path: "/dashboard/reports", permissionKey: "reports" },
  { icon: Globe, label: "Website", path: "/dashboard/website", permissionKey: "website", hasSubmenu: true, subItems: websiteSubItems },
  { icon: Settings, label: "Settings", path: "/dashboard/settings", permissionKey: "settings" },
];

interface SidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (value: boolean) => void;
}

const Sidebar = ({ isCollapsed, setIsCollapsed }: SidebarProps) => {
  const location = useLocation();
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);
  const { role, signOut, user } = useAuth();
  const { canAccessModule, canAccessBusSubModule, canAccessGarmentSubModule } = usePermissions(role);

  const isPathActive = (path: string) => location.pathname === path;
  const isParentActive = (path: string) => location.pathname.startsWith(path);

  const toggleSubmenu = (path: string) => {
    setExpandedMenus((prev) =>
      prev.includes(path) ? prev.filter((p) => p !== path) : [...prev, path]
    );
  };

  const isMenuExpanded = (path: string) => {
    return expandedMenus.includes(path) || isParentActive(path);
  };

  const handleSignOut = async () => {
    await signOut();
  };

  // Filter menu items based on permissions
  const visibleMenuItems = menuItems.filter((item) => canAccessModule(item.permissionKey));

  return (
    <>
      {/* Desktop Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: isCollapsed ? 80 : 280 }}
        className="hidden lg:flex flex-col fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border z-40"
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-sidebar-border">
          <AnimatePresence mode="wait">
            {!isCollapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-3"
              >
                <div className="w-9 h-9 gradient-primary rounded-lg flex items-center justify-center">
                  <Bus className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="font-display font-bold text-sidebar-foreground text-sm">
                  Allaha Mohan
                </span>
              </motion.div>
            )}
          </AnimatePresence>
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-2 rounded-lg hover:bg-sidebar-accent text-sidebar-foreground transition-colors"
          >
            <ChevronLeft
              className={cn(
                "w-5 h-5 transition-transform duration-300",
                isCollapsed && "rotate-180"
              )}
            />
          </button>
        </div>

        {/* User Info */}
        {!isCollapsed && (
          <div className="px-4 py-3 border-b border-sidebar-border">
            <div className="flex items-center justify-between">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-sidebar-foreground truncate">
                  {user?.email}
                </p>
              </div>
              <RoleBadge role={role} size="sm" />
            </div>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          <ul className="space-y-1">
            {visibleMenuItems.map((item) => {
              const isActive = item.hasSubmenu
                ? isParentActive(item.path)
                : isPathActive(item.path);
              const isExpanded = item.hasSubmenu && isMenuExpanded(item.path);

              // Filter sub-items based on permissions
              const visibleSubItems = item.subItems?.filter((subItem) => {
                if (item.permissionKey === "garments") {
                  return canAccessGarmentSubModule(subItem.permissionKey);
                }
                return canAccessBusSubModule(subItem.permissionKey);
              });

              return (
                <li key={item.path}>
                  {item.hasSubmenu ? (
                    <>
                      <button
                        onClick={() => toggleSubmenu(item.path)}
                        className={cn(
                          "w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                          isActive
                            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md"
                            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <item.icon className="w-5 h-5 flex-shrink-0" />
                          <AnimatePresence mode="wait">
                            {!isCollapsed && (
                              <motion.span
                                initial={{ opacity: 0, width: 0 }}
                                animate={{ opacity: 1, width: "auto" }}
                                exit={{ opacity: 0, width: 0 }}
                                className="text-sm font-medium whitespace-nowrap"
                              >
                                {item.label}
                              </motion.span>
                            )}
                          </AnimatePresence>
                        </div>
                        {!isCollapsed && (
                          <ChevronDown
                            className={cn(
                              "w-4 h-4 transition-transform duration-200",
                              isExpanded && "rotate-180"
                            )}
                          />
                        )}
                      </button>
                      <AnimatePresence>
                        {isExpanded && !isCollapsed && (
                          <motion.ul
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden ml-4 mt-1 space-y-1 border-l-2 border-sidebar-border pl-3"
                          >
                            {visibleSubItems?.map((subItem) => {
                              const isSubActive = isPathActive(subItem.path);
                              return (
                                <li key={subItem.path}>
                                  <Link
                                    to={subItem.path}
                                    className={cn(
                                      "flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 text-sm",
                                      isSubActive
                                        ? "bg-sidebar-accent text-sidebar-primary font-medium"
                                        : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                                    )}
                                  >
                                    <subItem.icon className="w-4 h-4 flex-shrink-0" />
                                    <span className="whitespace-nowrap">{subItem.label}</span>
                                  </Link>
                                </li>
                              );
                            })}
                          </motion.ul>
                        )}
                      </AnimatePresence>
                    </>
                  ) : (
                    <Link
                      to={item.path}
                      className={cn(
                        "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                        isActive
                          ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md"
                          : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      )}
                    >
                      <item.icon className="w-5 h-5 flex-shrink-0" />
                      <AnimatePresence mode="wait">
                        {!isCollapsed && (
                          <motion.span
                            initial={{ opacity: 0, width: 0 }}
                            animate={{ opacity: 1, width: "auto" }}
                            exit={{ opacity: 0, width: 0 }}
                            className="text-sm font-medium whitespace-nowrap"
                          >
                            {item.label}
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </Link>
                  )}
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Bottom - Empty now, actions moved to header */}
        <div className="p-3 border-t border-sidebar-border">
          {!isCollapsed && (
            <p className="text-xs text-sidebar-foreground/50 text-center">
              © 2024 Allaha Mohan
            </p>
          )}
        </div>
      </motion.aside>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-sidebar border-t border-sidebar-border z-40">
        <div className="flex justify-around py-2">
          {visibleMenuItems.slice(0, 5).map((item) => {
            const isActive = item.hasSubmenu
              ? isParentActive(item.path)
              : isPathActive(item.path);
            return (
              <Link
                key={item.path}
                to={item.hasSubmenu ? item.subItems![0].path : item.path}
                className={cn(
                  "flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors",
                  isActive ? "text-sidebar-primary" : "text-sidebar-foreground"
                )}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-xs">{item.label.split(" ")[0]}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
};

export default Sidebar;
