import { Badge } from "@/components/ui/badge";
import { AppRole } from "@/contexts/AuthContext";
import { Shield, ShieldCheck, User, Crown } from "lucide-react";
import { cn } from "@/lib/utils";

interface RoleBadgeProps {
  role: AppRole | null;
  showIcon?: boolean;
  size?: "sm" | "md" | "lg";
}

const roleConfig: Record<AppRole, { label: string; icon: typeof Shield; className: string }> = {
  super_admin: {
    label: "Super Admin",
    icon: Crown,
    className: "bg-purple-500/10 text-purple-600 border-purple-500/20 hover:bg-purple-500/20",
  },
  admin: {
    label: "Admin",
    icon: ShieldCheck,
    className: "bg-red-500/10 text-red-600 border-red-500/20 hover:bg-red-500/20",
  },
  manager: {
    label: "Manager",
    icon: Shield,
    className: "bg-blue-500/10 text-blue-600 border-blue-500/20 hover:bg-blue-500/20",
  },
  staff: {
    label: "Staff",
    icon: User,
    className: "bg-green-500/10 text-green-600 border-green-500/20 hover:bg-green-500/20",
  },
};

const RoleBadge = ({ role, showIcon = true, size = "md" }: RoleBadgeProps) => {
  if (!role) return null;

  const config = roleConfig[role];
  const Icon = config.icon;

  const sizeClasses = {
    sm: "text-xs px-2 py-0.5",
    md: "text-sm px-2.5 py-1",
    lg: "text-base px-3 py-1.5",
  };

  return (
    <Badge
      variant="outline"
      className={cn(
        "font-medium border",
        config.className,
        sizeClasses[size]
      )}
    >
      {showIcon && <Icon className={cn("mr-1", size === "sm" ? "w-3 h-3" : "w-4 h-4")} />}
      {config.label}
    </Badge>
  );
};

export default RoleBadge;
