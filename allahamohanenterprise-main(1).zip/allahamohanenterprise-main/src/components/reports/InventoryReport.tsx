import { useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Printer, X, Package, ArrowUpCircle, ArrowDownCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";

interface InventoryReportProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface InventoryItem {
  id: string;
  name: string;
  sku: string | null;
  category: string;
  stock: number;
  min_stock: number;
  unit: string;
  price: number;
}

interface Transaction {
  id: string;
  type: string;
  quantity: number;
  previous_stock: number;
  new_stock: number;
  notes: string | null;
  created_at: string;
  inventory_id: string;
}

const InventoryReport = ({ open, onOpenChange }: InventoryReportProps) => {
  const printRef = useRef<HTMLDivElement>(null);

  const { data: inventory = [], isLoading: loadingInventory } = useQuery({
    queryKey: ["inventory-report"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("inventory")
        .select("*")
        .order("category", { ascending: true })
        .order("name", { ascending: true });
      if (error) throw error;
      return data as InventoryItem[];
    },
    enabled: open,
  });

  const { data: transactions = [], isLoading: loadingTransactions } = useQuery({
    queryKey: ["inventory-transactions-report"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("inventory_transactions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data as Transaction[];
    },
    enabled: open,
  });

  const handlePrint = () => {
    const printContent = printRef.current;
    if (!printContent) return;

    const printWindow = window.open("", "_blank");
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Inventory Report - ${format(new Date(), "MMMM d, yyyy")}</title>
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
              padding: 20px;
              color: #1a1a1a;
            }
            .header { 
              text-align: center; 
              margin-bottom: 30px; 
              padding-bottom: 20px;
              border-bottom: 2px solid #e5e5e5;
            }
            .header h1 { font-size: 24px; margin-bottom: 5px; }
            .header p { color: #666; font-size: 14px; }
            .section { margin-bottom: 30px; }
            .section-title { 
              font-size: 18px; 
              font-weight: 600; 
              margin-bottom: 15px;
              color: #333;
            }
            table { 
              width: 100%; 
              border-collapse: collapse; 
              font-size: 12px;
            }
            th, td { 
              padding: 10px 8px; 
              text-align: left; 
              border-bottom: 1px solid #e5e5e5;
            }
            th { 
              background: #f5f5f5; 
              font-weight: 600;
              color: #333;
            }
            .text-right { text-align: right; }
            .text-center { text-align: center; }
            .low-stock { color: #dc2626; font-weight: 600; }
            .stock-in { color: #16a34a; }
            .stock-out { color: #dc2626; }
            .summary { 
              display: flex; 
              gap: 20px; 
              margin-bottom: 20px;
              flex-wrap: wrap;
            }
            .summary-card {
              padding: 15px;
              background: #f9fafb;
              border-radius: 8px;
              min-width: 150px;
            }
            .summary-card .label { font-size: 12px; color: #666; }
            .summary-card .value { font-size: 20px; font-weight: 600; }
            .footer {
              margin-top: 40px;
              padding-top: 20px;
              border-top: 1px solid #e5e5e5;
              font-size: 11px;
              color: #666;
              text-align: center;
            }
            @media print {
              body { padding: 0; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);
  };

  const formatBDT = (amount: number) => {
    return new Intl.NumberFormat("en-BD", {
      style: "currency",
      currency: "BDT",
      minimumFractionDigits: 0,
    }).format(amount).replace("BDT", "৳");
  };

  const stats = {
    total: inventory.length,
    lowStock: inventory.filter((i) => i.stock < i.min_stock).length,
    totalValue: inventory.reduce((sum, i) => sum + i.stock * i.price, 0),
    categories: [...new Set(inventory.map((i) => i.category))].length,
  };

  const inventoryByName: Record<string, string> = inventory.reduce(
    (acc, item) => ({ ...acc, [item.id]: item.name }),
    {}
  );

  const isLoading = loadingInventory || loadingTransactions;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              Inventory Report
            </span>
            <Button onClick={handlePrint} disabled={isLoading} className="gap-2">
              <Printer className="w-4 h-4" />
              Print Report
            </Button>
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="space-y-4 p-4">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-48 w-full" />
          </div>
        ) : (
          <div ref={printRef} className="p-4">
            {/* Header */}
            <div className="header">
              <h1>Inventory Report</h1>
              <p>Generated on {format(new Date(), "MMMM d, yyyy 'at' h:mm a")}</p>
            </div>

            {/* Summary */}
            <div className="section">
              <div className="summary">
                <div className="summary-card">
                  <div className="label">Total Items</div>
                  <div className="value">{stats.total}</div>
                </div>
                <div className="summary-card">
                  <div className="label">Categories</div>
                  <div className="value">{stats.categories}</div>
                </div>
                <div className="summary-card">
                  <div className="label">Low Stock Items</div>
                  <div className="value" style={{ color: stats.lowStock > 0 ? "#dc2626" : "inherit" }}>
                    {stats.lowStock}
                  </div>
                </div>
                <div className="summary-card">
                  <div className="label">Total Value</div>
                  <div className="value">{formatBDT(stats.totalValue)}</div>
                </div>
              </div>
            </div>

            {/* Stock Levels */}
            <div className="section">
              <h2 className="section-title">Current Stock Levels</h2>
              <table>
                <thead>
                  <tr>
                    <th>Item Name</th>
                    <th>SKU</th>
                    <th>Category</th>
                    <th className="text-right">Stock</th>
                    <th className="text-right">Min Stock</th>
                    <th className="text-right">Unit Price</th>
                    <th className="text-right">Value</th>
                  </tr>
                </thead>
                <tbody>
                  {inventory.map((item) => (
                    <tr key={item.id}>
                      <td>{item.name}</td>
                      <td>{item.sku || "-"}</td>
                      <td>{item.category}</td>
                      <td className={`text-right ${item.stock < item.min_stock ? "low-stock" : ""}`}>
                        {item.stock} {item.unit}
                      </td>
                      <td className="text-right">{item.min_stock} {item.unit}</td>
                      <td className="text-right">{formatBDT(item.price)}</td>
                      <td className="text-right">{formatBDT(item.stock * item.price)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Recent Transactions */}
            <div className="section">
              <h2 className="section-title">Recent Transactions (Last 50)</h2>
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Item</th>
                    <th className="text-center">Type</th>
                    <th className="text-right">Qty</th>
                    <th className="text-right">Previous</th>
                    <th className="text-right">New</th>
                    <th>Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx) => (
                    <tr key={tx.id}>
                      <td>{format(new Date(tx.created_at), "MMM d, yyyy h:mm a")}</td>
                      <td>{inventoryByName[tx.inventory_id] || "Unknown"}</td>
                      <td className={`text-center ${tx.type === "in" ? "stock-in" : "stock-out"}`}>
                        {tx.type === "in" ? "IN" : "OUT"}
                      </td>
                      <td className="text-right">{tx.quantity}</td>
                      <td className="text-right">{tx.previous_stock}</td>
                      <td className="text-right">{tx.new_stock}</td>
                      <td>{tx.notes || "-"}</td>
                    </tr>
                  ))}
                  {transactions.length === 0 && (
                    <tr>
                      <td colSpan={7} className="text-center" style={{ padding: "20px", color: "#666" }}>
                        No transactions recorded
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Footer */}
            <div className="footer">
              <p>This report was automatically generated. For questions, contact your system administrator.</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default InventoryReport;
