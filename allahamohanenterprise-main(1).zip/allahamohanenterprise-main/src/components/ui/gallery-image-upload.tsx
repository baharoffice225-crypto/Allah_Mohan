import { useRef } from "react";
import { Upload, X, Loader2, ImageIcon, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface GalleryImageUploadProps {
  value: string[];
  onChange: (urls: string[]) => void;
  onUpload: (file: File) => Promise<string | null>;
  onDelete?: (url: string) => Promise<boolean>;
  isUploading?: boolean;
  progress?: number;
  maxImages?: number;
  placeholder?: string;
  className?: string;
}

export const GalleryImageUpload = ({
  value = [],
  onChange,
  onUpload,
  onDelete,
  isUploading = false,
  progress = 0,
  maxImages = 10,
  placeholder = "Add Images",
  className = "",
}: GalleryImageUploadProps) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // Process files one by one
    for (const file of Array.from(files)) {
      if (value.length >= maxImages) break;
      
      const url = await onUpload(file);
      if (url) {
        onChange([...value, url]);
      }
    }

    // Reset input
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  const handleRemove = async (urlToRemove: string) => {
    if (onDelete) {
      const success = await onDelete(urlToRemove);
      if (success) {
        onChange(value.filter(url => url !== urlToRemove));
      }
    } else {
      onChange(value.filter(url => url !== urlToRemove));
    }
  };

  return (
    <div className={`space-y-3 ${className}`}>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileSelect}
        className="hidden"
        disabled={isUploading || value.length >= maxImages}
      />

      {/* Existing images grid */}
      {value.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
          {value.map((url, index) => (
            <div key={index} className="relative group aspect-square">
              <div className="w-full h-full rounded-lg overflow-hidden border border-border bg-muted">
                <img
                  src={url}
                  alt={`Gallery ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
              <button
                type="button"
                onClick={() => handleRemove(url)}
                disabled={isUploading}
                className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md hover:bg-destructive/90"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Upload button */}
      {value.length < maxImages && (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={isUploading}
          className="w-full py-4 rounded-lg border-2 border-dashed border-border hover:border-primary/50 transition-colors bg-muted/50 flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isUploading ? (
            <>
              <Loader2 className="w-5 h-5 text-muted-foreground animate-spin" />
              <span className="text-sm text-muted-foreground">Uploading...</span>
              <Progress value={progress} className="w-24 h-1" />
            </>
          ) : (
            <>
              <Plus className="w-5 h-5 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {placeholder} ({value.length}/{maxImages})
              </span>
            </>
          )}
        </button>
      )}

      {value.length >= maxImages && (
        <p className="text-xs text-muted-foreground text-center">
          Maximum {maxImages} images allowed
        </p>
      )}
    </div>
  );
};
