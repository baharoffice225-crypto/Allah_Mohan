import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Loader2, Plus, Edit, Trash2, FileText, Eye, EyeOff } from "lucide-react";

interface PageData {
  id: string;
  page_slug: string;
  page_title: string;
  page_description: string | null;
  is_visible: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

const WebsitePages = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [pages, setPages] = useState<PageData[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPage, setEditingPage] = useState<PageData | null>(null);
  const [formData, setFormData] = useState({
    page_slug: "",
    page_title: "",
    page_description: "",
    is_visible: true,
    display_order: 0,
  });

  useEffect(() => {
    fetchPages();
  }, []);

  const fetchPages = async () => {
    try {
      const { data, error } = await supabase
        .from("website_pages")
        .select("*")
        .order("display_order", { ascending: true });

      if (error) throw error;
      setPages(data as PageData[]);
    } catch (error: any) {
      console.error("Error fetching pages:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      if (editingPage) {
        const { error } = await supabase
          .from("website_pages")
          .update({
            page_slug: formData.page_slug,
            page_title: formData.page_title,
            page_description: formData.page_description,
            is_visible: formData.is_visible,
            display_order: formData.display_order,
          })
          .eq("id", editingPage.id);

        if (error) throw error;
        toast({ title: "Page Updated", description: "Page has been updated successfully." });
      } else {
        const { error } = await supabase.from("website_pages").insert({
          page_slug: formData.page_slug,
          page_title: formData.page_title,
          page_description: formData.page_description,
          is_visible: formData.is_visible,
          display_order: formData.display_order,
        });

        if (error) throw error;
        toast({ title: "Page Created", description: "New page has been created successfully." });
      }

      setIsDialogOpen(false);
      resetForm();
      fetchPages();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save page.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this page?")) return;

    try {
      const { error } = await supabase.from("website_pages").delete().eq("id", id);
      if (error) throw error;
      toast({ title: "Page Deleted", description: "Page has been deleted successfully." });
      fetchPages();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete page.",
        variant: "destructive",
      });
    }
  };

  const toggleVisibility = async (page: PageData) => {
    try {
      const { error } = await supabase
        .from("website_pages")
        .update({ is_visible: !page.is_visible })
        .eq("id", page.id);

      if (error) throw error;
      fetchPages();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update visibility.",
        variant: "destructive",
      });
    }
  };

  const openEditDialog = (page: PageData) => {
    setEditingPage(page);
    setFormData({
      page_slug: page.page_slug,
      page_title: page.page_title,
      page_description: page.page_description || "",
      is_visible: page.is_visible,
      display_order: page.display_order,
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingPage(null);
    setFormData({
      page_slug: "",
      page_title: "",
      page_description: "",
      is_visible: true,
      display_order: 0,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Website Pages</h1>
          <p className="text-muted-foreground">Manage your website's pages</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Add Page
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingPage ? "Edit Page" : "Add New Page"}</DialogTitle>
              <DialogDescription>
                {editingPage ? "Update page details" : "Create a new website page"}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="pageTitle">Page Title</Label>
                <Input
                  id="pageTitle"
                  value={formData.page_title}
                  onChange={(e) => setFormData({ ...formData, page_title: e.target.value })}
                  placeholder="About Us"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pageSlug">Page Slug</Label>
                <Input
                  id="pageSlug"
                  value={formData.page_slug}
                  onChange={(e) => setFormData({ ...formData, page_slug: e.target.value })}
                  placeholder="about-us"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pageDescription">Description</Label>
                <Textarea
                  id="pageDescription"
                  value={formData.page_description}
                  onChange={(e) => setFormData({ ...formData, page_description: e.target.value })}
                  placeholder="Brief description of the page"
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="displayOrder">Display Order</Label>
                <Input
                  id="displayOrder"
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                />
              </div>
              <div className="flex items-center gap-3">
                <Switch
                  checked={formData.is_visible}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_visible: checked })}
                />
                <Label>Visible on website</Label>
              </div>
              <Button onClick={handleSubmit} className="w-full">
                {editingPage ? "Update Page" : "Create Page"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Pages</CardTitle>
          <CardDescription>Click on a page to edit its content</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Page</TableHead>
                <TableHead>Slug</TableHead>
                <TableHead>Order</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pages.map((page) => (
                <TableRow key={page.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <FileText className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{page.page_title}</p>
                        {page.page_description && (
                          <p className="text-xs text-muted-foreground line-clamp-1">
                            {page.page_description}
                          </p>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <code className="text-xs bg-secondary px-2 py-1 rounded">
                      /{page.page_slug}
                    </code>
                  </TableCell>
                  <TableCell>{page.display_order}</TableCell>
                  <TableCell>
                    <Badge variant={page.is_visible ? "default" : "secondary"}>
                      {page.is_visible ? "Visible" : "Hidden"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggleVisibility(page)}
                      >
                        {page.is_visible ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(page)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(page.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default WebsitePages;
