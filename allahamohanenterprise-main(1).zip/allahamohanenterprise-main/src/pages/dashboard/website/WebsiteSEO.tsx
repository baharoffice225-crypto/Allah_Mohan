import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Save, Search, Globe, Tag, FileText } from "lucide-react";

interface SEOSettings {
  id: string;
  meta_title: string | null;
  meta_description: string | null;
  meta_keywords: string | null;
}

const WebsiteSEO = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<SEOSettings | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from("website_settings")
        .select("id, meta_title, meta_description, meta_keywords")
        .limit(1)
        .single();

      if (error && error.code !== "PGRST116") throw error;
      setSettings(data as SEOSettings);
    } catch (error: any) {
      console.error("Error fetching SEO settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!settings) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from("website_settings")
        .update({
          meta_title: settings.meta_title,
          meta_description: settings.meta_description,
          meta_keywords: settings.meta_keywords,
        })
        .eq("id", settings.id);

      if (error) throw error;

      toast({
        title: "SEO Settings Saved",
        description: "Your SEO settings have been updated successfully.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save SEO settings.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const titleLength = settings?.meta_title?.length || 0;
  const descriptionLength = settings?.meta_description?.length || 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">SEO Settings</h1>
          <p className="text-muted-foreground">
            Optimize your website for search engines
          </p>
        </div>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Save Changes
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* SEO Form */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Meta Tags
              </CardTitle>
              <CardDescription>
                These tags help search engines understand your website
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="metaTitle">Meta Title</Label>
                  <span className={`text-xs ${titleLength > 60 ? "text-destructive" : "text-muted-foreground"}`}>
                    {titleLength}/60 characters
                  </span>
                </div>
                <Input
                  id="metaTitle"
                  value={settings?.meta_title || ""}
                  onChange={(e) => setSettings(settings ? { ...settings, meta_title: e.target.value } : null)}
                  placeholder="Business Portal - Bus & Garments Services"
                  maxLength={60}
                />
                <p className="text-xs text-muted-foreground">
                  Appears as the clickable headline in search results
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="metaDescription">Meta Description</Label>
                  <span className={`text-xs ${descriptionLength > 160 ? "text-destructive" : "text-muted-foreground"}`}>
                    {descriptionLength}/160 characters
                  </span>
                </div>
                <Textarea
                  id="metaDescription"
                  value={settings?.meta_description || ""}
                  onChange={(e) => setSettings(settings ? { ...settings, meta_description: e.target.value } : null)}
                  placeholder="Professional bus transportation and garments product services. Reliable monthly contracts and quality materials at competitive prices."
                  rows={3}
                  maxLength={160}
                />
                <p className="text-xs text-muted-foreground">
                  Brief summary shown below the title in search results
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="metaKeywords">Meta Keywords</Label>
                <Textarea
                  id="metaKeywords"
                  value={settings?.meta_keywords || ""}
                  onChange={(e) => setSettings(settings ? { ...settings, meta_keywords: e.target.value } : null)}
                  placeholder="bus service, garments, transportation, corporate bus, yarn, buttons, fabric, Bangladesh"
                  rows={2}
                />
                <p className="text-xs text-muted-foreground">
                  Comma-separated keywords related to your business
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Preview */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Search Preview
              </CardTitle>
              <CardDescription>
                How your website might appear in Google search results
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-4 rounded-lg border border-border bg-card">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">
                    www.yourwebsite.com
                  </p>
                  <h3 className="text-lg font-medium text-primary hover:underline cursor-pointer">
                    {settings?.meta_title || "Your Website Title"}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {settings?.meta_description || "Add a meta description to see how it will appear in search results. A good description is 120-160 characters."}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Tag className="w-5 h-5" />
                Keywords
              </CardTitle>
              <CardDescription>
                Your target keywords for SEO
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {settings?.meta_keywords?.split(",").map((keyword, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 rounded-full bg-primary/10 text-primary text-sm"
                  >
                    {keyword.trim()}
                  </span>
                ))}
                {!settings?.meta_keywords && (
                  <p className="text-sm text-muted-foreground">
                    No keywords added yet
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                SEO Tips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Keep your title under 60 characters for best display
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Meta description should be 120-160 characters
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Include your main keyword in both title and description
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Use natural language that encourages clicks
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Focus on 5-10 relevant keywords for your business
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default WebsiteSEO;
