import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Loader2, Plus, Edit, Trash2, Image, Eye, EyeOff, GripVertical } from "lucide-react";

interface SliderData {
  id: string;
  title: string | null;
  subtitle: string | null;
  description: string | null;
  image_url: string | null;
  cta_text: string | null;
  cta_link: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
}

const WebsiteSliders = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [sliders, setSliders] = useState<SliderData[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSlider, setEditingSlider] = useState<SliderData | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    subtitle: "",
    description: "",
    image_url: "",
    cta_text: "",
    cta_link: "",
    display_order: 0,
    is_active: true,
  });

  useEffect(() => {
    fetchSliders();
  }, []);

  const fetchSliders = async () => {
    try {
      const { data, error } = await supabase
        .from("website_sliders")
        .select("*")
        .order("display_order", { ascending: true });

      if (error) throw error;
      setSliders(data as SliderData[]);
    } catch (error: any) {
      console.error("Error fetching sliders:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      if (editingSlider) {
        const { error } = await supabase
          .from("website_sliders")
          .update({
            title: formData.title,
            subtitle: formData.subtitle,
            description: formData.description,
            image_url: formData.image_url,
            cta_text: formData.cta_text,
            cta_link: formData.cta_link,
            display_order: formData.display_order,
            is_active: formData.is_active,
          })
          .eq("id", editingSlider.id);

        if (error) throw error;
        toast({ title: "Slider Updated", description: "Slider has been updated successfully." });
      } else {
        const { error } = await supabase.from("website_sliders").insert({
          title: formData.title,
          subtitle: formData.subtitle,
          description: formData.description,
          image_url: formData.image_url,
          cta_text: formData.cta_text,
          cta_link: formData.cta_link,
          display_order: formData.display_order,
          is_active: formData.is_active,
        });

        if (error) throw error;
        toast({ title: "Slider Created", description: "New slider has been created successfully." });
      }

      setIsDialogOpen(false);
      resetForm();
      fetchSliders();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save slider.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this slider?")) return;

    try {
      const { error } = await supabase.from("website_sliders").delete().eq("id", id);
      if (error) throw error;
      toast({ title: "Slider Deleted", description: "Slider has been deleted successfully." });
      fetchSliders();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete slider.",
        variant: "destructive",
      });
    }
  };

  const toggleActive = async (slider: SliderData) => {
    try {
      const { error } = await supabase
        .from("website_sliders")
        .update({ is_active: !slider.is_active })
        .eq("id", slider.id);

      if (error) throw error;
      fetchSliders();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update status.",
        variant: "destructive",
      });
    }
  };

  const openEditDialog = (slider: SliderData) => {
    setEditingSlider(slider);
    setFormData({
      title: slider.title || "",
      subtitle: slider.subtitle || "",
      description: slider.description || "",
      image_url: slider.image_url || "",
      cta_text: slider.cta_text || "",
      cta_link: slider.cta_link || "",
      display_order: slider.display_order,
      is_active: slider.is_active,
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingSlider(null);
    setFormData({
      title: "",
      subtitle: "",
      description: "",
      image_url: "",
      cta_text: "",
      cta_link: "",
      display_order: sliders.length,
      is_active: true,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Website Sliders</h1>
          <p className="text-muted-foreground">Manage hero banners and sliders</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Add Slider
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingSlider ? "Edit Slider" : "Add New Slider"}</DialogTitle>
              <DialogDescription>
                {editingSlider ? "Update slider details" : "Create a new hero slider"}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Welcome to Our Business"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subtitle">Subtitle</Label>
                <Input
                  id="subtitle"
                  value={formData.subtitle}
                  onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                  placeholder="Professional Services"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description for the slider"
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="imageUrl">Image URL</Label>
                <Input
                  id="imageUrl"
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  placeholder="https://example.com/banner.jpg"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ctaText">Button Text</Label>
                  <Input
                    id="ctaText"
                    value={formData.cta_text}
                    onChange={(e) => setFormData({ ...formData, cta_text: e.target.value })}
                    placeholder="Learn More"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ctaLink">Button Link</Label>
                  <Input
                    id="ctaLink"
                    value={formData.cta_link}
                    onChange={(e) => setFormData({ ...formData, cta_link: e.target.value })}
                    placeholder="/services"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="displayOrder">Display Order</Label>
                <Input
                  id="displayOrder"
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                />
              </div>
              <div className="flex items-center gap-3">
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
                <Label>Active</Label>
              </div>
              <Button onClick={handleSubmit} className="w-full">
                {editingSlider ? "Update Slider" : "Create Slider"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {sliders.map((slider) => (
          <Card key={slider.id} className={!slider.is_active ? "opacity-60" : ""}>
            <div className="aspect-video relative bg-secondary rounded-t-lg overflow-hidden">
              {slider.image_url ? (
                <img
                  src={slider.image_url}
                  alt={slider.title || "Slider"}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Image className="w-12 h-12 text-muted-foreground" />
                </div>
              )}
              <Badge
                className="absolute top-2 right-2"
                variant={slider.is_active ? "default" : "secondary"}
              >
                {slider.is_active ? "Active" : "Inactive"}
              </Badge>
            </div>
            <CardContent className="p-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <GripVertical className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Order: {slider.display_order}</span>
                </div>
                <h3 className="font-semibold text-foreground">{slider.title || "Untitled"}</h3>
                {slider.subtitle && (
                  <p className="text-sm text-muted-foreground">{slider.subtitle}</p>
                )}
                {slider.cta_text && (
                  <Badge variant="outline">{slider.cta_text}</Badge>
                )}
              </div>
              <div className="flex gap-2 mt-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => toggleActive(slider)}
                >
                  {slider.is_active ? (
                    <EyeOff className="w-4 h-4 mr-1" />
                  ) : (
                    <Eye className="w-4 h-4 mr-1" />
                  )}
                  {slider.is_active ? "Hide" : "Show"}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => openEditDialog(slider)}
                >
                  <Edit className="w-4 h-4 mr-1" />
                  Edit
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDelete(slider.id)}
                >
                  <Trash2 className="w-4 h-4 mr-1 text-destructive" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {sliders.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Image className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-foreground mb-2">No Sliders Yet</h3>
            <p className="text-muted-foreground mb-4">
              Add your first slider to showcase on the website
            </p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add First Slider
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default WebsiteSliders;
