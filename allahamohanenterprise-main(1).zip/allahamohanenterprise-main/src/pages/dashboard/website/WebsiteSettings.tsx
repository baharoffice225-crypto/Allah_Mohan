import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Save, Palette, Globe, Phone, Share2 } from "lucide-react";

interface WebsiteSettingsData {
  id: string;
  site_name: string | null;
  logo_url: string | null;
  favicon_url: string | null;
  primary_color: string | null;
  secondary_color: string | null;
  accent_color: string | null;
  font_family: string | null;
  meta_title: string | null;
  meta_description: string | null;
  meta_keywords: string | null;
  header_text: string | null;
  footer_text: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  contact_address: string | null;
  social_facebook: string | null;
  social_twitter: string | null;
  social_linkedin: string | null;
  social_youtube: string | null;
  social_instagram: string | null;
}

const WebsiteSettings = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<WebsiteSettingsData | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from("website_settings")
        .select("*")
        .limit(1)
        .single();

      if (error && error.code !== "PGRST116") throw error;
      setSettings(data as WebsiteSettingsData);
    } catch (error: any) {
      console.error("Error fetching settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!settings) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from("website_settings")
        .update({
          site_name: settings.site_name,
          logo_url: settings.logo_url,
          favicon_url: settings.favicon_url,
          primary_color: settings.primary_color,
          secondary_color: settings.secondary_color,
          accent_color: settings.accent_color,
          font_family: settings.font_family,
          header_text: settings.header_text,
          footer_text: settings.footer_text,
          contact_email: settings.contact_email,
          contact_phone: settings.contact_phone,
          contact_address: settings.contact_address,
          social_facebook: settings.social_facebook,
          social_twitter: settings.social_twitter,
          social_linkedin: settings.social_linkedin,
          social_youtube: settings.social_youtube,
          social_instagram: settings.social_instagram,
        })
        .eq("id", settings.id);

      if (error) throw error;

      toast({
        title: "Settings Saved",
        description: "Website settings have been updated successfully.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save settings.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (key: keyof WebsiteSettingsData, value: string) => {
    if (settings) {
      setSettings({ ...settings, [key]: value });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Website Settings</h1>
          <p className="text-muted-foreground">
            Manage your website's general settings and appearance
          </p>
        </div>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Save Changes
        </Button>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general">
            <Globe className="w-4 h-4 mr-2" />
            General
          </TabsTrigger>
          <TabsTrigger value="appearance">
            <Palette className="w-4 h-4 mr-2" />
            Appearance
          </TabsTrigger>
          <TabsTrigger value="contact">
            <Phone className="w-4 h-4 mr-2" />
            Contact
          </TabsTrigger>
          <TabsTrigger value="social">
            <Share2 className="w-4 h-4 mr-2" />
            Social Media
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Basic website information and branding
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                  <Input
                    id="siteName"
                    value={settings?.site_name || ""}
                    onChange={(e) => updateSetting("site_name", e.target.value)}
                    placeholder="Your Business Name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fontFamily">Font Family</Label>
                  <Input
                    id="fontFamily"
                    value={settings?.font_family || ""}
                    onChange={(e) => updateSetting("font_family", e.target.value)}
                    placeholder="Inter, sans-serif"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="logoUrl">Logo URL</Label>
                <Input
                  id="logoUrl"
                  value={settings?.logo_url || ""}
                  onChange={(e) => updateSetting("logo_url", e.target.value)}
                  placeholder="https://example.com/logo.png"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="faviconUrl">Favicon URL</Label>
                <Input
                  id="faviconUrl"
                  value={settings?.favicon_url || ""}
                  onChange={(e) => updateSetting("favicon_url", e.target.value)}
                  placeholder="https://example.com/favicon.ico"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="headerText">Header Text</Label>
                <Input
                  id="headerText"
                  value={settings?.header_text || ""}
                  onChange={(e) => updateSetting("header_text", e.target.value)}
                  placeholder="Welcome to our website"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="footerText">Footer Text</Label>
                <Textarea
                  id="footerText"
                  value={settings?.footer_text || ""}
                  onChange={(e) => updateSetting("footer_text", e.target.value)}
                  placeholder="© 2024 Your Company. All rights reserved."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>
                Customize colors and visual elements
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="primaryColor">Primary Color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={settings?.primary_color || "#3B82F6"}
                      onChange={(e) => updateSetting("primary_color", e.target.value)}
                      className="w-12 h-10 p-1"
                    />
                    <Input
                      id="primaryColor"
                      value={settings?.primary_color || ""}
                      onChange={(e) => updateSetting("primary_color", e.target.value)}
                      placeholder="#3B82F6"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="secondaryColor">Secondary Color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={settings?.secondary_color || "#10B981"}
                      onChange={(e) => updateSetting("secondary_color", e.target.value)}
                      className="w-12 h-10 p-1"
                    />
                    <Input
                      id="secondaryColor"
                      value={settings?.secondary_color || ""}
                      onChange={(e) => updateSetting("secondary_color", e.target.value)}
                      placeholder="#10B981"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accentColor">Accent Color</Label>
                  <div className="flex gap-2">
                    <Input
                      type="color"
                      value={settings?.accent_color || "#F59E0B"}
                      onChange={(e) => updateSetting("accent_color", e.target.value)}
                      className="w-12 h-10 p-1"
                    />
                    <Input
                      id="accentColor"
                      value={settings?.accent_color || ""}
                      onChange={(e) => updateSetting("accent_color", e.target.value)}
                      placeholder="#F59E0B"
                    />
                  </div>
                </div>
              </div>
              <div className="p-4 rounded-lg bg-secondary/50">
                <h4 className="font-medium mb-3">Color Preview</h4>
                <div className="flex gap-3">
                  <div
                    className="w-16 h-16 rounded-lg shadow-md"
                    style={{ backgroundColor: settings?.primary_color || "#3B82F6" }}
                  />
                  <div
                    className="w-16 h-16 rounded-lg shadow-md"
                    style={{ backgroundColor: settings?.secondary_color || "#10B981" }}
                  />
                  <div
                    className="w-16 h-16 rounded-lg shadow-md"
                    style={{ backgroundColor: settings?.accent_color || "#F59E0B" }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact">
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
              <CardDescription>
                Contact details displayed on your website
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="contactEmail">Email Address</Label>
                  <Input
                    id="contactEmail"
                    type="email"
                    value={settings?.contact_email || ""}
                    onChange={(e) => updateSetting("contact_email", e.target.value)}
                    placeholder="contact@example.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contactPhone">Phone Number</Label>
                  <Input
                    id="contactPhone"
                    value={settings?.contact_phone || ""}
                    onChange={(e) => updateSetting("contact_phone", e.target.value)}
                    placeholder="+880 1234-567890"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactAddress">Address</Label>
                <Textarea
                  id="contactAddress"
                  value={settings?.contact_address || ""}
                  onChange={(e) => updateSetting("contact_address", e.target.value)}
                  placeholder="123 Business Street, City, Country"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social">
          <Card>
            <CardHeader>
              <CardTitle>Social Media Links</CardTitle>
              <CardDescription>
                Connect your social media profiles
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="facebook">Facebook</Label>
                  <Input
                    id="facebook"
                    value={settings?.social_facebook || ""}
                    onChange={(e) => updateSetting("social_facebook", e.target.value)}
                    placeholder="https://facebook.com/yourpage"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="twitter">Twitter / X</Label>
                  <Input
                    id="twitter"
                    value={settings?.social_twitter || ""}
                    onChange={(e) => updateSetting("social_twitter", e.target.value)}
                    placeholder="https://twitter.com/yourhandle"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="linkedin">LinkedIn</Label>
                  <Input
                    id="linkedin"
                    value={settings?.social_linkedin || ""}
                    onChange={(e) => updateSetting("social_linkedin", e.target.value)}
                    placeholder="https://linkedin.com/company/yourcompany"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="youtube">YouTube</Label>
                  <Input
                    id="youtube"
                    value={settings?.social_youtube || ""}
                    onChange={(e) => updateSetting("social_youtube", e.target.value)}
                    placeholder="https://youtube.com/@yourchannel"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="instagram">Instagram</Label>
                  <Input
                    id="instagram"
                    value={settings?.social_instagram || ""}
                    onChange={(e) => updateSetting("social_instagram", e.target.value)}
                    placeholder="https://instagram.com/yourprofile"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default WebsiteSettings;
