import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loader2, LayoutGrid, Eye, EyeOff, GripVertical } from "lucide-react";

interface SectionData {
  id: string;
  section_key: string;
  section_name: string;
  is_visible: boolean;
  display_order: number;
  updated_at: string;
}

const sectionIcons: Record<string, string> = {
  hero: "🏠",
  services: "⚙️",
  about: "ℹ️",
  testimonials: "💬",
  contact: "📞",
  footer: "📄",
};

const WebsiteSections = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [sections, setSections] = useState<SectionData[]>([]);

  useEffect(() => {
    fetchSections();
  }, []);

  const fetchSections = async () => {
    try {
      const { data, error } = await supabase
        .from("website_sections")
        .select("*")
        .order("display_order", { ascending: true });

      if (error) throw error;
      setSections(data as SectionData[]);
    } catch (error: any) {
      console.error("Error fetching sections:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleVisibility = async (section: SectionData) => {
    try {
      const { error } = await supabase
        .from("website_sections")
        .update({ is_visible: !section.is_visible })
        .eq("id", section.id);

      if (error) throw error;

      toast({
        title: section.is_visible ? "Section Hidden" : "Section Visible",
        description: `${section.section_name} is now ${section.is_visible ? "hidden" : "visible"} on the website.`,
      });

      fetchSections();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update visibility.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Website Sections</h1>
        <p className="text-muted-foreground">
          Control the visibility of different sections on your website
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LayoutGrid className="w-5 h-5" />
            Section Visibility Control
          </CardTitle>
          <CardDescription>
            Toggle sections on or off to customize your website layout
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order</TableHead>
                <TableHead>Section</TableHead>
                <TableHead>Key</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Visibility</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sections.map((section) => (
                <TableRow key={section.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <GripVertical className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{section.display_order}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <span className="text-xl">
                        {sectionIcons[section.section_key] || "📦"}
                      </span>
                      <span className="font-medium text-foreground">
                        {section.section_name}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <code className="text-xs bg-secondary px-2 py-1 rounded">
                      {section.section_key}
                    </code>
                  </TableCell>
                  <TableCell>
                    <Badge variant={section.is_visible ? "default" : "secondary"}>
                      {section.is_visible ? (
                        <><Eye className="w-3 h-3 mr-1" /> Visible</>
                      ) : (
                        <><EyeOff className="w-3 h-3 mr-1" /> Hidden</>
                      )}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Switch
                      checked={section.is_visible}
                      onCheckedChange={() => toggleVisibility(section)}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Preview Card */}
      <Card>
        <CardHeader>
          <CardTitle>Website Preview</CardTitle>
          <CardDescription>
            This shows which sections are currently enabled
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {sections.map((section) => (
              <div
                key={section.id}
                className={`p-3 rounded-lg border transition-colors ${
                  section.is_visible
                    ? "bg-primary/5 border-primary/20"
                    : "bg-secondary/30 border-border opacity-50"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">{sectionIcons[section.section_key] || "📦"}</span>
                    <span className={section.is_visible ? "font-medium" : "text-muted-foreground"}>
                      {section.section_name}
                    </span>
                  </div>
                  {section.is_visible ? (
                    <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary">Hidden</Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WebsiteSections;
