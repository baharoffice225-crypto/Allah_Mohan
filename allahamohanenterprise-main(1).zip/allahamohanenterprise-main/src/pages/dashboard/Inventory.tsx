import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { 
  Package, 
  Plus, 
  Search, 
  AlertTriangle,
  Edit,
  Trash2,
  Eye,
  Loader2,
  Boxes,
  DollarSign,
  History,
  ArrowUpCircle,
  ArrowDownCircle,
  RefreshCw,
  Bell,
  ChevronDown,
  ChevronUp,
  X,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";
import InventoryReport from "@/components/reports/InventoryReport";

interface InventoryItem {
  id: string;
  name: string;
  category: string;
  stock: number;
  unit: string;
  min_stock: number;
  price: number;
  sku: string | null;
  description: string | null;
  created_at: string;
  updated_at: string;
}

interface InventoryTransaction {
  id: string;
  inventory_id: string;
  user_id: string | null;
  type: "in" | "out" | "adjustment";
  quantity: number;
  previous_stock: number;
  new_stock: number;
  notes: string | null;
  created_at: string;
  profiles?: { full_name: string | null; email: string | null } | null;
}

const CATEGORIES = ["Yarn", "Fabric", "Buttons", "Zippers", "Jhut", "Accessories", "Thread", "Other"];
const UNITS = ["kg", "pcs", "meter", "roll", "box", "dozen"];

const Inventory = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { role } = useAuth();
  const { canPerformAction } = usePermissions(role);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isStockDialogOpen, setIsStockDialogOpen] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [stockAction, setStockAction] = useState<"in" | "out">("in");
  const [stockAmount, setStockAmount] = useState("");
  const [stockNotes, setStockNotes] = useState("");
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [isAlertsExpanded, setIsAlertsExpanded] = useState(true);
  const [dismissedAlerts, setDismissedAlerts] = useState<Set<string>>(new Set());
  
  const [formData, setFormData] = useState({
    name: "",
    category: "Yarn",
    stock: 0,
    unit: "kg",
    min_stock: 0,
    price: 0,
    sku: "",
    description: "",
  });

  // Fetch inventory
  const { data: inventory = [], isLoading } = useQuery({
    queryKey: ["inventory"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("inventory")
        .select("*")
        .order("name");
      
      if (error) throw error;
      return data as InventoryItem[];
    },
  });

  // Fetch transactions for selected item
  const { data: transactions = [], isLoading: isLoadingTransactions } = useQuery({
    queryKey: ["inventory-transactions", selectedItem?.id],
    queryFn: async () => {
      if (!selectedItem) return [];
      
      // First get transactions
      const { data: txData, error: txError } = await supabase
        .from("inventory_transactions")
        .select("*")
        .eq("inventory_id", selectedItem.id)
        .order("created_at", { ascending: false })
        .limit(50);
      
      if (txError) throw txError;
      
      // Get unique user IDs and fetch profiles
      const userIds = [...new Set(txData.map(t => t.user_id).filter(Boolean))];
      let profilesMap: Record<string, { full_name: string | null; email: string | null }> = {};
      
      if (userIds.length > 0) {
        const { data: profilesData } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", userIds);
        
        if (profilesData) {
          profilesMap = Object.fromEntries(
            profilesData.map(p => [p.id, { full_name: p.full_name, email: p.email }])
          );
        }
      }
      
      // Merge profiles into transactions
      return txData.map(t => ({
        ...t,
        profiles: t.user_id ? profilesMap[t.user_id] || null : null,
      })) as InventoryTransaction[];
    },
    enabled: !!selectedItem && isHistoryDialogOpen,
  });

  // Add item mutation
  const addItemMutation = useMutation({
    mutationFn: async (newItem: Omit<InventoryItem, "id" | "created_at" | "updated_at">) => {
      const { data, error } = await supabase
        .from("inventory")
        .insert([newItem])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["inventory"] });
      setIsAddDialogOpen(false);
      resetForm();
      toast({ title: "Success!", description: "Item added successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add item.", variant: "destructive" });
    },
  });

  // Update item mutation
  const updateItemMutation = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<InventoryItem> & { id: string }) => {
      const { data, error } = await supabase
        .from("inventory")
        .update(updates)
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["inventory"] });
      setIsEditDialogOpen(false);
      setIsStockDialogOpen(false);
      setSelectedItem(null);
      toast({ title: "Success!", description: "Item updated successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update item.", variant: "destructive" });
    },
  });

  // Delete item mutation
  const deleteItemMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("inventory").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["inventory"] });
      toast({ title: "Success!", description: "Item deleted successfully." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete item.", variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      category: "Yarn",
      stock: 0,
      unit: "kg",
      min_stock: 0,
      price: 0,
      sku: "",
      description: "",
    });
  };

  const handleAddItem = () => {
    if (!formData.name.trim()) {
      toast({ title: "Error", description: "Item name is required.", variant: "destructive" });
      return;
    }
    addItemMutation.mutate(formData);
  };

  const handleEditItem = () => {
    if (!selectedItem) return;
    updateItemMutation.mutate({
      id: selectedItem.id,
      ...formData,
    });
  };

  const handleStockUpdate = async () => {
    if (!selectedItem || !stockAmount) return;
    const amount = parseFloat(stockAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({ title: "Error", description: "Please enter a valid amount.", variant: "destructive" });
      return;
    }
    
    const previousStock = selectedItem.stock;
    const newStock = stockAction === "in" 
      ? selectedItem.stock + amount 
      : Math.max(0, selectedItem.stock - amount);
    
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      
      // Update inventory
      const { error: updateError } = await supabase
        .from("inventory")
        .update({ stock: newStock })
        .eq("id", selectedItem.id);
      
      if (updateError) throw updateError;
      
      // Record transaction
      const { error: txError } = await supabase
        .from("inventory_transactions")
        .insert({
          inventory_id: selectedItem.id,
          user_id: user?.id || null,
          type: stockAction,
          quantity: amount,
          previous_stock: previousStock,
          new_stock: newStock,
          notes: stockNotes || null,
        });
      
      if (txError) throw txError;
      
      queryClient.invalidateQueries({ queryKey: ["inventory"] });
      queryClient.invalidateQueries({ queryKey: ["inventory-transactions", selectedItem.id] });
      setIsStockDialogOpen(false);
      setSelectedItem(null);
      setStockAmount("");
      setStockNotes("");
      toast({ title: "Success!", description: `Stock ${stockAction === "in" ? "added" : "removed"} successfully.` });
    } catch (error) {
      toast({ title: "Error", description: "Failed to update stock.", variant: "destructive" });
    }
  };

  const handleDeleteItem = (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      deleteItemMutation.mutate(id);
    }
  };

  const openEditDialog = (item: InventoryItem) => {
    setSelectedItem(item);
    setFormData({
      name: item.name,
      category: item.category,
      stock: item.stock,
      unit: item.unit,
      min_stock: item.min_stock,
      price: item.price,
      sku: item.sku || "",
      description: item.description || "",
    });
    setIsEditDialogOpen(true);
  };

  const openStockDialog = (item: InventoryItem, action: "in" | "out") => {
    setSelectedItem(item);
    setStockAction(action);
    setStockAmount("");
    setStockNotes("");
    setIsStockDialogOpen(true);
  };

  const openViewDialog = (item: InventoryItem) => {
    setSelectedItem(item);
    setIsViewDialogOpen(true);
  };

  const openHistoryDialog = (item: InventoryItem) => {
    setSelectedItem(item);
    setIsHistoryDialogOpen(true);
  };

  const getStockStatus = (stock: number, minStock: number) => {
    const ratio = stock / minStock;
    if (ratio < 1) return { label: "Low Stock", color: "destructive" as const };
    if (ratio < 1.5) return { label: "Reorder Soon", color: "secondary" as const };
    return { label: "In Stock", color: "default" as const };
  };

  // Filtered inventory
  const filteredInventory = useMemo(() => {
    return inventory.filter((item) => {
      const matchesSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sku?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = categoryFilter === "all" || item.category === categoryFilter;
      
      return matchesSearch && matchesCategory;
    });
  }, [inventory, searchQuery, categoryFilter]);

  // Stats
  const stats = {
    total: inventory.length,
    lowStock: inventory.filter(i => i.stock < i.min_stock).length,
    totalValue: inventory.reduce((sum, i) => sum + (i.stock * i.price), 0),
    categories: [...new Set(inventory.map(i => i.category))].length,
  };

  // Low stock items for alerts (exclude dismissed)
  const lowStockItems = useMemo(() => {
    return inventory
      .filter(i => i.stock < i.min_stock && !dismissedAlerts.has(i.id))
      .sort((a, b) => (a.stock / a.min_stock) - (b.stock / b.min_stock));
  }, [inventory, dismissedAlerts]);

  const handleDismissAlert = (itemId: string) => {
    setDismissedAlerts(prev => new Set([...prev, itemId]));
  };

  const handleClearDismissed = () => {
    setDismissedAlerts(new Set());
  };

  const canCreate = canPerformAction("inventory", "create");
  const canEdit = canPerformAction("inventory", "edit");
  const canDelete = canPerformAction("inventory", "delete");

  const ItemForm = () => (
    <div className="space-y-4 py-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2 space-y-2">
          <Label htmlFor="name">Item Name *</Label>
          <Input
            id="name"
            placeholder="Item name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select
            value={formData.category}
            onValueChange={(value) => setFormData({ ...formData, category: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {CATEGORIES.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="sku">SKU</Label>
          <Input
            id="sku"
            placeholder="SKU code"
            value={formData.sku}
            onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="stock">Current Stock</Label>
          <Input
            id="stock"
            type="number"
            min="0"
            value={formData.stock}
            onChange={(e) => setFormData({ ...formData, stock: parseFloat(e.target.value) || 0 })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="unit">Unit</Label>
          <Select
            value={formData.unit}
            onValueChange={(value) => setFormData({ ...formData, unit: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select unit" />
            </SelectTrigger>
            <SelectContent>
              {UNITS.map(unit => (
                <SelectItem key={unit} value={unit}>{unit}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="min_stock">Minimum Stock</Label>
          <Input
            id="min_stock"
            type="number"
            min="0"
            value={formData.min_stock}
            onChange={(e) => setFormData({ ...formData, min_stock: parseFloat(e.target.value) || 0 })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="price">Unit Price (৳)</Label>
          <Input
            id="price"
            type="number"
            min="0"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
          />
        </div>
        <div className="col-span-2 space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Item description..."
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Inventory
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage garments materials stock and inventory
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setIsReportDialogOpen(true)}>
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">Print Report</span>
          </Button>
        {canCreate && (
          <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Item</DialogTitle>
              </DialogHeader>
              <ItemForm />
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <Button onClick={handleAddItem} disabled={addItemMutation.isPending}>
                  {addItemMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Add Item
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
        </div>
      </div>

      {/* Inventory Report Dialog */}
      <InventoryReport open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen} />

      {/* Low Stock Alerts Banner */}
      {lowStockItems.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-lg border border-destructive/30 bg-destructive/5"
        >
          <div 
            className="flex items-center justify-between p-4 cursor-pointer"
            onClick={() => setIsAlertsExpanded(!isAlertsExpanded)}
          >
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
                <Bell className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <h3 className="font-semibold text-destructive">Low Stock Alerts</h3>
                <p className="text-sm text-muted-foreground">
                  {lowStockItems.length} item{lowStockItems.length !== 1 ? 's' : ''} below minimum stock level
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {dismissedAlerts.size > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleClearDismissed();
                  }}
                  className="text-xs text-muted-foreground hover:text-foreground"
                >
                  Show dismissed ({dismissedAlerts.size})
                </Button>
              )}
              {isAlertsExpanded ? (
                <ChevronUp className="w-5 h-5 text-muted-foreground" />
              ) : (
                <ChevronDown className="w-5 h-5 text-muted-foreground" />
              )}
            </div>
          </div>
          
          {isAlertsExpanded && (
            <div className="border-t border-destructive/20 p-4 space-y-2">
              {lowStockItems.slice(0, 5).map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-3 rounded-md bg-background hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="w-4 h-4 text-destructive" />
                    <div>
                      <p className="font-medium text-sm">{item.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.category} • Current: <span className="text-destructive font-medium">{item.stock}</span> / Min: {item.min_stock} {item.unit}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 gap-1 text-xs"
                      onClick={() => openStockDialog(item, "in")}
                    >
                      <ArrowUpCircle className="w-3 h-3" />
                      Stock In
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleDismissAlert(item.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {lowStockItems.length > 5 && (
                <p className="text-sm text-muted-foreground text-center pt-2">
                  +{lowStockItems.length - 5} more items with low stock
                </p>
              )}
            </div>
          )}
        </motion.div>
      )}

      {/* Stats Cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Items</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Package className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Low Stock</p>
                  <p className="text-2xl font-bold text-destructive">{stats.lowStock}</p>
                </div>
                <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-destructive" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Value</p>
                  <p className="text-2xl font-bold">৳{stats.totalValue.toLocaleString()}</p>
                </div>
                <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Categories</p>
                  <p className="text-2xl font-bold">{stats.categories}</p>
                </div>
                <div className="h-12 w-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Boxes className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search inventory..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Inventory Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-card rounded-xl border border-border overflow-hidden"
      >
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredInventory.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No inventory items found</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Product</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Stock Level</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Unit Price</TableHead>
                <TableHead className="text-right">Total Value</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInventory.map((item) => {
                const status = getStockStatus(item.stock, item.min_stock);
                const stockPercent = item.min_stock > 0 
                  ? Math.min((item.stock / (item.min_stock * 2)) * 100, 100) 
                  : 100;
                return (
                  <TableRow key={item.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center">
                          <Package className="w-5 h-5 text-muted-foreground" />
                        </div>
                        <div>
                          <div className="font-medium text-foreground">{item.name}</div>
                          {item.sku && <div className="text-xs text-muted-foreground">SKU: {item.sku}</div>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1 min-w-[120px]">
                        <div className="flex justify-between text-sm">
                          <span>{item.stock} {item.unit}</span>
                          <span className="text-muted-foreground">Min: {item.min_stock}</span>
                        </div>
                        <Progress value={stockPercent} className="h-2" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={status.color}>{status.label}</Badge>
                    </TableCell>
                    <TableCell className="text-right">৳{item.price}</TableCell>
                    <TableCell className="text-right font-medium">
                      ৳{(item.stock * item.price).toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openViewDialog(item)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openHistoryDialog(item)} title="View History">
                          <History className="w-4 h-4" />
                        </Button>
                        {canEdit && (
                          <>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 text-green-600 hover:text-green-700"
                              onClick={() => openStockDialog(item, "in")}
                            >
                              +In
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 text-orange-600 hover:text-orange-700"
                              onClick={() => openStockDialog(item, "out")}
                            >
                              -Out
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditDialog(item)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                        {canDelete && (
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => handleDeleteItem(item.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </motion.div>

      {/* View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Item Details</DialogTitle>
          </DialogHeader>
          {selectedItem && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-secondary rounded-xl flex items-center justify-center">
                  <Package className="w-8 h-8 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">{selectedItem.name}</h3>
                  <Badge variant="outline">{selectedItem.category}</Badge>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">SKU</Label>
                  <p className="font-medium">{selectedItem.sku || "-"}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Unit</Label>
                  <p className="font-medium">{selectedItem.unit}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Current Stock</Label>
                  <p className="font-medium">{selectedItem.stock} {selectedItem.unit}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Minimum Stock</Label>
                  <p className="font-medium">{selectedItem.min_stock} {selectedItem.unit}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Unit Price</Label>
                  <p className="font-medium">৳{selectedItem.price}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Total Value</Label>
                  <p className="font-medium">৳{(selectedItem.stock * selectedItem.price).toLocaleString()}</p>
                </div>
                {selectedItem.description && (
                  <div className="col-span-2">
                    <Label className="text-muted-foreground">Description</Label>
                    <p className="font-medium">{selectedItem.description}</p>
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Close</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={(open) => {
        setIsEditDialogOpen(open);
        if (!open) setSelectedItem(null);
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Item</DialogTitle>
          </DialogHeader>
          <ItemForm />
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button onClick={handleEditItem} disabled={updateItemMutation.isPending}>
              {updateItemMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Stock In/Out Dialog */}
      <Dialog open={isStockDialogOpen} onOpenChange={(open) => {
        setIsStockDialogOpen(open);
        if (!open) {
          setSelectedItem(null);
          setStockAmount("");
          setStockNotes("");
        }
      }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>
              {stockAction === "in" ? "Stock In" : "Stock Out"} - {selectedItem?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div>
              <Label className="text-muted-foreground">Current Stock</Label>
              <p className="text-lg font-semibold">{selectedItem?.stock} {selectedItem?.unit}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount">
                {stockAction === "in" ? "Add Amount" : "Remove Amount"} ({selectedItem?.unit})
              </Label>
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.01"
                placeholder={`Enter ${selectedItem?.unit}`}
                value={stockAmount}
                onChange={(e) => setStockAmount(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (optional)</Label>
              <Input
                id="notes"
                placeholder="Reason for stock change..."
                value={stockNotes}
                onChange={(e) => setStockNotes(e.target.value)}
              />
            </div>
            {stockAmount && selectedItem && (
              <div className="p-3 bg-muted rounded-lg">
                <Label className="text-muted-foreground">New Stock</Label>
                <p className="text-lg font-semibold">
                  {stockAction === "in" 
                    ? (selectedItem.stock + (parseFloat(stockAmount) || 0)).toFixed(2)
                    : Math.max(0, selectedItem.stock - (parseFloat(stockAmount) || 0)).toFixed(2)
                  } {selectedItem.unit}
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button 
              onClick={handleStockUpdate} 
              variant={stockAction === "in" ? "default" : "destructive"}
            >
              {stockAction === "in" ? "Add Stock" : "Remove Stock"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transaction History Dialog */}
      <Dialog open={isHistoryDialogOpen} onOpenChange={(open) => {
        setIsHistoryDialogOpen(open);
        if (!open) setSelectedItem(null);
      }}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="w-5 h-5" />
              Transaction History - {selectedItem?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto py-4">
            {isLoadingTransactions ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-primary" />
              </div>
            ) : transactions.length === 0 ? (
              <div className="text-center py-8">
                <RefreshCw className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No transactions recorded yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {transactions.map((tx) => (
                  <div 
                    key={tx.id} 
                    className="flex items-start gap-3 p-3 rounded-lg border border-border bg-card"
                  >
                    <div className={`p-2 rounded-full ${
                      tx.type === "in" 
                        ? "bg-green-500/10" 
                        : tx.type === "out" 
                          ? "bg-orange-500/10" 
                          : "bg-blue-500/10"
                    }`}>
                      {tx.type === "in" ? (
                        <ArrowUpCircle className="w-5 h-5 text-green-600" />
                      ) : tx.type === "out" ? (
                        <ArrowDownCircle className="w-5 h-5 text-orange-600" />
                      ) : (
                        <RefreshCw className="w-5 h-5 text-blue-600" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-medium capitalize">
                          Stock {tx.type === "in" ? "In" : tx.type === "out" ? "Out" : "Adjustment"}
                        </span>
                        <span className={`font-semibold ${
                          tx.type === "in" ? "text-green-600" : tx.type === "out" ? "text-orange-600" : "text-blue-600"
                        }`}>
                          {tx.type === "in" ? "+" : "-"}{tx.quantity} {selectedItem?.unit}
                        </span>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        <span>{tx.previous_stock} → {tx.new_stock} {selectedItem?.unit}</span>
                      </div>
                      {tx.notes && (
                        <p className="text-sm mt-1 text-foreground">{tx.notes}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                        <span>{format(new Date(tx.created_at), "dd MMM yyyy, HH:mm")}</span>
                        {tx.profiles && (
                          <>
                            <span>•</span>
                            <span>{tx.profiles.full_name || tx.profiles.email || "Unknown user"}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Close</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Inventory;
