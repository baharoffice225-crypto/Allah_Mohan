import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Bus, 
  Package, 
  Users, 
  DollarSign, 
  TrendingUp, 
  ArrowUpRight,
  Calendar,
  Clock,
  Wallet,
  CreditCard,
  Receipt,
  AlertCircle,
  Banknote,
  PiggyBank,
  ArrowDown,
  ArrowUp,
  Shirt,
  Warehouse,
  ShoppingCart,
} from "lucide-react";
import StatsCard from "@/components/dashboard/StatsCard";
import FinancialCard from "@/components/dashboard/FinancialCard";
import IncomeExpenseChart from "@/components/dashboard/charts/IncomeExpenseChart";
import MonthlyComparisonChart from "@/components/dashboard/charts/MonthlyComparisonChart";
import CashFlowChart from "@/components/dashboard/charts/CashFlowChart";
import RecentTransactionsWidget from "@/components/dashboard/RecentTransactionsWidget";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "react-router-dom";
import { format, startOfMonth, endOfMonth } from "date-fns";

// Mock financial data - would be fetched from API/database
const currentMonthFinancials = {
  income: 485000,
  expense: 125000,
  cash: 320000,
  dues: 165000,
  incomeChange: 12,
  expenseChange: -5,
  cashChange: 8,
  duesChange: 15,
};

const lifetimeFinancials = {
  totalBillCollection: 15850000,
  totalCash: 12450000,
  totalDues: 3400000,
};

const recentActivities = [
  { id: 1, type: "bus", message: "Bus service completed for ABC Garments", time: "2 hours ago" },
  { id: 2, type: "inventory", message: "New stock added: 500 kg Yarn", time: "4 hours ago" },
  { id: 3, type: "payment", message: "Payment received from XYZ Ltd - ৳45,000", time: "5 hours ago" },
  { id: 4, type: "client", message: "New client onboarded: Fashion Hub Ltd", time: "Yesterday" },
  { id: 5, type: "invoice", message: "Monthly invoice generated for 12 clients", time: "Yesterday" },
];

const upcomingTasks = [
  { id: 1, task: "Monthly invoice generation", due: "Tomorrow" },
  { id: 2, task: "Fleet maintenance check", due: "In 3 days" },
  { id: 3, task: "Stock reorder - Buttons", due: "In 5 days" },
];

// Format currency in BDT
const formatBDT = (amount: number) => {
  return new Intl.NumberFormat('en-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount).replace('BDT', '৳');
};

const DashboardHome = () => {
  const [selectedMonth, setSelectedMonth] = useState("current");

  // Fetch garment products data
  const { data: garmentProducts } = useQuery({
    queryKey: ["garment-products-dashboard"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_products")
        .select("id, name, stock, price, cost_price, status");
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch this month's garment sales
  const { data: recentGarmentSales } = useQuery({
    queryKey: ["recent-garment-sales-dashboard"],
    queryFn: async () => {
      const monthStart = format(startOfMonth(new Date()), "yyyy-MM-dd");
      const monthEnd = format(endOfMonth(new Date()), "yyyy-MM-dd");
      const { data, error } = await supabase
        .from("garment_sales")
        .select("id, invoice_number, customer_name, total_amount, sale_date, payment_status")
        .gte("sale_date", monthStart)
        .lte("sale_date", monthEnd)
        .order("sale_date", { ascending: false })
        .limit(5);
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch this month's garment sale items with product cost prices for profit calculation
  const { data: garmentSaleItems } = useQuery({
    queryKey: ["garment-sale-items-profit"],
    queryFn: async () => {
      const monthStart = format(startOfMonth(new Date()), "yyyy-MM-dd");
      const monthEnd = format(endOfMonth(new Date()), "yyyy-MM-dd");
      
      // First get this month's sale IDs
      const { data: sales, error: salesError } = await supabase
        .from("garment_sales")
        .select("id")
        .gte("sale_date", monthStart)
        .lte("sale_date", monthEnd);
      if (salesError) throw salesError;
      
      if (!sales || sales.length === 0) return [];
      
      const saleIds = sales.map(s => s.id);
      
      // Then fetch sale items with product details
      const { data: items, error: itemsError } = await supabase
        .from("garment_sale_items")
        .select(`
          id,
          quantity,
          unit_price,
          total_price,
          product_id,
          garment_products (
            id,
            name,
            cost_price
          )
        `)
        .in("sale_id", saleIds);
      if (itemsError) throw itemsError;
      return items || [];
    },
  });

  // Calculate garment stats
  const totalGarmentProducts = garmentProducts?.length || 0;
  const totalGarmentStock = garmentProducts?.reduce((sum, p) => sum + Number(p.stock), 0) || 0;
  const garmentStockValue = garmentProducts?.reduce((sum, p) => sum + (Number(p.stock) * Number(p.cost_price)), 0) || 0;
  const lowStockProducts = garmentProducts?.filter(p => Number(p.stock) <= 10).length || 0;
  const thisMonthSalesTotal = recentGarmentSales?.reduce((sum, s) => sum + Number(s.total_amount), 0) || 0;

  // Calculate profit/loss
  const profitCalculation = garmentSaleItems?.reduce((acc, item) => {
    const product = item.garment_products as { id: string; name: string; cost_price: number } | null;
    const costPrice = product?.cost_price || 0;
    const revenue = Number(item.total_price);
    const cost = Number(costPrice) * Number(item.quantity);
    const profit = revenue - cost;
    return {
      totalRevenue: acc.totalRevenue + revenue,
      totalCost: acc.totalCost + cost,
      totalProfit: acc.totalProfit + profit,
    };
  }, { totalRevenue: 0, totalCost: 0, totalProfit: 0 }) || { totalRevenue: 0, totalCost: 0, totalProfit: 0 };

  const profitMarginPercent = profitCalculation.totalRevenue > 0 
    ? ((profitCalculation.totalProfit / profitCalculation.totalRevenue) * 100).toFixed(1) 
    : "0";

  const handleCardClick = (type: string) => {
    // Handle navigation to detailed breakdown
    console.log(`Navigate to ${type} details`);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Welcome back! Here's your financial overview.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Select month" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current">This Month</SelectItem>
              <SelectItem value="last">Last Month</SelectItem>
              <SelectItem value="last3">Last 3 Months</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span className="hidden sm:inline">{new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}</span>
          </div>
        </div>
      </div>

      {/* This Month Financial Summary */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <h2 className="font-display text-lg font-bold text-foreground">
            This Month's Summary
          </h2>
          <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium">
            December 2024
          </span>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <FinancialCard
            title="This Month Income"
            value={formatBDT(currentMonthFinancials.income)}
            subtitle="Total income generated"
            icon={TrendingUp}
            variant="income"
            trend={{
              value: `${currentMonthFinancials.incomeChange}% from last month`,
              type: currentMonthFinancials.incomeChange > 0 ? "up" : "down",
            }}
            delay={0}
            onClick={() => handleCardClick("monthly-income")}
          />
          <FinancialCard
            title="This Month Expense"
            value={formatBDT(currentMonthFinancials.expense)}
            subtitle="Total expenses recorded"
            icon={ArrowDown}
            variant="expense"
            trend={{
              value: `${Math.abs(currentMonthFinancials.expenseChange)}% from last month`,
              type: currentMonthFinancials.expenseChange < 0 ? "down" : "up",
            }}
            delay={0.1}
            onClick={() => handleCardClick("monthly-expense")}
          />
          <FinancialCard
            title="This Month Cash"
            value={formatBDT(currentMonthFinancials.cash)}
            subtitle="Cash received"
            icon={Banknote}
            variant="cash"
            trend={{
              value: `${currentMonthFinancials.cashChange}% from last month`,
              type: currentMonthFinancials.cashChange > 0 ? "up" : "down",
            }}
            delay={0.2}
            onClick={() => handleCardClick("monthly-cash")}
          />
          <FinancialCard
            title="This Month Dues"
            value={formatBDT(currentMonthFinancials.dues)}
            subtitle="Outstanding dues"
            icon={AlertCircle}
            variant="dues"
            trend={{
              value: `${currentMonthFinancials.duesChange}% from last month`,
              type: "neutral",
            }}
            delay={0.3}
            onClick={() => handleCardClick("monthly-dues")}
          />
        </div>
      </div>

      {/* Lifetime Totals */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <h2 className="font-display text-lg font-bold text-foreground">
            Lifetime Totals
          </h2>
          <span className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded-full font-medium">
            All Time
          </span>
        </div>
        <div className="grid sm:grid-cols-3 gap-4">
          <FinancialCard
            title="Total Bill Collection"
            value={formatBDT(lifetimeFinancials.totalBillCollection)}
            subtitle="Total collected from all invoices"
            icon={Receipt}
            variant="default"
            delay={0.4}
            onClick={() => handleCardClick("total-collection")}
          />
          <FinancialCard
            title="Total Cash"
            value={formatBDT(lifetimeFinancials.totalCash)}
            subtitle="Overall cash received"
            icon={PiggyBank}
            variant="cash"
            delay={0.5}
            onClick={() => handleCardClick("total-cash")}
          />
          <FinancialCard
            title="Total Dues"
            value={formatBDT(lifetimeFinancials.totalDues)}
            subtitle="Overall outstanding dues"
            icon={CreditCard}
            variant="dues"
            delay={0.6}
            onClick={() => handleCardClick("total-dues")}
          />
        </div>
      </div>

      {/* Business Stats */}
      <div>
        <h2 className="font-display text-lg font-bold text-foreground mb-4">
          Business Overview
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          <StatsCard
            title="Active Clients"
            value="48"
            change="+3 new this month"
            changeType="positive"
            icon={Users}
            delay={0.7}
          />
          <StatsCard
            title="Bus Trips Today"
            value="24"
            change="2 remaining"
            changeType="neutral"
            icon={Bus}
            iconColor="bg-info"
            delay={0.8}
          />
          <StatsCard
            title="Inventory Value"
            value="৳8,50,000"
            change="Stock levels healthy"
            changeType="neutral"
            icon={Package}
            iconColor="bg-warning"
            delay={0.9}
          />
          <StatsCard
            title="Net Profit"
            value={formatBDT(currentMonthFinancials.income - currentMonthFinancials.expense)}
            change="This month"
            changeType="positive"
            icon={Wallet}
            delay={1.0}
          />
        </div>
      </div>

      {/* Garments Products Summary */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <h2 className="font-display text-lg font-bold text-foreground">
              Garments Products
            </h2>
            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium">
              <Shirt className="w-3 h-3 inline mr-1" />
              Overview
            </span>
          </div>
          <Link to="/dashboard/garments/products">
            <Button variant="ghost" size="sm">
              View All
              <ArrowUpRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
          <StatsCard
            title="Total Products"
            value={totalGarmentProducts.toString()}
            change={`${lowStockProducts} low stock`}
            changeType={lowStockProducts > 0 ? "negative" : "positive"}
            icon={Shirt}
            iconColor="bg-primary"
            delay={0.7}
          />
          <StatsCard
            title="Total Stock"
            value={totalGarmentStock.toLocaleString()}
            change="Units in inventory"
            changeType="neutral"
            icon={Warehouse}
            iconColor="bg-info"
            delay={0.75}
          />
          <StatsCard
            title="Stock Value"
            value={formatBDT(garmentStockValue)}
            change="At cost price"
            changeType="neutral"
            icon={Package}
            iconColor="bg-warning"
            delay={0.8}
          />
          <StatsCard
            title="This Month Sales"
            value={formatBDT(thisMonthSalesTotal)}
            change={`${recentGarmentSales?.length || 0} transactions`}
            changeType="positive"
            icon={ShoppingCart}
            iconColor="bg-success"
            delay={0.85}
          />
          <StatsCard
            title="This Month Profit"
            value={formatBDT(profitCalculation.totalProfit)}
            change={`${profitMarginPercent}% margin`}
            changeType={profitCalculation.totalProfit >= 0 ? "positive" : "negative"}
            icon={profitCalculation.totalProfit >= 0 ? TrendingUp : ArrowDown}
            iconColor={profitCalculation.totalProfit >= 0 ? "bg-success" : "bg-destructive"}
            delay={0.9}
          />
        </div>

        {/* Profit Breakdown Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.92 }}
          className="grid sm:grid-cols-3 gap-4 mb-4"
        >
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-foreground">{formatBDT(profitCalculation.totalRevenue)}</p>
              <p className="text-xs text-muted-foreground mt-1">From garment sales this month</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Cost</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-foreground">{formatBDT(profitCalculation.totalCost)}</p>
              <p className="text-xs text-muted-foreground mt-1">Cost of goods sold</p>
            </CardContent>
          </Card>
          <Card className={`border-border ${profitCalculation.totalProfit >= 0 ? 'bg-success/5' : 'bg-destructive/5'}`}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Net Profit/Loss</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {profitCalculation.totalProfit >= 0 ? (
                  <ArrowUp className="w-5 h-5 text-success" />
                ) : (
                  <ArrowDown className="w-5 h-5 text-destructive" />
                )}
                <p className={`text-2xl font-bold ${profitCalculation.totalProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {formatBDT(Math.abs(profitCalculation.totalProfit))}
                </p>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {profitMarginPercent}% profit margin
              </p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Garment Sales */}
        {recentGarmentSales && recentGarmentSales.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="bg-card rounded-xl border border-border p-4"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium text-foreground">Recent Garment Sales</h3>
              <Link to="/dashboard/garments/invoices">
                <Button variant="ghost" size="sm">View All</Button>
              </Link>
            </div>
            <div className="space-y-3">
              {recentGarmentSales.map((sale) => (
                <div key={sale.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Receipt className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{sale.customer_name}</p>
                      <p className="text-xs text-muted-foreground">{sale.invoice_number}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-foreground">{formatBDT(Number(sale.total_amount))}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      sale.payment_status === "paid" ? "bg-success/20 text-success" :
                      sale.payment_status === "partial" ? "bg-warning/20 text-warning" :
                      "bg-destructive/20 text-destructive"
                    }`}>
                      {sale.payment_status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>

      {/* Charts Section */}
      <div>
        <h2 className="font-display text-lg font-bold text-foreground mb-4">
          Analytics & Insights
        </h2>
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          <IncomeExpenseChart delay={1.1} />
          <MonthlyComparisonChart delay={1.2} />
        </div>
        <CashFlowChart delay={1.3} />
      </div>

      {/* Recent Inventory Transactions Widget */}
      <RecentTransactionsWidget delay={1.35} />

      {/* Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Activities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1 }}
          className="lg:col-span-2 bg-card rounded-xl border border-border p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display text-lg font-bold text-foreground">
              Recent Activities
            </h2>
            <Button variant="ghost" size="sm">
              View All
              <ArrowUpRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.2 + index * 0.1 }}
                className="flex items-start gap-4 p-3 rounded-lg hover:bg-secondary/50 transition-colors"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  activity.type === 'bus' ? 'bg-info/20 text-info' :
                  activity.type === 'inventory' ? 'bg-warning/20 text-warning' :
                  activity.type === 'payment' ? 'bg-success/20 text-success' :
                  'gradient-primary text-primary-foreground'
                }`}>
                  {activity.type === 'bus' && <Bus className="w-5 h-5" />}
                  {activity.type === 'inventory' && <Package className="w-5 h-5" />}
                  {activity.type === 'payment' && <DollarSign className="w-5 h-5" />}
                  {activity.type === 'client' && <Users className="w-5 h-5" />}
                  {activity.type === 'invoice' && <TrendingUp className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">{activity.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Upcoming Tasks */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="bg-card rounded-xl border border-border p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display text-lg font-bold text-foreground">
              Upcoming Tasks
            </h2>
            <Clock className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="space-y-4">
            {upcomingTasks.map((task, index) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.3 + index * 0.1 }}
                className="p-4 rounded-lg bg-secondary/50 border border-border"
              >
                <p className="text-sm font-medium text-foreground">{task.task}</p>
                <p className="text-xs text-muted-foreground mt-1">Due: {task.due}</p>
              </motion.div>
            ))}
          </div>
          <Button variant="outline" className="w-full mt-4">
            View All Tasks
          </Button>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.4 }}
        className="bg-card rounded-xl border border-border p-6"
      >
        <h2 className="font-display text-lg font-bold text-foreground mb-4">
          Quick Actions
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button variant="outline" className="h-auto py-4 flex flex-col gap-2">
            <Bus className="w-6 h-6" />
            <span>Add Bus Entry</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex flex-col gap-2">
            <Package className="w-6 h-6" />
            <span>Add Inventory</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex flex-col gap-2">
            <Users className="w-6 h-6" />
            <span>New Client</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex flex-col gap-2">
            <DollarSign className="w-6 h-6" />
            <span>Record Sale</span>
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default DashboardHome;
