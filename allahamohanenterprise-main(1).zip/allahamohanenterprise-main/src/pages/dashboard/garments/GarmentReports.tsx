import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, Package, FolderOpen, TrendingUp, Printer } from "lucide-react";
import { format, startOfMonth, endOfMonth } from "date-fns";

const GarmentReports = () => {
  const [dateFrom, setDateFrom] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [dateTo, setDateTo] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: categories = [] } = useQuery({
    queryKey: ["garment-categories-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_categories")
        .select("id, name")
        .order("name");

      if (error) throw error;
      return data;
    },
  });

  const { data: products = [] } = useQuery({
    queryKey: ["garment-products-report"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_products")
        .select("*, garment_categories(name)")
        .order("name");

      if (error) throw error;
      return data;
    },
  });

  const { data: sales = [] } = useQuery({
    queryKey: ["garment-sales-report", dateFrom, dateTo],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_sales")
        .select("*, garment_sale_items(*, garment_products(name, category_id, garment_categories(name)))")
        .gte("sale_date", dateFrom)
        .lte("sale_date", dateTo)
        .order("sale_date", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const { data: purchases = [] } = useQuery({
    queryKey: ["garment-purchases-report", dateFrom, dateTo],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_purchases")
        .select("*")
        .gte("purchase_date", dateFrom)
        .lte("purchase_date", dateTo)
        .order("purchase_date", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  // Calculate summary stats
  const totalSales = sales.reduce((sum, s) => sum + s.total_amount, 0);
  const totalPurchases = purchases.reduce((sum, p) => sum + p.total_amount, 0);
  const totalStock = products.reduce((sum, p) => sum + p.stock, 0);
  const stockValue = products.reduce((sum, p) => sum + (p.stock * p.cost_price), 0);

  // Product-wise sales summary
  const productSalesSummary = sales.flatMap((s: any) => s.garment_sale_items || [])
    .reduce((acc: any, item: any) => {
      const key = item.product_id;
      if (!acc[key]) {
        acc[key] = {
          product_id: key,
          product_name: item.garment_products?.name || "Unknown",
          category_name: item.garment_products?.garment_categories?.name || "Unknown",
          total_quantity: 0,
          total_revenue: 0,
        };
      }
      acc[key].total_quantity += item.quantity;
      acc[key].total_revenue += item.total_price;
      return acc;
    }, {});

  const productSalesArray = Object.values(productSalesSummary).sort((a: any, b: any) => b.total_revenue - a.total_revenue);

  // Category-wise summary
  const categorySummary = products.reduce((acc: any, product: any) => {
    const catName = product.garment_categories?.name || "Uncategorized";
    if (!acc[catName]) {
      acc[catName] = { name: catName, products: 0, totalStock: 0, totalValue: 0 };
    }
    acc[catName].products += 1;
    acc[catName].totalStock += product.stock;
    acc[catName].totalValue += product.stock * product.cost_price;
    return acc;
  }, {});

  const categoryArray = Object.values(categorySummary);

  const handlePrint = () => {
    window.print();
  };

  const filteredProducts = selectedCategory === "all"
    ? products
    : products.filter((p: any) => p.category_id === selectedCategory);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Garments Reports</h1>
          <p className="text-muted-foreground">Product-wise, category-wise, and date-wise reports</p>
        </div>
        <Button variant="outline" onClick={handlePrint}>
          <Printer className="w-4 h-4 mr-2" />
          Print Report
        </Button>
      </div>

      {/* Date Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-end">
            <div className="space-y-2">
              <Label>From Date</Label>
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-40"
              />
            </div>
            <div className="space-y-2">
              <Label>To Date</Label>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-40"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-2xl font-bold">৳{totalSales.toFixed(2)}</p>
                <p className="text-sm text-muted-foreground">Total Sales</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Package className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">৳{totalPurchases.toFixed(2)}</p>
                <p className="text-sm text-muted-foreground">Total Purchases</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-8 h-8 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">{totalStock.toFixed(2)}</p>
                <p className="text-sm text-muted-foreground">Total Stock Units</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <FolderOpen className="w-8 h-8 text-orange-500" />
              <div>
                <p className="text-2xl font-bold">৳{stockValue.toFixed(2)}</p>
                <p className="text-sm text-muted-foreground">Stock Value</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reports Tabs */}
      <Tabs defaultValue="product-wise" className="space-y-4">
        <TabsList>
          <TabsTrigger value="product-wise">Product-wise Sales</TabsTrigger>
          <TabsTrigger value="category-wise">Category-wise Stock</TabsTrigger>
          <TabsTrigger value="inventory">Inventory Report</TabsTrigger>
        </TabsList>

        <TabsContent value="product-wise">
          <Card>
            <CardHeader>
              <CardTitle>Product-wise Sales Report</CardTitle>
            </CardHeader>
            <CardContent>
              {productSalesArray.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">No sales in the selected period</p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>#</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Qty Sold</TableHead>
                        <TableHead className="text-right">Revenue</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {productSalesArray.map((item: any, index) => (
                        <TableRow key={item.product_id}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell className="font-medium">{item.product_name}</TableCell>
                          <TableCell>{item.category_name}</TableCell>
                          <TableCell>{item.total_quantity}</TableCell>
                          <TableCell className="text-right">৳{item.total_revenue.toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="category-wise">
          <Card>
            <CardHeader>
              <CardTitle>Category-wise Stock Report</CardTitle>
            </CardHeader>
            <CardContent>
              {categoryArray.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">No categories found</p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Category</TableHead>
                        <TableHead>Products</TableHead>
                        <TableHead>Total Stock</TableHead>
                        <TableHead className="text-right">Stock Value</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {categoryArray.map((cat: any) => (
                        <TableRow key={cat.name}>
                          <TableCell className="font-medium">{cat.name}</TableCell>
                          <TableCell>{cat.products}</TableCell>
                          <TableCell>{cat.totalStock.toFixed(2)}</TableCell>
                          <TableCell className="text-right">৳{cat.totalValue.toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <CardTitle>Inventory Report</CardTitle>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((cat: any) => (
                      <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredProducts.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">No products found</p>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>#</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead>Stock</TableHead>
                        <TableHead>Min Stock</TableHead>
                        <TableHead>Cost Price</TableHead>
                        <TableHead>Sell Price</TableHead>
                        <TableHead className="text-right">Stock Value</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product: any, index) => (
                        <TableRow key={product.id} className={product.stock <= product.min_stock ? "bg-destructive/10" : ""}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell className="font-medium">{product.name}</TableCell>
                          <TableCell>{product.garment_categories?.name || "-"}</TableCell>
                          <TableCell>{product.unit}</TableCell>
                          <TableCell className={product.stock <= product.min_stock ? "text-destructive font-medium" : ""}>
                            {product.stock}
                          </TableCell>
                          <TableCell>{product.min_stock}</TableCell>
                          <TableCell>৳{product.cost_price.toFixed(2)}</TableCell>
                          <TableCell>৳{product.price.toFixed(2)}</TableCell>
                          <TableCell className="text-right">৳{(product.stock * product.cost_price).toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                      <TableRow className="font-bold bg-muted">
                        <TableCell colSpan={4}>Total</TableCell>
                        <TableCell>{filteredProducts.reduce((sum: number, p: any) => sum + p.stock, 0).toFixed(2)}</TableCell>
                        <TableCell colSpan={3}></TableCell>
                        <TableCell className="text-right">
                          ৳{filteredProducts.reduce((sum: number, p: any) => sum + (p.stock * p.cost_price), 0).toFixed(2)}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default GarmentReports;
