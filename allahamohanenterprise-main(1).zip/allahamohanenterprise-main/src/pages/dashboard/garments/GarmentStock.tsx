import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Package, ArrowUpCircle, ArrowDownCircle, History, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";

interface GarmentProduct {
  id: string;
  name: string;
  sku: string | null;
  unit: string;
  stock: number;
  min_stock: number;
  garment_categories?: { name: string };
}

interface StockTransaction {
  id: string;
  product_id: string;
  type: string;
  reference_type: string | null;
  quantity: number;
  previous_stock: number;
  new_stock: number;
  notes: string | null;
  created_at: string;
  garment_products?: { name: string; unit: string };
}

const GarmentStock = () => {
  const queryClient = useQueryClient();
  const { role, user } = useAuth();
  const { canPerformAction } = usePermissions(role);
  const [searchTerm, setSearchTerm] = useState("");
  const [isAdjustDialogOpen, setIsAdjustDialogOpen] = useState(false);
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<GarmentProduct | null>(null);
  const [adjustmentType, setAdjustmentType] = useState<"in" | "out">("in");
  const [adjustmentQuantity, setAdjustmentQuantity] = useState(0);
  const [adjustmentNotes, setAdjustmentNotes] = useState("");

  const canEdit = canPerformAction("garments", "edit");

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["garment-products-stock"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_products")
        .select("id, name, sku, unit, stock, min_stock, garment_categories(name)")
        .eq("status", "active")
        .order("name");

      if (error) throw error;
      return data as GarmentProduct[];
    },
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["garment-stock-transactions", selectedProduct?.id],
    queryFn: async () => {
      if (!selectedProduct) return [];
      const { data, error } = await supabase
        .from("garment_stock_transactions")
        .select("*, garment_products(name, unit)")
        .eq("product_id", selectedProduct.id)
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      return data as StockTransaction[];
    },
    enabled: !!selectedProduct && isHistoryDialogOpen,
  });

  const { data: recentTransactions = [] } = useQuery({
    queryKey: ["garment-stock-transactions-recent"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_stock_transactions")
        .select("*, garment_products(name, unit)")
        .order("created_at", { ascending: false })
        .limit(10);

      if (error) throw error;
      return data as StockTransaction[];
    },
  });

  const adjustStockMutation = useMutation({
    mutationFn: async () => {
      if (!selectedProduct) throw new Error("No product selected");
      if (adjustmentQuantity <= 0) throw new Error("Quantity must be greater than 0");

      const newStock = adjustmentType === "in"
        ? selectedProduct.stock + adjustmentQuantity
        : selectedProduct.stock - adjustmentQuantity;

      if (newStock < 0) throw new Error("Insufficient stock");

      // Update product stock
      const { error: stockError } = await supabase
        .from("garment_products")
        .update({ stock: newStock })
        .eq("id", selectedProduct.id);

      if (stockError) throw stockError;

      // Create stock transaction
      const { error: txnError } = await supabase.from("garment_stock_transactions").insert([{
        product_id: selectedProduct.id,
        type: `adjustment_${adjustmentType}`,
        reference_type: "adjustment",
        quantity: adjustmentQuantity,
        previous_stock: selectedProduct.stock,
        new_stock: newStock,
        notes: adjustmentNotes || null,
        created_by: user?.id,
      }]);

      if (txnError) throw txnError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["garment-products-stock"] });
      queryClient.invalidateQueries({ queryKey: ["garment-stock-transactions"] });
      queryClient.invalidateQueries({ queryKey: ["garment-stock-transactions-recent"] });
      toast.success("Stock adjusted successfully");
      setIsAdjustDialogOpen(false);
      resetAdjustment();
    },
    onError: (error: Error) => {
      toast.error(`Failed to adjust stock: ${error.message}`);
    },
  });

  const resetAdjustment = () => {
    setAdjustmentType("in");
    setAdjustmentQuantity(0);
    setAdjustmentNotes("");
    setSelectedProduct(null);
  };

  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (product.sku?.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const lowStockProducts = products.filter((p) => p.stock <= p.min_stock);

  const getTransactionBadge = (type: string) => {
    if (type.includes("in")) return <Badge className="bg-green-500">IN</Badge>;
    return <Badge variant="destructive">OUT</Badge>;
  };

  const stats = {
    totalProducts: products.length,
    lowStock: lowStockProducts.length,
    totalValue: products.reduce((sum, p) => sum + p.stock, 0),
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Stock Management</h1>
          <p className="text-muted-foreground">Monitor and adjust inventory levels</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Package className="w-8 h-8 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats.totalProducts}</p>
                <p className="text-sm text-muted-foreground">Total Products</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-8 h-8 text-destructive" />
              <div>
                <p className="text-2xl font-bold">{stats.lowStock}</p>
                <p className="text-sm text-muted-foreground">Low Stock Items</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <History className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{recentTransactions.length}</p>
                <p className="text-sm text-muted-foreground">Recent Transactions</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              Stock Levels ({filteredProducts.length})
            </CardTitle>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading...</div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No products found</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Current Stock</TableHead>
                    <TableHead>Min Stock</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => (
                    <TableRow key={product.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{product.name}</div>
                          {product.sku && <div className="text-xs text-muted-foreground">{product.sku}</div>}
                        </div>
                      </TableCell>
                      <TableCell>{product.garment_categories?.name || "-"}</TableCell>
                      <TableCell>
                        <span className={product.stock <= product.min_stock ? "text-destructive font-medium" : ""}>
                          {product.stock} {product.unit}
                        </span>
                      </TableCell>
                      <TableCell>{product.min_stock} {product.unit}</TableCell>
                      <TableCell>
                        {product.stock <= product.min_stock ? (
                          <Badge variant="destructive">Low Stock</Badge>
                        ) : (
                          <Badge variant="default">In Stock</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          {canEdit && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="gap-1"
                                onClick={() => {
                                  setSelectedProduct(product);
                                  setAdjustmentType("in");
                                  setIsAdjustDialogOpen(true);
                                }}
                              >
                                <ArrowUpCircle className="w-4 h-4 text-green-500" />
                                In
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="gap-1"
                                onClick={() => {
                                  setSelectedProduct(product);
                                  setAdjustmentType("out");
                                  setIsAdjustDialogOpen(true);
                                }}
                              >
                                <ArrowDownCircle className="w-4 h-4 text-destructive" />
                                Out
                              </Button>
                            </>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedProduct(product);
                              setIsHistoryDialogOpen(true);
                            }}
                          >
                            <History className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="w-5 h-5" />
            Recent Stock Movements
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentTransactions.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">No recent transactions</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Stock Change</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentTransactions.map((txn) => (
                    <TableRow key={txn.id}>
                      <TableCell>{format(new Date(txn.created_at), "MMM d, HH:mm")}</TableCell>
                      <TableCell>{txn.garment_products?.name}</TableCell>
                      <TableCell>{getTransactionBadge(txn.type)}</TableCell>
                      <TableCell>{txn.quantity} {txn.garment_products?.unit}</TableCell>
                      <TableCell>
                        {txn.previous_stock} → {txn.new_stock}
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{txn.notes || "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stock Adjustment Dialog */}
      <Dialog open={isAdjustDialogOpen} onOpenChange={setIsAdjustDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {adjustmentType === "in" ? "Stock In" : "Stock Out"} - {selectedProduct?.name}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              adjustStockMutation.mutate();
            }}
            className="space-y-4"
          >
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm">Current Stock: <strong>{selectedProduct?.stock} {selectedProduct?.unit}</strong></p>
            </div>
            <div className="space-y-2">
              <Label>Adjustment Type</Label>
              <Select value={adjustmentType} onValueChange={(v: "in" | "out") => setAdjustmentType(v)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in">Stock In (Add)</SelectItem>
                  <SelectItem value="out">Stock Out (Remove)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Quantity *</Label>
              <Input
                type="number"
                min="0.01"
                step="0.01"
                value={adjustmentQuantity}
                onChange={(e) => setAdjustmentQuantity(parseFloat(e.target.value) || 0)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={adjustmentNotes}
                onChange={(e) => setAdjustmentNotes(e.target.value)}
                placeholder="Reason for adjustment..."
              />
            </div>
            <Button type="submit" className="w-full" disabled={adjustStockMutation.isPending}>
              {adjustStockMutation.isPending ? "Adjusting..." : "Confirm Adjustment"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={isHistoryDialogOpen} onOpenChange={setIsHistoryDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Stock History - {selectedProduct?.name}</DialogTitle>
          </DialogHeader>
          {transactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No transaction history</div>
          ) : (
            <div className="max-h-96 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Qty</TableHead>
                    <TableHead>Stock</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((txn) => (
                    <TableRow key={txn.id}>
                      <TableCell>{format(new Date(txn.created_at), "MMM d, HH:mm")}</TableCell>
                      <TableCell>{getTransactionBadge(txn.type)}</TableCell>
                      <TableCell>{txn.quantity}</TableCell>
                      <TableCell>{txn.previous_stock} → {txn.new_stock}</TableCell>
                      <TableCell className="max-w-xs truncate">{txn.notes || "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GarmentStock;
