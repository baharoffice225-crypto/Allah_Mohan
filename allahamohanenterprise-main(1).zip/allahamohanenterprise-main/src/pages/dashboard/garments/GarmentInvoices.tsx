import { useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, FileText, Printer, Eye } from "lucide-react";
import { format } from "date-fns";

interface GarmentSale {
  id: string;
  invoice_number: string;
  customer_name: string;
  customer_contact: string | null;
  customer_address: string | null;
  sale_date: string;
  subtotal: number;
  discount: number;
  total_amount: number;
  paid_amount: number;
  payment_status: string;
  notes: string | null;
  created_at: string;
}

const GarmentInvoices = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedSale, setSelectedSale] = useState<GarmentSale | null>(null);
  const printRef = useRef<HTMLDivElement>(null);

  const { data: sales = [], isLoading } = useQuery({
    queryKey: ["garment-invoices"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_sales")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as GarmentSale[];
    },
  });

  const { data: saleItems = [] } = useQuery({
    queryKey: ["garment-sale-items", selectedSale?.id],
    queryFn: async () => {
      if (!selectedSale) return [];
      const { data, error } = await supabase
        .from("garment_sale_items")
        .select("*, garment_products(name, unit)")
        .eq("sale_id", selectedSale.id);

      if (error) throw error;
      return data;
    },
    enabled: !!selectedSale,
  });

  const filteredSales = sales.filter((sale) =>
    sale.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sale.customer_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getPaymentBadgeVariant = (status: string) => {
    switch (status) {
      case "paid": return "default";
      case "partial": return "secondary";
      default: return "destructive";
    }
  };

  const handlePrint = () => {
    if (printRef.current) {
      const printContents = printRef.current.innerHTML;
      const printWindow = window.open("", "_blank");
      if (printWindow) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>Invoice - ${selectedSale?.invoice_number}</title>
            <style>
              * { margin: 0; padding: 0; box-sizing: border-box; }
              body { font-family: Arial, sans-serif; padding: 20px; color: #333; }
              .invoice-header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
              .invoice-header h1 { font-size: 28px; margin-bottom: 5px; }
              .invoice-header p { color: #666; }
              .invoice-info { display: flex; justify-content: space-between; margin-bottom: 30px; }
              .invoice-info div { flex: 1; }
              .invoice-info .right { text-align: right; }
              .invoice-info h3 { font-size: 14px; color: #666; margin-bottom: 5px; }
              .invoice-info p { font-size: 14px; margin-bottom: 3px; }
              table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
              th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
              th { background: #f5f5f5; font-weight: bold; }
              .text-right { text-align: right; }
              .totals { margin-top: 20px; text-align: right; }
              .totals p { margin-bottom: 5px; }
              .totals .grand-total { font-size: 18px; font-weight: bold; border-top: 2px solid #333; padding-top: 10px; margin-top: 10px; }
              .footer { margin-top: 50px; text-align: center; color: #666; font-size: 12px; }
              @media print { body { padding: 0; } }
            </style>
          </head>
          <body>
            ${printContents}
          </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Invoice & Billing</h1>
          <p className="text-muted-foreground">View and print sales invoices</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Invoices ({filteredSales.length})
            </CardTitle>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search invoices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading...</div>
          ) : filteredSales.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {searchTerm ? "No invoices found" : "No invoices yet."}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice #</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Paid</TableHead>
                    <TableHead>Due</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSales.map((sale) => (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">{sale.invoice_number}</TableCell>
                      <TableCell>{sale.customer_name}</TableCell>
                      <TableCell>{format(new Date(sale.sale_date), "MMM d, yyyy")}</TableCell>
                      <TableCell>৳{sale.total_amount.toFixed(2)}</TableCell>
                      <TableCell>৳{sale.paid_amount.toFixed(2)}</TableCell>
                      <TableCell className={sale.total_amount - sale.paid_amount > 0 ? "text-destructive" : ""}>
                        ৳{(sale.total_amount - sale.paid_amount).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getPaymentBadgeVariant(sale.payment_status)}>
                          {sale.payment_status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setSelectedSale(sale);
                              setIsViewDialogOpen(true);
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invoice View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex justify-between items-center">
              <span>Invoice - {selectedSale?.invoice_number}</span>
              <Button variant="outline" size="sm" onClick={handlePrint}>
                <Printer className="w-4 h-4 mr-1" /> Print Invoice
              </Button>
            </DialogTitle>
          </DialogHeader>
          {selectedSale && (
            <div ref={printRef}>
              <div className="invoice-header">
                <h1>INVOICE</h1>
                <p>Allaha Mohan Garments</p>
              </div>

              <div className="invoice-info" style={{ display: "flex", justifyContent: "space-between", marginBottom: "30px" }}>
                <div>
                  <h3 style={{ color: "#666", fontSize: "12px", marginBottom: "5px" }}>Bill To:</h3>
                  <p style={{ fontWeight: "bold" }}>{selectedSale.customer_name}</p>
                  {selectedSale.customer_contact && <p>{selectedSale.customer_contact}</p>}
                  {selectedSale.customer_address && <p>{selectedSale.customer_address}</p>}
                </div>
                <div style={{ textAlign: "right" }}>
                  <h3 style={{ color: "#666", fontSize: "12px", marginBottom: "5px" }}>Invoice Details:</h3>
                  <p><strong>Invoice #:</strong> {selectedSale.invoice_number}</p>
                  <p><strong>Date:</strong> {format(new Date(selectedSale.sale_date), "MMM d, yyyy")}</p>
                  <p><strong>Status:</strong> {selectedSale.payment_status.toUpperCase()}</p>
                </div>
              </div>

              <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "20px" }}>
                <thead>
                  <tr style={{ background: "#f5f5f5" }}>
                    <th style={{ padding: "12px", textAlign: "left", borderBottom: "2px solid #ddd" }}>Item</th>
                    <th style={{ padding: "12px", textAlign: "left", borderBottom: "2px solid #ddd" }}>Quantity</th>
                    <th style={{ padding: "12px", textAlign: "right", borderBottom: "2px solid #ddd" }}>Unit Price</th>
                    <th style={{ padding: "12px", textAlign: "right", borderBottom: "2px solid #ddd" }}>Total</th>
                  </tr>
                </thead>
                <tbody>
                  {saleItems.map((item: any) => (
                    <tr key={item.id}>
                      <td style={{ padding: "12px", borderBottom: "1px solid #ddd" }}>{item.garment_products?.name}</td>
                      <td style={{ padding: "12px", borderBottom: "1px solid #ddd" }}>{item.quantity} {item.garment_products?.unit}</td>
                      <td style={{ padding: "12px", borderBottom: "1px solid #ddd", textAlign: "right" }}>৳{item.unit_price.toFixed(2)}</td>
                      <td style={{ padding: "12px", borderBottom: "1px solid #ddd", textAlign: "right" }}>৳{item.total_price.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div style={{ textAlign: "right", marginTop: "20px" }}>
                <p style={{ marginBottom: "5px" }}>Subtotal: ৳{selectedSale.subtotal.toFixed(2)}</p>
                {selectedSale.discount > 0 && (
                  <p style={{ marginBottom: "5px", color: "green" }}>Discount: -৳{selectedSale.discount.toFixed(2)}</p>
                )}
                <p style={{ fontSize: "18px", fontWeight: "bold", borderTop: "2px solid #333", paddingTop: "10px", marginTop: "10px" }}>
                  Grand Total: ৳{selectedSale.total_amount.toFixed(2)}
                </p>
                <p style={{ marginTop: "10px" }}>Paid Amount: ৳{selectedSale.paid_amount.toFixed(2)}</p>
                {selectedSale.total_amount - selectedSale.paid_amount > 0 && (
                  <p style={{ color: "red", fontWeight: "bold" }}>
                    Balance Due: ৳{(selectedSale.total_amount - selectedSale.paid_amount).toFixed(2)}
                  </p>
                )}
              </div>

              <div className="footer" style={{ marginTop: "50px", textAlign: "center", color: "#666", fontSize: "12px" }}>
                <p>Thank you for your business!</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GarmentInvoices;
