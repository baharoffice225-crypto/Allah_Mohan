import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Plus, Package, Edit2, Trash2, Eye, EyeOff, Star, StarOff, Search, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useImageUpload } from "@/hooks/useImageUpload";
import { ImageUpload } from "@/components/ui/image-upload";
import { GalleryImageUpload } from "@/components/ui/gallery-image-upload";

interface GarmentWebsiteProduct {
  id: string;
  name: string;
  description: string | null;
  short_description: string | null;
  features: string[];
  specifications: Record<string, string>;
  price: number;
  price_unit: string;
  category: string;
  image_url: string | null;
  gallery_images: string[];
  is_featured: boolean;
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

const categoryOptions = [
  { value: "yarn", label: "Yarn & Thread" },
  { value: "buttons", label: "Buttons & Accessories" },
  { value: "fabric", label: "Fabric & Textile" },
  { value: "jhut", label: "Jhut (Waste)" },
  { value: "zippers", label: "Zippers" },
  { value: "other", label: "Other Materials" },
];

const priceUnitOptions = [
  { value: "per kg", label: "Per Kg" },
  { value: "per piece", label: "Per Piece" },
  { value: "per meter", label: "Per Meter" },
  { value: "per dozen", label: "Per Dozen" },
  { value: "per bale", label: "Per Bale" },
];

const GarmentWebsiteProducts = () => {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<GarmentWebsiteProduct | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Image upload hook
  const { uploadImage, deleteImage, isUploading, progress } = useImageUpload({
    bucket: "product-images",
    folder: "garment-products",
  });
  
  // Form state
  const [formData, setFormData] = useState({
    name: "",
    short_description: "",
    description: "",
    features: "",
    specifications: "",
    price: "",
    price_unit: "per kg",
    category: "yarn",
    image_url: "",
    gallery_images: [] as string[],
    is_featured: false,
    is_active: true,
    display_order: 0,
  });

  // Fetch products
  const { data: products = [], isLoading } = useQuery({
    queryKey: ["garment-website-products"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_website_products")
        .select("*")
        .order("display_order", { ascending: true });
      
      if (error) throw error;
      return data as GarmentWebsiteProduct[];
    },
  });

  // Create/Update mutation
  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const payload = {
        name: data.name,
        short_description: data.short_description || null,
        description: data.description || null,
        features: data.features.split("\n").filter(f => f.trim()),
        specifications: data.specifications ? JSON.parse(data.specifications) : {},
        price: parseFloat(data.price) || 0,
        price_unit: data.price_unit,
        category: data.category,
        image_url: data.image_url || null,
        gallery_images: data.gallery_images,
        is_featured: data.is_featured,
        is_active: data.is_active,
        display_order: data.display_order,
      };

      if (editingProduct) {
        const { error } = await supabase
          .from("garment_website_products")
          .update(payload)
          .eq("id", editingProduct.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("garment_website_products")
          .insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["garment-website-products"] });
      toast.success(editingProduct ? "Product updated successfully" : "Product added successfully");
      handleCloseDialog();
    },
    onError: (error) => {
      toast.error("Failed to save product: " + error.message);
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("garment_website_products")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["garment-website-products"] });
      toast.success("Product deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete product: " + error.message);
    },
  });

  // Toggle active/featured mutations
  const toggleMutation = useMutation({
    mutationFn: async ({ id, field, value }: { id: string; field: string; value: boolean }) => {
      const { error } = await supabase
        .from("garment_website_products")
        .update({ [field]: value })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["garment-website-products"] });
    },
  });

  const handleOpenDialog = (product?: GarmentWebsiteProduct) => {
    if (product) {
      setEditingProduct(product);
      setFormData({
        name: product.name,
        short_description: product.short_description || "",
        description: product.description || "",
        features: product.features.join("\n"),
        specifications: JSON.stringify(product.specifications, null, 2),
        price: product.price.toString(),
        price_unit: product.price_unit,
        category: product.category,
        image_url: product.image_url || "",
        gallery_images: product.gallery_images || [],
        is_featured: product.is_featured,
        is_active: product.is_active,
        display_order: product.display_order,
      });
    } else {
      setEditingProduct(null);
      setFormData({
        name: "",
        short_description: "",
        description: "",
        features: "",
        specifications: '{\n  "composition": "",\n  "quality": "",\n  "origin": ""\n}',
        price: "",
        price_unit: "per kg",
        category: "yarn",
        image_url: "",
        gallery_images: [],
        is_featured: false,
        is_active: true,
        display_order: products.length,
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingProduct(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error("Product name is required");
      return;
    }
    try {
      if (formData.specifications) {
        JSON.parse(formData.specifications);
      }
    } catch {
      toast.error("Invalid specifications JSON format");
      return;
    }
    saveMutation.mutate(formData);
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/dashboard/garments/categories">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
              Garments Website Products
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage products displayed on the website services page
            </p>
          </div>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Product
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingProduct ? "Edit Product" : "Add New Product"}</DialogTitle>
              <DialogDescription>
                {editingProduct ? "Update product details" : "Add a new garment product to display on the website"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="name">Product Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Premium Cotton Yarn"
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="short_description">Short Description</Label>
                  <Input
                    id="short_description"
                    value={formData.short_description}
                    onChange={(e) => setFormData({ ...formData, short_description: e.target.value })}
                    placeholder="Brief one-line description"
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="description">Full Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Detailed description of the product..."
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categoryOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="price">Price (৳)</Label>
                    <Input
                      id="price"
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <Label htmlFor="price_unit">Unit</Label>
                    <Select
                      value={formData.price_unit}
                      onValueChange={(value) => setFormData({ ...formData, price_unit: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {priceUnitOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="col-span-2">
                  <Label htmlFor="features">Features (one per line)</Label>
                  <Textarea
                    id="features"
                    value={formData.features}
                    onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                    placeholder="100% pure cotton&#10;High tensile strength&#10;Factory direct pricing"
                    rows={4}
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="specifications">Specifications (JSON)</Label>
                  <Textarea
                    id="specifications"
                    value={formData.specifications}
                    onChange={(e) => setFormData({ ...formData, specifications: e.target.value })}
                    placeholder='{"composition": "100% Cotton", "quality": "Premium"}'
                    rows={4}
                    className="font-mono text-sm"
                  />
                </div>
                <div className="col-span-2">
                  <Label>Main Product Image</Label>
                  <ImageUpload
                    value={formData.image_url}
                    onChange={(url) => setFormData({ ...formData, image_url: url || "" })}
                    onUpload={uploadImage}
                    onDelete={deleteImage}
                    isUploading={isUploading}
                    progress={progress}
                    placeholder="Upload main product image"
                  />
                </div>
                <div className="col-span-2">
                  <Label>Gallery Images</Label>
                  <GalleryImageUpload
                    value={formData.gallery_images}
                    onChange={(urls) => setFormData({ ...formData, gallery_images: urls })}
                    onUpload={uploadImage}
                    onDelete={deleteImage}
                    isUploading={isUploading}
                    progress={progress}
                    maxImages={8}
                    placeholder="Add gallery images"
                  />
                </div>
                <div>
                  <Label htmlFor="display_order">Display Order</Label>
                  <Input
                    id="display_order"
                    type="number"
                    value={formData.display_order}
                    onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <Switch
                      id="is_active"
                      checked={formData.is_active}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                    />
                    <Label htmlFor="is_active">Active</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="is_featured"
                      checked={formData.is_featured}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_featured: checked })}
                    />
                    <Label htmlFor="is_featured">Featured</Label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancel
                </Button>
                <Button type="submit" disabled={saveMutation.isPending}>
                  {saveMutation.isPending ? "Saving..." : editingProduct ? "Update" : "Add Product"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Products ({products.length})</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {searchQuery ? "No products match your search" : "No products added yet"}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Featured</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product, index) => (
                  <motion.tr
                    key={product.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b"
                  >
                    <TableCell>
                      <div className="flex items-center gap-3">
                        {product.image_url ? (
                          <img
                            src={product.image_url}
                            alt={product.name}
                            className="w-10 h-10 rounded-lg object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                            <Package className="w-5 h-5 text-accent" />
                          </div>
                        )}
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground truncate max-w-xs">
                            {product.short_description}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="capitalize">
                        {product.category}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="font-semibold">৳{product.price.toLocaleString()}</span>
                      <span className="text-sm text-muted-foreground ml-1">/{product.price_unit}</span>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleMutation.mutate({ 
                          id: product.id, 
                          field: "is_active", 
                          value: !product.is_active 
                        })}
                        className={product.is_active ? "text-success" : "text-muted-foreground"}
                      >
                        {product.is_active ? <Eye className="w-4 h-4 mr-1" /> : <EyeOff className="w-4 h-4 mr-1" />}
                        {product.is_active ? "Active" : "Hidden"}
                      </Button>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleMutation.mutate({ 
                          id: product.id, 
                          field: "is_featured", 
                          value: !product.is_featured 
                        })}
                        className={product.is_featured ? "text-warning" : "text-muted-foreground"}
                      >
                        {product.is_featured ? <Star className="w-4 h-4" /> : <StarOff className="w-4 h-4" />}
                      </Button>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleOpenDialog(product)}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive"
                          onClick={() => {
                            if (confirm("Are you sure you want to delete this product?")) {
                              deleteMutation.mutate(product.id);
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Info Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="p-6 rounded-xl bg-accent/5 border border-accent/20"
      >
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0">
            <Package className="w-6 h-6 text-accent" />
          </div>
          <div>
            <h3 className="font-display font-bold text-foreground mb-1">
              Website Integration
            </h3>
            <p className="text-sm text-muted-foreground">
              Products added here will automatically appear on the website's Services page under Garments Trading. 
              Each product will have a "Learn More" link that shows detailed information including 
              description, features, specifications, and pricing.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default GarmentWebsiteProducts;
