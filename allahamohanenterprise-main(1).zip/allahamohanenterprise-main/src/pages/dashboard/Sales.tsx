import { motion } from "framer-motion";
import { 
  DollarSign, 
  Plus, 
  TrendingUp, 
  TrendingDown,
  ShoppingCart,
  Receipt,
  ArrowUpRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const recentSales = [
  { id: 1, date: "2024-01-15", customer: "Local Market - Riazuddin", items: "Cotton Yarn (100kg)", amount: 35000, status: "completed" },
  { id: 2, date: "2024-01-15", customer: "Wholesale - Rahim Traders", items: "Mixed Jhut (500kg)", amount: 22500, status: "completed" },
  { id: 3, date: "2024-01-14", customer: "Factory Outlet - Prime", items: "Buttons (5000pcs)", amount: 2500, status: "pending" },
  { id: 4, date: "2024-01-14", customer: "Local Market - Karim", items: "Denim Fabric (50m)", amount: 9000, status: "completed" },
  { id: 5, date: "2024-01-13", customer: "Wholesale - National Traders", items: "Polyester Yarn (200kg)", amount: 56000, status: "completed" },
];

const Sales = () => {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Sales & Billing
          </h1>
          <p className="text-muted-foreground mt-1">
            Track sales, purchases, and financial transactions
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Receipt className="w-4 h-4" />
            New Purchase
          </Button>
          <Button variant="hero">
            <Plus className="w-4 h-4" />
            New Sale
          </Button>
        </div>
      </div>

      {/* Financial Summary */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Monthly Sales", value: "৳3,25,000", change: "+18%", positive: true, icon: TrendingUp },
          { label: "Monthly Purchases", value: "৳1,85,000", change: "+5%", positive: false, icon: ShoppingCart },
          { label: "Gross Profit", value: "৳1,40,000", change: "+24%", positive: true, icon: DollarSign },
          { label: "Pending Payments", value: "৳42,000", change: "5 invoices", positive: false, icon: Receipt },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-5 rounded-xl bg-card border border-border"
          >
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 ${stat.positive ? 'bg-success' : 'bg-warning'} rounded-lg flex items-center justify-center`}>
                <stat.icon className="w-5 h-5 text-primary-foreground" />
              </div>
              {stat.positive !== undefined && (
                <span className={`text-xs font-medium ${stat.positive ? 'text-success' : 'text-muted-foreground'}`}>
                  {stat.change}
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Profit/Loss Chart Placeholder */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-card rounded-xl border border-border p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-lg font-bold text-foreground">
            Monthly Performance
          </h2>
          <Button variant="ghost" size="sm">
            View Details
            <ArrowUpRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        <div className="h-64 flex items-center justify-center bg-secondary/30 rounded-lg">
          <div className="text-center">
            <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">Chart visualization will be displayed here</p>
            <p className="text-sm text-muted-foreground">Connect to backend for real data</p>
          </div>
        </div>
      </motion.div>

      {/* Recent Sales */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-card rounded-xl border border-border overflow-hidden"
      >
        <div className="p-6 border-b border-border">
          <h2 className="font-display text-lg font-bold text-foreground">
            Recent Sales
          </h2>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Items</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {recentSales.map((sale) => (
              <TableRow key={sale.id} className="cursor-pointer hover:bg-secondary/50">
                <TableCell className="font-medium">{sale.date}</TableCell>
                <TableCell>{sale.customer}</TableCell>
                <TableCell className="text-muted-foreground">{sale.items}</TableCell>
                <TableCell>
                  <Badge variant={sale.status === "completed" ? "default" : "secondary"}>
                    {sale.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-medium">৳{sale.amount.toLocaleString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </motion.div>
    </div>
  );
};

export default Sales;
