import { motion } from "framer-motion";
import { 
  Users, 
  Plus, 
  Search, 
  Phone,
  Mail,
  Shield,
  MoreVertical
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

const staff = [
  { id: 1, name: "Mohammad Hasan", role: "Manager", department: "Operations", phone: "+880 1711-XXXXXX", email: "hasan@allahamohan.com", status: "active" },
  { id: 2, name: "Fatima Begum", role: "Accountant", department: "Finance", phone: "+880 1812-XXXXXX", email: "fatima@allahamohan.com", status: "active" },
  { id: 3, name: "Abdul Karim", role: "Driver", department: "Transport", phone: "+880 1911-XXXXXX", email: "karim@allahamohan.com", status: "active" },
  { id: 4, name: "Rahim Uddin", role: "Driver", department: "Transport", phone: "+880 1611-XXXXXX", email: "rahim@allahamohan.com", status: "active" },
  { id: 5, name: "Salma Akter", role: "Sales Executive", department: "Sales", phone: "+880 1511-XXXXXX", email: "salma@allahamohan.com", status: "active" },
  { id: 6, name: "Jahangir Alam", role: "Warehouse Staff", department: "Inventory", phone: "+880 1811-XXXXXX", email: "jahangir@allahamohan.com", status: "on-leave" },
];

const roleColors: Record<string, string> = {
  Manager: "gradient-primary",
  Accountant: "bg-info",
  Driver: "bg-success",
  "Sales Executive": "bg-warning",
  "Warehouse Staff": "bg-secondary",
};

const Staff = () => {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Staff Management
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage employees, roles, and departments
          </p>
        </div>
        <Button variant="hero">
          <Plus className="w-4 h-4" />
          Add Staff
        </Button>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-4 gap-4">
        {[
          { label: "Total Staff", value: "6" },
          { label: "Active", value: "5" },
          { label: "On Leave", value: "1" },
          { label: "Departments", value: "4" },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-xl bg-card border border-border text-center"
          >
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search staff..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Staff Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        {staff.map((member, index) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-6 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-elegant transition-all duration-300"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 ${roleColors[member.role] || 'gradient-primary'} rounded-xl flex items-center justify-center text-primary-foreground font-bold`}>
                  {member.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{member.name}</h3>
                  <p className="text-sm text-muted-foreground">{member.role}</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="w-4 h-4" />
                {member.department}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="w-4 h-4" />
                {member.phone}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="w-4 h-4" />
                {member.email}
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <Badge
                variant={member.status === "active" ? "default" : "secondary"}
                className="capitalize"
              >
                {member.status}
              </Badge>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Staff;
