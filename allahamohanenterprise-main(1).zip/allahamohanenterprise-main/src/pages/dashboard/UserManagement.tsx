import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, Shield, ShieldCheck, User, Search, ShieldAlert, RefreshCw, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, AppRole } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";
import RoleBadge from "@/components/RoleBadge";
import { Skeleton } from "@/components/ui/skeleton";

interface UserWithRole {
  id: string;
  email: string;
  full_name: string | null;
  created_at: string;
  role: AppRole | null;
  role_id: string | null;
}

const UserManagement = () => {
  const navigate = useNavigate();
  const { role: currentUserRole, user: currentUser } = useAuth();
  const { canAccessModule } = usePermissions(currentUserRole);
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [updatingUserId, setUpdatingUserId] = useState<string | null>(null);

  // Check if current user is super_admin (can manage everyone) or admin (can manage non-admins)
  const isSuperAdmin = currentUserRole === "super_admin";
  const isAdmin = currentUserRole === "admin";
  
  // Only super_admin and admin can access user management
  if (!isSuperAdmin && !isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
        <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-xl font-bold text-foreground mb-2">Access Denied</h2>
        <p className="text-muted-foreground mb-4">Only Super Admin and Admin users can manage user roles.</p>
        <Button onClick={() => navigate("/dashboard")}>Go to Dashboard</Button>
      </div>
    );
  }

  const fetchUsers = async () => {
    setLoading(true);
    try {
      // Fetch profiles with roles using secure function with role-based email masking
      const { data: profilesData, error: profilesError } = await supabase.rpc("get_profiles_for_management");

      if (profilesError) throw profilesError;

      // Fetch role IDs separately for update operations
      const { data: roles, error: rolesError } = await supabase
        .from("user_roles")
        .select("id, user_id, role");

      if (rolesError) throw rolesError;

      // Map the data
      const usersWithRoles: UserWithRole[] = (profilesData || []).map((profile: any) => {
        const userRole = roles?.find((r) => r.user_id === profile.id);
        return {
          id: profile.id,
          email: profile.email || "N/A",
          full_name: profile.full_name,
          created_at: profile.created_at,
          role: profile.role as AppRole | null,
          role_id: userRole?.id || null,
        };
      });

      setUsers(usersWithRoles);
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("Failed to fetch users");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleRoleChange = async (userId: string, newRole: AppRole, currentRoleId: string | null, targetUserRole: AppRole | null) => {
    // Prevent self-demotion
    if (userId === currentUser?.id && newRole !== currentUserRole) {
      toast.error("You cannot change your own role. Ask another admin to change it.");
      return;
    }
    
    // Regular admins cannot modify super_admin or other admin roles
    if (!isSuperAdmin && (targetUserRole === "super_admin" || targetUserRole === "admin")) {
      toast.error("Only Super Admin can modify admin roles.");
      return;
    }
    
    // Regular admins cannot assign super_admin or admin roles
    if (!isSuperAdmin && (newRole === "super_admin" || newRole === "admin")) {
      toast.error("Only Super Admin can assign admin roles.");
      return;
    }

    setUpdatingUserId(userId);

    try {
      if (currentRoleId) {
        // Update existing role
        const { error } = await supabase
          .from("user_roles")
          .update({ role: newRole })
          .eq("id", currentRoleId);

        if (error) throw error;
      } else {
        // Insert new role
        const { error } = await supabase
          .from("user_roles")
          .insert({ user_id: userId, role: newRole });

        if (error) throw error;
      }

      toast.success(`Role updated to ${newRole}`);
      
      // Update local state
      setUsers((prev) =>
        prev.map((u) =>
          u.id === userId ? { ...u, role: newRole } : u
        )
      );
    } catch (error: any) {
      console.error("Error updating role:", error);
      toast.error(error.message || "Failed to update role");
    } finally {
      setUpdatingUserId(null);
    }
  };

  const filteredUsers = users.filter((user) => {
    const searchLower = searchQuery.toLowerCase();
    return (
      user.email.toLowerCase().includes(searchLower) ||
      (user.full_name?.toLowerCase() || "").includes(searchLower)
    );
  });

  const roleStats = {
    super_admin: users.filter((u) => u.role === "super_admin").length,
    admin: users.filter((u) => u.role === "admin").length,
    manager: users.filter((u) => u.role === "manager").length,
    staff: users.filter((u) => u.role === "staff").length,
    unassigned: users.filter((u) => !u.role).length,
  };
  
  // Check if user can modify a specific target user
  const canModifyUser = (targetRole: AppRole | null): boolean => {
    if (isSuperAdmin) return true;
    if (!isAdmin) return false;
    // Admin can only modify manager and staff
    return targetRole !== "super_admin" && targetRole !== "admin";
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            User Management
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage user roles and permissions
          </p>
        </div>
        <Button onClick={fetchUsers} variant="outline" className="gap-2">
          <RefreshCw className="w-4 h-4" />
          Refresh
        </Button>
      </div>

      {/* Role Stats */}
      <div className="grid sm:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center">
                <Crown className="w-6 h-6 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{roleStats.super_admin}</p>
                <p className="text-sm text-muted-foreground">Super Admins</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-red-500/10 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-red-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{roleStats.admin}</p>
                <p className="text-sm text-muted-foreground">Admins</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Shield className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{roleStats.manager}</p>
                <p className="text-sm text-muted-foreground">Managers</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center">
                <User className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{roleStats.staff}</p>
                <p className="text-sm text-muted-foreground">Staff</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                <Users className="w-6 h-6 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{users.length}</p>
                <p className="text-sm text-muted-foreground">Total Users</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Users Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                All Users
              </CardTitle>
              <div className="relative w-full sm:w-[300px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or email..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="flex-1">
                      <Skeleton className="h-4 w-[200px] mb-2" />
                      <Skeleton className="h-3 w-[150px]" />
                    </div>
                    <Skeleton className="h-8 w-[100px]" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="rounded-lg border border-border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead>User</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Current Role</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead className="text-right">Change Role</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No users found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                                <span className="text-sm font-bold text-primary">
                                  {(user.full_name || user.email)[0].toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <p className="font-medium text-foreground">
                                  {user.full_name || "No name"}
                                </p>
                                {user.id === currentUser?.id && (
                                  <Badge variant="outline" className="text-xs">You</Badge>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {user.email}
                          </TableCell>
                          <TableCell>
                            <RoleBadge role={user.role} />
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {new Date(user.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <Select
                              value={user.role || "staff"}
                              onValueChange={(value) =>
                                handleRoleChange(user.id, value as AppRole, user.role_id, user.role)
                              }
                              disabled={updatingUserId === user.id || !canModifyUser(user.role)}
                            >
                              <SelectTrigger className="w-[130px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {isSuperAdmin && (
                                  <SelectItem value="super_admin">
                                    <div className="flex items-center gap-2">
                                      <Crown className="w-4 h-4 text-purple-500" />
                                      Super Admin
                                    </div>
                                  </SelectItem>
                                )}
                                {isSuperAdmin && (
                                  <SelectItem value="admin">
                                    <div className="flex items-center gap-2">
                                      <ShieldCheck className="w-4 h-4 text-red-500" />
                                      Admin
                                    </div>
                                  </SelectItem>
                                )}
                                <SelectItem value="manager">
                                  <div className="flex items-center gap-2">
                                    <Shield className="w-4 h-4 text-blue-500" />
                                    Manager
                                  </div>
                                </SelectItem>
                                <SelectItem value="staff">
                                  <div className="flex items-center gap-2">
                                    <User className="w-4 h-4 text-green-500" />
                                    Staff
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Permission Reference */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Role Permissions Reference
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Module / Feature</TableHead>
                    <TableHead className="text-center">Super Admin</TableHead>
                    <TableHead className="text-center">Admin</TableHead>
                    <TableHead className="text-center">Manager</TableHead>
                    <TableHead className="text-center">Staff</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    { feature: "Dashboard", superAdmin: true, admin: true, manager: true, staff: true },
                    { feature: "Bus List (View)", superAdmin: true, admin: true, manager: true, staff: true },
                    { feature: "Add/Edit Bus", superAdmin: true, admin: true, manager: true, staff: false },
                    { feature: "Delete Bus", superAdmin: true, admin: true, manager: false, staff: false },
                    { feature: "Assign Bus", superAdmin: true, admin: true, manager: true, staff: false },
                    { feature: "Daily Service Entry", superAdmin: true, admin: true, manager: true, staff: true },
                    { feature: "Monthly Summary", superAdmin: true, admin: true, manager: true, staff: false },
                    { feature: "Billing & Invoice", superAdmin: true, admin: true, manager: true, staff: false },
                    { feature: "Payment Status", superAdmin: true, admin: true, manager: false, staff: false },
                    { feature: "Clients Management", superAdmin: true, admin: true, manager: true, staff: false },
                    { feature: "Staff/User Management", superAdmin: true, admin: true, manager: false, staff: false },
                    { feature: "Manage Admin Roles", superAdmin: true, admin: false, manager: false, staff: false },
                    { feature: "Settings", superAdmin: true, admin: true, manager: false, staff: false },
                  ].map((row, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{row.feature}</TableCell>
                      <TableCell className="text-center">
                        {row.superAdmin ? "✓" : "—"}
                      </TableCell>
                      <TableCell className="text-center">
                        {row.admin ? "✓" : "—"}
                      </TableCell>
                      <TableCell className="text-center">
                        {row.manager ? "✓" : "—"}
                      </TableCell>
                      <TableCell className="text-center">
                        {row.staff ? "✓" : "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default UserManagement;
