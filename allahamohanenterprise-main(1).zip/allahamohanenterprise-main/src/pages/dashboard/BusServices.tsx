import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { 
  Bus, 
  Plus, 
  List,
  UserCheck,
  Calendar,
  ClipboardList,
  Receipt,
  CreditCard,
  ArrowRight,
  Building2,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const subModules = [
  { 
    icon: Bus, 
    title: "Bus Products", 
    description: "Manage products shown on website", 
    path: "/dashboard/bus-services/products",
    color: "bg-accent/10 text-accent"
  },
  { 
    icon: Plus, 
    title: "Add Bus", 
    description: "Register new bus to the fleet", 
    path: "/dashboard/bus-services/add",
    color: "bg-primary/10 text-primary"
  },
  { 
    icon: List, 
    title: "Bus List", 
    description: "View and manage all buses", 
    path: "/dashboard/bus-services/list",
    color: "bg-info/10 text-info"
  },
  { 
    icon: UserCheck, 
    title: "Assign Bus", 
    description: "Assign buses to companies", 
    path: "/dashboard/bus-services/assign",
    color: "bg-success/10 text-success"
  },
  { 
    icon: Calendar, 
    title: "Daily Service Entry", 
    description: "Log daily bus service records", 
    path: "/dashboard/bus-services/daily-entry",
    color: "bg-warning/10 text-warning"
  },
  { 
    icon: ClipboardList, 
    title: "Monthly Summary", 
    description: "Auto-calculated monthly report", 
    path: "/dashboard/bus-services/monthly-summary",
    color: "bg-accent/10 text-accent-foreground"
  },
  { 
    icon: Receipt, 
    title: "Billing & Invoice", 
    description: "Generate monthly invoices", 
    path: "/dashboard/bus-services/billing",
    color: "bg-primary/10 text-primary"
  },
  { 
    icon: CreditCard, 
    title: "Payment Status", 
    description: "Track payments and dues", 
    path: "/dashboard/bus-services/payment-status",
    color: "bg-destructive/10 text-destructive"
  },
];

const quickStats = [
  { label: "Total Buses", value: "12", icon: Bus },
  { label: "Active Routes", value: "8", icon: Building2 },
  { label: "This Month Trips", value: "624", icon: CheckCircle2 },
  { label: "Pending Dues", value: "৳48,100", icon: AlertCircle },
];

const BusServices = () => {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
          Bus Services
        </h1>
        <p className="text-muted-foreground mt-1">
          Complete bus service management - fleet, scheduling, billing & payments
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickStats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-xl bg-card border border-border"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center">
                <stat.icon className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-xl font-bold text-foreground">{stat.value}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Sub-Modules Grid */}
      <div>
        <h2 className="font-display text-lg font-bold text-foreground mb-4">
          Manage Bus Services
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {subModules.map((module, index) => (
            <motion.div
              key={module.path}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.05 }}
            >
              <Link to={module.path}>
                <Card className="h-full hover:shadow-lg hover:border-primary/50 transition-all duration-300 group cursor-pointer">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className={`w-12 h-12 rounded-xl ${module.color} flex items-center justify-center`}>
                        <module.icon className="w-6 h-6" />
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                    </div>
                    <CardTitle className="text-base mt-3">{module.title}</CardTitle>
                    <CardDescription className="text-sm">
                      {module.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Access Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="p-6 rounded-xl bg-primary/5 border border-primary/20"
      >
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Bus className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="font-display font-bold text-foreground mb-1">
              Quick Tip
            </h3>
            <p className="text-sm text-muted-foreground">
              You can also access all sub-modules from the sidebar by clicking on "Bus Services" to expand the menu. 
              The sidebar menu stays expanded while you navigate between sub-modules.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default BusServices;
