import { useState } from "react";
import { motion } from "framer-motion";
import { 
  BarChart3, 
  Download, 
  Calendar,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Bus,
  Package,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import InventoryReport from "@/components/reports/InventoryReport";

const Reports = () => {
  const [isInventoryReportOpen, setIsInventoryReportOpen] = useState(false);
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Reports & Analytics
          </h1>
          <p className="text-muted-foreground mt-1">
            Business insights and performance metrics
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Calendar className="w-4 h-4" />
            This Month
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Revenue", value: "৳12,45,000", change: "+18%", positive: true, icon: DollarSign },
          { label: "Bus Service Revenue", value: "৳7,80,000", change: "+12%", positive: true, icon: Bus },
          { label: "Trading Revenue", value: "৳4,65,000", change: "+28%", positive: true, icon: Package },
          { label: "Active Clients", value: "48", change: "+6", positive: true, icon: Users },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-5 rounded-xl bg-card border border-border"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center">
                <stat.icon className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className={`flex items-center gap-1 text-xs font-medium ${stat.positive ? 'text-success' : 'text-destructive'}`}>
                {stat.positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {stat.change}
              </span>
            </div>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Revenue Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center bg-secondary/30 rounded-lg">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">Revenue chart visualization</p>
                  <p className="text-sm text-muted-foreground">Connect to backend for real data</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Service Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Service Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { label: "Bus Transportation", value: 62, color: "gradient-primary" },
                  { label: "Yarn Trading", value: 18, color: "bg-warning" },
                  { label: "Fabric Trading", value: 12, color: "bg-info" },
                  { label: "Other Materials", value: 8, color: "bg-success" },
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-foreground">{item.label}</span>
                      <span className="text-muted-foreground">{item.value}%</span>
                    </div>
                    <div className="h-2 bg-secondary rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${item.color} rounded-full transition-all duration-500`}
                        style={{ width: `${item.value}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Monthly Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="font-display">Monthly Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: "Bus Trips Completed", value: "624", subtext: "26 days × 24 avg/day" },
                { label: "New Clients Added", value: "3", subtext: "Fashion Hub, Prime, Textile" },
                { label: "Inventory Turnover", value: "2.4x", subtext: "Above target (2.0x)" },
                { label: "Payment Collection Rate", value: "94%", subtext: "৳4,32,800 collected" },
              ].map((item, index) => (
                <div key={item.label} className="text-center p-4 bg-secondary/30 rounded-lg">
                  <p className="text-3xl font-bold text-foreground mb-1">{item.value}</p>
                  <p className="text-sm font-medium text-foreground">{item.label}</p>
                  <p className="text-xs text-muted-foreground mt-1">{item.subtext}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Available Reports */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="font-display">Available Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { name: "Monthly Revenue Report", description: "Complete revenue breakdown by service", onClick: undefined },
                { name: "Bus Service Report", description: "Daily trips, routes, and billing summary", onClick: undefined },
                { name: "Inventory Report", description: "Stock levels, movements, and valuation", onClick: () => setIsInventoryReportOpen(true) },
                { name: "Client Statement", description: "Individual client transaction history", onClick: undefined },
                { name: "Profit & Loss Report", description: "Income, expenses, and net profit", onClick: undefined },
                { name: "Staff Performance", description: "Employee productivity and attendance", onClick: undefined },
              ].map((report) => (
                <div 
                  key={report.name} 
                  className={`p-4 border border-border rounded-lg hover:border-primary/30 hover:bg-secondary/30 transition-all ${report.onClick ? 'cursor-pointer' : 'cursor-default opacity-70'}`}
                  onClick={report.onClick}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">{report.name}</h4>
                      <p className="text-sm text-muted-foreground mt-1">{report.description}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8" disabled={!report.onClick}>
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Inventory Report Dialog */}
      <InventoryReport open={isInventoryReportOpen} onOpenChange={setIsInventoryReportOpen} />
    </div>
  );
};

export default Reports;
