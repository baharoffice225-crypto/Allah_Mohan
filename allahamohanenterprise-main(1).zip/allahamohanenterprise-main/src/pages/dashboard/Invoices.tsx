import { motion } from "framer-motion";
import { 
  FileText, 
  Plus, 
  Search, 
  Download,
  Send,
  CheckCircle2,
  Clock,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

const invoices = [
  { id: "INV-2024-001", date: "2024-01-15", client: "ABC Garments Ltd", type: "Bus Service", period: "January 2024", amount: 91000, status: "paid" },
  { id: "INV-2024-002", date: "2024-01-15", client: "Fashion Hub Ltd", type: "Bus Service", period: "January 2024", amount: 65000, status: "pending" },
  { id: "INV-2024-003", date: "2024-01-14", client: "XYZ Textiles", type: "Trading", period: "January 2024", amount: 125000, status: "paid" },
  { id: "INV-2024-004", date: "2024-01-14", client: "Prime Exports", type: "Bus Service", period: "January 2024", amount: 52000, status: "overdue" },
  { id: "INV-2024-005", date: "2024-01-13", client: "Global Apparels", type: "Bus Service", period: "January 2024", amount: 83200, status: "paid" },
  { id: "INV-2024-006", date: "2024-01-13", client: "Textile World", type: "Trading", period: "January 2024", amount: 45000, status: "pending" },
];

const statusConfig = {
  paid: { label: "Paid", variant: "default" as const, icon: CheckCircle2 },
  pending: { label: "Pending", variant: "secondary" as const, icon: Clock },
  overdue: { label: "Overdue", variant: "destructive" as const, icon: AlertCircle },
};

const Invoices = () => {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Invoices
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage and track all invoices and payments
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4" />
            Export
          </Button>
          <Button variant="hero">
            <Plus className="w-4 h-4" />
            Create Invoice
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-4 gap-4">
        {[
          { label: "Total Invoiced", value: "৳4,61,200", color: "gradient-primary" },
          { label: "Paid", value: "৳2,99,200", color: "bg-success" },
          { label: "Pending", value: "৳1,10,000", color: "bg-warning" },
          { label: "Overdue", value: "৳52,000", color: "bg-destructive" },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-xl bg-card border border-border"
          >
            <div className="flex items-center gap-3">
              <div className={`w-3 h-10 ${stat.color} rounded-full`} />
              <div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-xl font-bold text-foreground">{stat.value}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search invoices..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Invoices Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-card rounded-xl border border-border overflow-hidden"
      >
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Period</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoices.map((invoice) => {
              const status = statusConfig[invoice.status as keyof typeof statusConfig];
              const StatusIcon = status.icon;
              return (
                <TableRow key={invoice.id} className="cursor-pointer hover:bg-secondary/50">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{invoice.id}</span>
                    </div>
                  </TableCell>
                  <TableCell>{invoice.client}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{invoice.type}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{invoice.period}</TableCell>
                  <TableCell>
                    <Badge variant={status.variant} className="gap-1">
                      <StatusIcon className="w-3 h-3" />
                      {status.label}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium">৳{invoice.amount.toLocaleString()}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </motion.div>
    </div>
  );
};

export default Invoices;
