import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { CreditCard, Check, Clock, AlertTriangle, Search, Filter, ShieldAlert, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";

const payments = [
  { id: 1, company: "ABC Garments Ltd", invoiceId: "INV-2024-001", total: 37500, paid: 37500, due: 0, status: "paid", lastPayment: "2024-12-18" },
  { id: 2, company: "XYZ Fashion Industries", invoiceId: "INV-2024-002", total: 33600, paid: 20000, due: 13600, status: "partial", lastPayment: "2024-12-15" },
  { id: 3, company: "Fashion Hub Bangladesh", invoiceId: "INV-2024-003", total: 41600, paid: 41600, due: 0, status: "paid", lastPayment: "2024-12-19" },
  { id: 4, company: "Textile Masters Ltd", invoiceId: "INV-2024-004", total: 34500, paid: 0, due: 34500, status: "pending", lastPayment: "-" },
];

const PaymentStatus = () => {
  const navigate = useNavigate();
  const { role } = useAuth();
  const { canAccessBusSubModule } = usePermissions(role);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Payment Status is Admin only
  if (!canAccessBusSubModule("paymentStatus")) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
        <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-xl font-bold text-foreground mb-2">Access Denied</h2>
        <p className="text-muted-foreground mb-4">Only Admin users can access Payment Status.</p>
        <Button onClick={() => navigate("/dashboard/bus-services")}>Go to Bus Services</Button>
      </div>
    );
  }

  const formatBDT = (amount: number) => {
    return new Intl.NumberFormat("en-BD", {
      style: "currency",
      currency: "BDT",
      minimumFractionDigits: 0,
    })
      .format(amount)
      .replace("BDT", "৳");
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-success/20 text-success border-0">Paid</Badge>;
      case "partial":
        return <Badge className="bg-warning/20 text-warning border-0">Partial</Badge>;
      case "pending":
        return <Badge className="bg-destructive/20 text-destructive border-0">Due</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const filteredPayments = payments.filter((payment) => {
    const matchesSearch = payment.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || payment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalBilled = payments.reduce((acc, p) => acc + p.total, 0);
  const totalPaid = payments.reduce((acc, p) => acc + p.paid, 0);
  const totalDue = payments.reduce((acc, p) => acc + p.due, 0);

  const handleRecordPayment = (id: number) => {
    toast.success("Payment recorded successfully!");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Payment Status
          </h1>
          <p className="text-muted-foreground mt-1">
            Track paid, due, and partial payments
          </p>
        </div>
        <Badge variant="outline" className="bg-red-500/10 text-red-600 border-red-500/20">
          <Lock className="w-3 h-3 mr-1" />
          Admin Only
        </Badge>
      </div>

      <div className="grid sm:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{formatBDT(totalBilled)}</p>
                <p className="text-sm text-muted-foreground">Total Billed</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
                <Check className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{formatBDT(totalPaid)}</p>
                <p className="text-sm text-muted-foreground">Total Paid</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{formatBDT(totalDue)}</p>
                <p className="text-sm text-muted-foreground">Total Due</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-info/10 flex items-center justify-center">
                <Clock className="w-6 h-6 text-info" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {Math.round((totalPaid / totalBilled) * 100)}%
                </p>
                <p className="text-sm text-muted-foreground">Collection Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Payment Tracker</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by company name..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px]">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                  <SelectItem value="pending">Due</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Company</TableHead>
                    <TableHead>Invoice</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Paid</TableHead>
                    <TableHead className="text-right">Due</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayments.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell className="font-medium">{payment.company}</TableCell>
                      <TableCell>{payment.invoiceId}</TableCell>
                      <TableCell className="text-right">{formatBDT(payment.total)}</TableCell>
                      <TableCell className="text-right text-success">{formatBDT(payment.paid)}</TableCell>
                      <TableCell className="text-right text-destructive">
                        {payment.due > 0 ? formatBDT(payment.due) : "-"}
                      </TableCell>
                      <TableCell className="w-[120px]">
                        <Progress
                          value={(payment.paid / payment.total) * 100}
                          className="h-2"
                        />
                      </TableCell>
                      <TableCell>{getStatusBadge(payment.status)}</TableCell>
                      <TableCell className="text-right">
                        {payment.status !== "paid" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleRecordPayment(payment.id)}
                          >
                            Record Payment
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default PaymentStatus;
