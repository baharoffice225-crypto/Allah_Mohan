import { useState, useEffect, useMemo } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { 
  Bus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  MoreVertical, 
  Eye, 
  Lock,
  Save,
  X,
  RefreshCw,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface BusCategory {
  id: string;
  name: string;
}

interface BusData {
  id: string;
  bus_number: string;
  route: string;
  capacity: number;
  driver: string | null;
  status: string;
  category_id: string | null;
  bus_categories: BusCategory | null;
}

const BusList = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [buses, setBuses] = useState<BusData[]>([]);
  const [categories, setCategories] = useState<BusCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState(searchParams.get("category") || "all");
  const { role } = useAuth();
  const { canPerformAction, canAccessBusSubModule } = usePermissions(role);

  // Edit dialog state
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingBus, setEditingBus] = useState<BusData | null>(null);
  const [editFormData, setEditFormData] = useState({
    bus_number: "",
    route: "",
    capacity: "",
    driver: "",
    status: "active",
    category_id: "",
  });

  // Delete dialog state
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [deletingBusId, setDeletingBusId] = useState<string | null>(null);

  // View dialog state
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [viewingBus, setViewingBus] = useState<BusData | null>(null);

  const canEdit = canPerformAction("busServices", "edit");
  const canDelete = canPerformAction("busServices", "delete");
  const canAddBus = canAccessBusSubModule("addBus");

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  useEffect(() => {
    fetchBuses();
    fetchCategories();
  }, []);

  const fetchBuses = async () => {
    try {
      const { data, error } = await supabase
        .from("buses")
        .select(`
          *,
          bus_categories (
            id,
            name
          )
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setBuses(data || []);
    } catch (error: any) {
      toast.error("Failed to fetch buses: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from("bus_categories")
        .select("id, name")
        .eq("status", "active")
        .order("name");

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      console.error("Failed to fetch categories:", error.message);
    }
  };

  const filteredBuses = useMemo(() => {
    return buses.filter((bus) => {
      const matchesSearch =
        bus.bus_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
        bus.route.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (bus.driver?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false);
      const matchesStatus = statusFilter === "all" || bus.status === statusFilter;
      const matchesCategory = categoryFilter === "all" || 
        (categoryFilter === "none" && !bus.category_id) ||
        bus.category_id === categoryFilter;
      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [buses, searchQuery, statusFilter, categoryFilter]);

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter, categoryFilter]);

  // Pagination calculations
  const totalPages = Math.ceil(filteredBuses.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedBuses = filteredBuses.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(parseInt(value));
    setCurrentPage(1);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-success/20 text-success border-0">Active</Badge>;
      case "maintenance":
        return <Badge className="bg-warning/20 text-warning border-0">Maintenance</Badge>;
      case "inactive":
        return <Badge className="bg-destructive/20 text-destructive border-0">Inactive</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const handleView = (bus: BusData) => {
    setViewingBus(bus);
    setIsViewDialogOpen(true);
  };

  const handleEdit = (bus: BusData) => {
    if (!canEdit) {
      toast.error("You don't have permission to edit buses");
      return;
    }
    setEditingBus(bus);
    setEditFormData({
      bus_number: bus.bus_number,
      route: bus.route,
      capacity: bus.capacity.toString(),
      driver: bus.driver || "",
      status: bus.status,
      category_id: bus.category_id || "none",
    });
    setIsEditDialogOpen(true);
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBus) return;

    try {
      const { error } = await supabase
        .from("buses")
        .update({
          bus_number: editFormData.bus_number,
          route: editFormData.route,
          capacity: parseInt(editFormData.capacity),
          driver: editFormData.driver || null,
          status: editFormData.status,
          category_id: editFormData.category_id && editFormData.category_id !== "none" 
            ? editFormData.category_id 
            : null,
        })
        .eq("id", editingBus.id);

      if (error) throw error;

      toast.success("Bus updated successfully!");
      setIsEditDialogOpen(false);
      setEditingBus(null);
      fetchBuses();
    } catch (error: any) {
      toast.error("Failed to update bus: " + error.message);
    }
  };

  const handleDeleteClick = (busId: string) => {
    if (!canDelete) {
      toast.error("You don't have permission to delete buses");
      return;
    }
    setDeletingBusId(busId);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deletingBusId) return;

    try {
      const { error } = await supabase
        .from("buses")
        .delete()
        .eq("id", deletingBusId);

      if (error) throw error;

      toast.success("Bus deleted successfully!");
      setIsDeleteDialogOpen(false);
      setDeletingBusId(null);
      fetchBuses();
    } catch (error: any) {
      toast.error("Failed to delete bus: " + error.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Bus List
          </h1>
          <p className="text-muted-foreground mt-1">
            Total {buses.length} buses in fleet
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={fetchBuses} title="Refresh">
            <RefreshCw className="w-4 h-4" />
          </Button>
          {canAddBus && (
            <Button asChild className="gap-2">
              <Link to="/dashboard/bus-services/add">
                <Bus className="w-4 h-4" />
                Add New Bus
              </Link>
            </Button>
          )}
        </div>
      </div>

      {/* Search and Filter Section */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by bus number, route, or driver..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
              <Select 
                value={categoryFilter} 
                onValueChange={(value) => {
                  setCategoryFilter(value);
                  if (value === "all") {
                    searchParams.delete("category");
                  } else {
                    searchParams.set("category", value);
                  }
                  setSearchParams(searchParams);
                }}
              >
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="none">No Category</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bus className="w-5 h-5 text-primary" />
              All Buses
              {filteredBuses.length !== buses.length && (
                <Badge variant="secondary" className="ml-2">
                  {filteredBuses.length} of {buses.length}
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">Loading...</div>
            ) : buses.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No buses found. Add your first bus to get started.
              </div>
            ) : filteredBuses.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No buses match your search criteria.
              </div>
            ) : (
              <div className="space-y-4">
                <div className="rounded-lg border border-border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead>Bus Name</TableHead>
                        <TableHead>Bus Number</TableHead>
                        <TableHead>Route</TableHead>
                        <TableHead>Capacity</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedBuses.map((bus) => (
                        <TableRow key={bus.id}>
                          <TableCell className="font-medium">{bus.driver || "-"}</TableCell>
                          <TableCell>{bus.bus_number}</TableCell>
                          <TableCell>{bus.route}</TableCell>
                          <TableCell>{bus.capacity} seats</TableCell>
                          <TableCell>
                            {bus.bus_categories?.name ? (
                              <Badge variant="outline">{bus.bus_categories.name}</Badge>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>{getStatusBadge(bus.status)}</TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-popover">
                                <DropdownMenuItem onClick={() => handleView(bus)}>
                                  <Eye className="w-4 h-4 mr-2" />
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => handleEdit(bus)}
                                  disabled={!canEdit}
                                  className={!canEdit ? "opacity-50" : ""}
                                >
                                  {canEdit ? (
                                    <Edit className="w-4 h-4 mr-2" />
                                  ) : (
                                    <Lock className="w-4 h-4 mr-2" />
                                  )}
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => handleDeleteClick(bus.id)}
                                  disabled={!canDelete}
                                  className={!canDelete ? "opacity-50" : "text-destructive"}
                                >
                                  {canDelete ? (
                                    <Trash2 className="w-4 h-4 mr-2" />
                                  ) : (
                                    <Lock className="w-4 h-4 mr-2" />
                                  )}
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Pagination Controls */}
                {totalPages > 1 && (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span>Showing {startIndex + 1}-{Math.min(endIndex, filteredBuses.length)} of {filteredBuses.length}</span>
                      <Select value={itemsPerPage.toString()} onValueChange={handleItemsPerPageChange}>
                        <SelectTrigger className="w-[70px] h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5">5</SelectItem>
                          <SelectItem value="10">10</SelectItem>
                          <SelectItem value="20">20</SelectItem>
                          <SelectItem value="50">50</SelectItem>
                        </SelectContent>
                      </Select>
                      <span>per page</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="w-4 h-4" />
                        Previous
                      </Button>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: totalPages }, (_, i) => i + 1)
                          .filter(page => {
                            // Show first, last, current, and adjacent pages
                            return page === 1 || 
                                   page === totalPages || 
                                   Math.abs(page - currentPage) <= 1;
                          })
                          .map((page, index, array) => {
                            // Add ellipsis if there's a gap
                            const showEllipsisBefore = index > 0 && page - array[index - 1] > 1;
                            return (
                              <div key={page} className="flex items-center">
                                {showEllipsisBefore && (
                                  <span className="px-2 text-muted-foreground">...</span>
                                )}
                                <Button
                                  variant={currentPage === page ? "default" : "outline"}
                                  size="sm"
                                  className="w-8 h-8 p-0"
                                  onClick={() => handlePageChange(page)}
                                >
                                  {page}
                                </Button>
                              </div>
                            );
                          })}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                      >
                        Next
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bus className="w-5 h-5" />
              Bus Details
            </DialogTitle>
          </DialogHeader>
          {viewingBus && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-muted-foreground">Bus Name</Label>
                  <p className="font-medium">{viewingBus.driver || "-"}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Bus Number</Label>
                  <p className="font-medium">{viewingBus.bus_number}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Route</Label>
                  <p className="font-medium">{viewingBus.route}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Capacity</Label>
                  <p className="font-medium">{viewingBus.capacity} seats</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Category</Label>
                  <p className="font-medium">{viewingBus.bus_categories?.name || "-"}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">Status</Label>
                  <div className="mt-1">{getStatusBadge(viewingBus.status)}</div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Bus</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-busNumber">Bus Number *</Label>
                <Input
                  id="edit-busNumber"
                  value={editFormData.bus_number}
                  onChange={(e) => setEditFormData({ ...editFormData, bus_number: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-route">Route *</Label>
                <Input
                  id="edit-route"
                  value={editFormData.route}
                  onChange={(e) => setEditFormData({ ...editFormData, route: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-capacity">Capacity *</Label>
                <Input
                  id="edit-capacity"
                  type="number"
                  value={editFormData.capacity}
                  onChange={(e) => setEditFormData({ ...editFormData, capacity: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-driver">Bus Name</Label>
                <Input
                  id="edit-driver"
                  placeholder="e.g., Projapori"
                  value={editFormData.driver}
                  onChange={(e) => setEditFormData({ ...editFormData, driver: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select
                  value={editFormData.category_id}
                  onValueChange={(value) => setEditFormData({ ...editFormData, category_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No category selected</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select
                  value={editFormData.status}
                  onValueChange={(value) => setEditFormData({ ...editFormData, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="maintenance">Under Maintenance</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <Button type="submit" className="gap-2">
                <Save className="w-4 h-4" />
                Update
              </Button>
              <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)} className="gap-2">
                <X className="w-4 h-4" />
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Bus</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this bus? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default BusList;