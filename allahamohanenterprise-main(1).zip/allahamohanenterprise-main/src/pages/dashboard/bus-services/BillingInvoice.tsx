import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { FileText, Download, Send, Plus, Printer, ShieldAlert, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";

const invoices = [
  { id: "INV-2024-001", company: "ABC Garments Ltd", period: "Dec 2024", amount: 37500, status: "paid", date: "2024-12-20" },
  { id: "INV-2024-002", company: "XYZ Fashion Industries", period: "Dec 2024", amount: 33600, status: "pending", date: "2024-12-20" },
  { id: "INV-2024-003", company: "Fashion Hub Bangladesh", period: "Dec 2024", amount: 41600, status: "paid", date: "2024-12-20" },
  { id: "INV-2024-004", company: "Textile Masters Ltd", period: "Dec 2024", amount: 34500, status: "overdue", date: "2024-12-20" },
];

const BillingInvoice = () => {
  const navigate = useNavigate();
  const { role } = useAuth();
  const { canAccessBusSubModule, canPerformAction } = usePermissions(role);
  const [selectedMonth, setSelectedMonth] = useState("december-2024");

  // Billing is Admin and Manager only
  if (!canAccessBusSubModule("billing")) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
        <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-xl font-bold text-foreground mb-2">Access Denied</h2>
        <p className="text-muted-foreground mb-4">You don't have permission to access Billing & Invoice.</p>
        <Button onClick={() => navigate("/dashboard/bus-services")}>Go to Bus Services</Button>
      </div>
    );
  }

  const canCreate = canPerformAction("busServices", "create");

  const formatBDT = (amount: number) => {
    return new Intl.NumberFormat("en-BD", {
      style: "currency",
      currency: "BDT",
      minimumFractionDigits: 0,
    })
      .format(amount)
      .replace("BDT", "৳");
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-success/20 text-success border-0">Paid</Badge>;
      case "pending":
        return <Badge className="bg-warning/20 text-warning border-0">Pending</Badge>;
      case "overdue":
        return <Badge className="bg-destructive/20 text-destructive border-0">Overdue</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const handleGenerateInvoice = () => {
    if (!canCreate) {
      toast.error("You don't have permission to generate invoices");
      return;
    }
    toast.success("Invoice generated successfully!");
  };

  const totalAmount = invoices.reduce((acc, inv) => acc + inv.amount, 0);
  const paidAmount = invoices.filter((i) => i.status === "paid").reduce((acc, inv) => acc + inv.amount, 0);
  const pendingAmount = invoices.filter((i) => i.status !== "paid").reduce((acc, inv) => acc + inv.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
              Billing & Invoice
            </h1>
            <p className="text-muted-foreground mt-1">
              Generate and manage monthly invoices
            </p>
          </div>
          <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20 hidden sm:flex">
            <Lock className="w-3 h-3 mr-1" />
            Admin/Manager
          </Badge>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select month" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="december-2024">December 2024</SelectItem>
              <SelectItem value="november-2024">November 2024</SelectItem>
              <SelectItem value="october-2024">October 2024</SelectItem>
            </SelectContent>
          </Select>
          {canCreate && (
            <Button onClick={handleGenerateInvoice} className="gap-2">
              <Plus className="w-4 h-4" />
              Generate Invoice
            </Button>
          )}
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{formatBDT(totalAmount)}</p>
                <p className="text-sm text-muted-foreground">Total Billed</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{formatBDT(paidAmount)}</p>
                <p className="text-sm text-muted-foreground">Collected</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-warning/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{formatBDT(pendingAmount)}</p>
                <p className="text-sm text-muted-foreground">Outstanding</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Invoices - December 2024</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Invoice ID</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">{invoice.id}</TableCell>
                      <TableCell>{invoice.company}</TableCell>
                      <TableCell>{invoice.period}</TableCell>
                      <TableCell className="text-right font-semibold">{formatBDT(invoice.amount)}</TableCell>
                      <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="icon" title="Download">
                            <Download className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Print">
                            <Printer className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" title="Send">
                            <Send className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default BillingInvoice;
