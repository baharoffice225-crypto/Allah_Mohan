import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Bus, Building2, Save, MapPin, ShieldAlert, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";

const availableBuses = [
  { id: 1, number: "CTG-1234", capacity: 45 },
  { id: 2, number: "CTG-5678", capacity: 40 },
  { id: 3, number: "CTG-9012", capacity: 50 },
];

const companies = [
  { id: 1, name: "ABC Garments Ltd" },
  { id: 2, name: "XYZ Fashion Industries" },
  { id: 3, name: "Fashion Hub Bangladesh" },
  { id: 4, name: "Textile Masters Ltd" },
];

const currentAssignments = [
  { id: 1, bus: "CTG-1234", company: "ABC Garments Ltd", route: "Agrabad - EPZ", shift: "Morning" },
  { id: 2, bus: "CTG-5678", company: "XYZ Fashion Industries", route: "GEC - CEPZ", shift: "Day" },
  { id: 3, bus: "CTG-9012", company: "Fashion Hub Bangladesh", route: "Halishahar - EPZ", shift: "Evening" },
];

const AssignBus = () => {
  const navigate = useNavigate();
  const { role } = useAuth();
  const { canAccessBusSubModule } = usePermissions(role);
  const [formData, setFormData] = useState({
    bus: "",
    company: "",
    route: "",
    shift: "",
  });

  // Assign Bus is Admin and Manager only
  if (!canAccessBusSubModule("assignBus")) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
        <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-xl font-bold text-foreground mb-2">Access Denied</h2>
        <p className="text-muted-foreground mb-4">You don't have permission to assign buses.</p>
        <Button onClick={() => navigate("/dashboard/bus-services/list")}>Go to Bus List</Button>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Bus assigned successfully!");
    setFormData({ bus: "", company: "", route: "", shift: "" });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Assign Bus
          </h1>
          <p className="text-muted-foreground mt-1">
            Assign buses to companies or specific routes
          </p>
        </div>
        <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20 hidden sm:flex">
          <Lock className="w-3 h-3 mr-1" />
          Admin/Manager
        </Badge>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bus className="w-5 h-5 text-primary" />
                New Assignment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Select Bus *</Label>
                  <Select
                    value={formData.bus}
                    onValueChange={(value) => setFormData({ ...formData, bus: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a bus" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableBuses.map((bus) => (
                        <SelectItem key={bus.id} value={bus.number}>
                          {bus.number} ({bus.capacity} seats)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Assign to Company *</Label>
                  <Select
                    value={formData.company}
                    onValueChange={(value) => setFormData({ ...formData, company: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select company" />
                    </SelectTrigger>
                    <SelectContent>
                      {companies.map((company) => (
                        <SelectItem key={company.id} value={company.name}>
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Shift *</Label>
                  <Select
                    value={formData.shift}
                    onValueChange={(value) => setFormData({ ...formData, shift: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select shift" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">Morning (6 AM - 9 AM)</SelectItem>
                      <SelectItem value="day">Day (9 AM - 5 PM)</SelectItem>
                      <SelectItem value="evening">Evening (5 PM - 9 PM)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button type="submit" className="w-full gap-2 mt-4">
                  <Save className="w-4 h-4" />
                  Assign Bus
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-primary" />
                Current Assignments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {currentAssignments.map((assignment) => (
                  <div
                    key={assignment.id}
                    className="p-4 rounded-lg bg-secondary/50 border border-border"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-foreground">{assignment.bus}</span>
                      <Badge variant="outline">{assignment.shift}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{assignment.company}</p>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <MapPin className="w-3 h-3" />
                      {assignment.route}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default AssignBus;
