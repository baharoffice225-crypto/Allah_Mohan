import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Calendar, Bus, TrendingUp, Users, ShieldAlert, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";

const monthlySummary = [
  { bus: "CTG-1234", company: "ABC Garments Ltd", totalDays: 26, serviceDays: 25, passengers: 1050, rate: 1500, total: 37500 },
  { bus: "CTG-5678", company: "XYZ Fashion Industries", totalDays: 26, serviceDays: 24, passengers: 960, rate: 1400, total: 33600 },
  { bus: "CTG-9012", company: "Fashion Hub Bangladesh", totalDays: 26, serviceDays: 26, passengers: 1170, rate: 1600, total: 41600 },
  { bus: "CTG-3456", company: "Textile Masters Ltd", totalDays: 26, serviceDays: 23, passengers: 1012, rate: 1500, total: 34500 },
];

const MonthlyServiceSummary = () => {
  const navigate = useNavigate();
  const { role } = useAuth();
  const { canAccessBusSubModule } = usePermissions(role);
  const [selectedMonth, setSelectedMonth] = useState("december-2024");

  // Monthly Summary is Admin and Manager only
  if (!canAccessBusSubModule("monthlySummary")) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] text-center">
        <ShieldAlert className="w-16 h-16 text-destructive mb-4" />
        <h2 className="text-xl font-bold text-foreground mb-2">Access Denied</h2>
        <p className="text-muted-foreground mb-4">You don't have permission to access Monthly Summary.</p>
        <Button onClick={() => navigate("/dashboard/bus-services")}>Go to Bus Services</Button>
      </div>
    );
  }

  const totalServiceDays = monthlySummary.reduce((acc, s) => acc + s.serviceDays, 0);
  const totalPassengers = monthlySummary.reduce((acc, s) => acc + s.passengers, 0);
  const totalRevenue = monthlySummary.reduce((acc, s) => acc + s.total, 0);

  const formatBDT = (amount: number) => {
    return new Intl.NumberFormat("en-BD", {
      style: "currency",
      currency: "BDT",
      minimumFractionDigits: 0,
    })
      .format(amount)
      .replace("BDT", "৳");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
              Monthly Service Summary
            </h1>
            <p className="text-muted-foreground mt-1">
              Auto-calculated monthly service report
            </p>
          </div>
          <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20 hidden sm:flex">
            <Lock className="w-3 h-3 mr-1" />
            Admin/Manager
          </Badge>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select month" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="december-2024">December 2024</SelectItem>
              <SelectItem value="november-2024">November 2024</SelectItem>
              <SelectItem value="october-2024">October 2024</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">Export PDF</Button>
        </div>
      </div>

      <div className="grid sm:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Bus className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{monthlySummary.length}</p>
                <p className="text-sm text-muted-foreground">Active Buses</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
                <Calendar className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{totalServiceDays}</p>
                <p className="text-sm text-muted-foreground">Service Days</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-info/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-info" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{totalPassengers.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Total Passengers</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-warning/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{formatBDT(totalRevenue)}</p>
                <p className="text-sm text-muted-foreground">Total Revenue</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Service Summary - December 2024</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Bus</TableHead>
                    <TableHead>Company</TableHead>
                    <TableHead className="text-center">Working Days</TableHead>
                    <TableHead className="text-center">Service Days</TableHead>
                    <TableHead className="text-center">Passengers</TableHead>
                    <TableHead className="text-right">Daily Rate</TableHead>
                    <TableHead className="text-right">Total Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {monthlySummary.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{row.bus}</TableCell>
                      <TableCell>{row.company}</TableCell>
                      <TableCell className="text-center">{row.totalDays}</TableCell>
                      <TableCell className="text-center">{row.serviceDays}</TableCell>
                      <TableCell className="text-center">{row.passengers}</TableCell>
                      <TableCell className="text-right">{formatBDT(row.rate)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatBDT(row.total)}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="bg-primary/5 font-bold">
                    <TableCell colSpan={4}>Total</TableCell>
                    <TableCell className="text-center">{totalPassengers}</TableCell>
                    <TableCell className="text-right">-</TableCell>
                    <TableCell className="text-right text-primary">{formatBDT(totalRevenue)}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default MonthlyServiceSummary;
