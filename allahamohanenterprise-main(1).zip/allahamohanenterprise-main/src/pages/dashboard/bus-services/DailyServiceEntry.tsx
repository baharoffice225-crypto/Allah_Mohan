import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, Bus, Check, Clock, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { usePermissions } from "@/hooks/usePermissions";

const serviceEntries = [
  { id: 1, bus: "CTG-1234", company: "ABC Garments Ltd", completed: true, passengers: 42 },
  { id: 2, bus: "CTG-5678", company: "XYZ Fashion Industries", completed: true, passengers: 38 },
  { id: 3, bus: "CTG-9012", company: "Fashion Hub Bangladesh", completed: false, passengers: 0 },
  { id: 4, bus: "CTG-3456", company: "Textile Masters Ltd", completed: true, passengers: 44 },
];

const DailyServiceEntry = () => {
  const { role } = useAuth();
  const { canPerformAction } = usePermissions(role);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [entries, setEntries] = useState(serviceEntries);

  const canEdit = canPerformAction("busServices", "edit");

  const toggleService = (id: number) => {
    if (!canEdit) {
      toast.error("You don't have permission to modify service entries");
      return;
    }
    setEntries(
      entries.map((entry) =>
        entry.id === id ? { ...entry, completed: !entry.completed } : entry
      )
    );
  };

  const handleSave = () => {
    if (!canEdit) {
      toast.error("You don't have permission to save service entries");
      return;
    }
    toast.success("Daily service entries saved!");
  };

  const completedCount = entries.filter((e) => e.completed).length;
  const totalPassengers = entries
    .filter((e) => e.completed)
    .reduce((acc, e) => acc + e.passengers, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
            Daily Service Entry
          </h1>
          <p className="text-muted-foreground mt-1">
            Log daily bus service records
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-auto"
          />
        </div>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Bus className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{entries.length}</p>
                <p className="text-sm text-muted-foreground">Total Trips</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
                <Check className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{completedCount}</p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-info/10 flex items-center justify-center">
                <Clock className="w-6 h-6 text-info" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{totalPassengers}</p>
                <p className="text-sm text-muted-foreground">Total Passengers</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Service Log - {new Date(selectedDate).toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </CardTitle>
            <Button onClick={handleSave} className="gap-2" disabled={!canEdit}>
              <Save className="w-4 h-4" />
              Save Entries
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {entries.map((entry) => (
                <div
                  key={entry.id}
                  className={`p-4 rounded-lg border transition-colors ${
                    entry.completed
                      ? "bg-success/5 border-success/20"
                      : "bg-muted/50 border-border"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Checkbox
                        checked={entry.completed}
                        onCheckedChange={() => toggleService(entry.id)}
                        disabled={!canEdit}
                      />
                      <div>
                        <p className="font-semibold text-foreground">{entry.bus}</p>
                        <p className="text-sm text-muted-foreground">{entry.company}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {entry.completed && (
                        <div className="text-right">
                          <p className="text-sm font-medium text-foreground">
                            {entry.passengers} passengers
                          </p>
                        </div>
                      )}
                      <Badge
                        className={
                          entry.completed
                            ? "bg-success/20 text-success border-0"
                            : "bg-muted text-muted-foreground border-0"
                        }
                      >
                        {entry.completed ? "Completed" : "Pending"}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default DailyServiceEntry;
