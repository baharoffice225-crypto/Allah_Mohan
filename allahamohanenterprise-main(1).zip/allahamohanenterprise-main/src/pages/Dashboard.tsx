import { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "@/components/dashboard/Sidebar";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import ChatBot from "@/components/chat/ChatBot";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import RoleBadge from "@/components/RoleBadge";

const Dashboard = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { role } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isCollapsed={sidebarCollapsed} setIsCollapsed={setSidebarCollapsed} />
      
      <div
        className={cn(
          "transition-all duration-300 pb-20 lg:pb-0",
          sidebarCollapsed ? "lg:ml-20" : "lg:ml-[280px]"
        )}
      >
        <DashboardHeader />
        <main className="p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
      
      {/* AI Customer Support ChatBot */}
      <ChatBot />
    </div>
  );
};

export default Dashboard;
