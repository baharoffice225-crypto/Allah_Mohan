import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Bus, CheckCircle, Phone, Clock, MapPin, Shield, Users, Star, ArrowRight, ChevronLeft, ChevronRight, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/landing/Header";
import Footer from "@/components/landing/Footer";

interface BusProduct {
  id: string;
  name: string;
  description: string | null;
  short_description: string | null;
  features: string[];
  specifications: Record<string, string>;
  price: number;
  price_unit: string;
  category: string;
  image_url: string | null;
  gallery_images: string[];
  is_featured: boolean;
  is_active: boolean;
}

const ServiceDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const { data: product, isLoading, error } = useQuery({
    queryKey: ["bus-product", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bus_products")
        .select("*")
        .eq("id", id)
        .eq("is_active", true)
        .maybeSingle();
      
      if (error) throw error;
      return data as BusProduct | null;
    },
    enabled: !!id,
  });

  // Fetch related products
  const { data: relatedProducts = [] } = useQuery({
    queryKey: ["related-products", product?.category, id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bus_products")
        .select("*")
        .eq("is_active", true)
        .neq("id", id)
        .limit(3);
      
      if (error) throw error;
      return data as BusProduct[];
    },
    enabled: !!product,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-20">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-20">
          <div className="container mx-auto px-4">
            <div className="text-center py-20">
              <h1 className="font-display text-2xl font-bold text-foreground mb-4">
                Service Not Found
              </h1>
              <p className="text-muted-foreground mb-8">
                The service you're looking for doesn't exist or has been removed.
              </p>
              <Link to="/services">
                <Button className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back to Services
                </Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const specifications = product.specifications || {};
  const allImages = [product.image_url, ...(product.gallery_images || [])].filter(Boolean) as string[];

  const handlePrevImage = () => {
    setSelectedImageIndex((prev) => (prev === 0 ? allImages.length - 1 : prev - 1));
  };

  const handleNextImage = () => {
    setSelectedImageIndex((prev) => (prev === allImages.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-24 pb-20">
        {/* Breadcrumb */}
        <section className="py-4 border-b border-border">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Link to="/" className="hover:text-primary transition-colors">Home</Link>
              <span>/</span>
              <Link to="/services" className="hover:text-primary transition-colors">Services</Link>
              <span>/</span>
              <span className="text-foreground">{product.name}</span>
            </div>
          </div>
        </section>

        {/* Hero Section */}
        <section className="py-12 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto px-4">
            <Link to="/services">
              <Button variant="ghost" size="sm" className="gap-2 mb-6">
                <ArrowLeft className="w-4 h-4" />
                Back to Services
              </Button>
            </Link>
            
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              {/* Left - Image/Icon */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-4"
              >
                {/* Main Image */}
                <div 
                  className="aspect-video rounded-3xl bg-gradient-to-br from-primary/20 via-primary/10 to-primary/5 border border-primary/20 flex items-center justify-center relative overflow-hidden cursor-pointer group"
                  onClick={() => allImages.length > 0 && setLightboxOpen(true)}
                >
                  {allImages.length > 0 ? (
                    <img 
                      src={allImages[selectedImageIndex]} 
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <>
                      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent" />
                      <Bus className="w-32 h-32 text-primary/30" />
                    </>
                  )}
                  {product.is_featured && (
                    <div className="absolute top-4 right-4">
                      <Badge className="gap-1 bg-warning text-warning-foreground">
                        <Star className="w-3 h-3" />
                        Featured
                      </Badge>
                    </div>
                  )}
                  {allImages.length > 1 && (
                    <>
                      <button
                        onClick={(e) => { e.stopPropagation(); handlePrevImage(); }}
                        className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <ChevronLeft className="w-6 h-6" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleNextImage(); }}
                        className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <ChevronRight className="w-6 h-6" />
                      </button>
                    </>
                  )}
                </div>

                {/* Thumbnail Gallery */}
                {allImages.length > 1 && (
                  <div className="flex gap-2 overflow-x-auto pb-2">
                    {allImages.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedImageIndex(index)}
                        className={`flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                          selectedImageIndex === index 
                            ? "border-primary ring-2 ring-primary/20" 
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <img 
                          src={image} 
                          alt={`${product.name} ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </motion.div>

              {/* Right - Content */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <Badge variant="secondary" className="mb-4 capitalize">
                  {product.category}
                </Badge>
                <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
                  {product.name}
                </h1>
                <p className="text-lg text-muted-foreground mb-6">
                  {product.short_description}
                </p>

                {/* Price */}
                <div className="flex items-baseline gap-2 mb-8">
                  <span className="text-4xl font-bold text-primary">
                    ৳{product.price.toLocaleString()}
                  </span>
                  <span className="text-lg text-muted-foreground">
                    /{product.price_unit}
                  </span>
                </div>

                {/* Quick Icons */}
                <div className="flex gap-3 mb-8">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-primary" />
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Clock className="w-6 h-6 text-primary" />
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                </div>

                {/* CTA Buttons */}
                <div className="flex flex-wrap gap-4">
                  <a href="/#contact">
                    <Button size="lg" className="gap-2">
                      <Phone className="w-5 h-5" />
                      Contact for Booking
                    </Button>
                  </a>
                  <a href="/#contact">
                    <Button size="lg" variant="outline" className="gap-2">
                      Get a Quote
                    </Button>
                  </a>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Description & Features */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-3 gap-12">
              {/* Description */}
              <motion.div 
                className="lg:col-span-2"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="font-display text-2xl font-bold text-foreground mb-6">
                  About This Service
                </h2>
                <div className="prose prose-lg max-w-none text-muted-foreground">
                  <p>{product.description || product.short_description}</p>
                </div>

                {/* Features */}
                {product.features && product.features.length > 0 && (
                  <div className="mt-12">
                    <h3 className="font-display text-xl font-bold text-foreground mb-6">
                      Key Features
                    </h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {product.features.map((feature, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -10 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-start gap-3 p-4 rounded-xl bg-card border border-border"
                        >
                          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <CheckCircle className="w-4 h-4 text-primary" />
                          </div>
                          <span className="text-foreground">{feature}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>

              {/* Specifications Sidebar */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <Card className="sticky top-24">
                  <CardContent className="p-6">
                    <h3 className="font-display text-lg font-bold text-foreground mb-6">
                      Specifications
                    </h3>
                    <div className="space-y-4">
                      {Object.entries(specifications).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-start border-b border-border pb-3 last:border-0">
                          <span className="text-muted-foreground capitalize">
                            {key.replace(/_/g, ' ')}
                          </span>
                          <span className="font-medium text-foreground text-right max-w-[60%]">
                            {value}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-8 p-4 rounded-xl bg-primary/5 border border-primary/20">
                      <h4 className="font-semibold text-foreground mb-2">Need Help?</h4>
                      <p className="text-sm text-muted-foreground mb-4">
                        Contact us for customized solutions
                      </p>
                      <a href="/#contact">
                        <Button className="w-full gap-2">
                          <Phone className="w-4 h-4" />
                          Get in Touch
                        </Button>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <section className="py-16 bg-gradient-to-b from-background to-secondary/20">
            <div className="container mx-auto px-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-12"
              >
                <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-4">
                  Other Services
                </h2>
                <p className="text-muted-foreground">
                  Explore more of our transportation solutions
                </p>
              </motion.div>

              <div className="grid md:grid-cols-3 gap-6">
                {relatedProducts.map((relatedProduct, index) => (
                  <motion.div
                    key={relatedProduct.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link to={`/services/bus/${relatedProduct.id}`}>
                      <Card className="h-full hover:shadow-lg hover:border-primary/50 transition-all duration-300 group cursor-pointer">
                        <CardContent className="p-6">
                          <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center mb-4">
                            <Bus className="w-6 h-6 text-primary-foreground" />
                          </div>
                          <h3 className="font-display text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                            {relatedProduct.name}
                          </h3>
                          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                            {relatedProduct.short_description}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-primary">
                              ৳{relatedProduct.price.toLocaleString()}/{relatedProduct.price_unit}
                            </span>
                            <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CTA */}
        <section className="py-16">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-4">
                Ready to Get Started?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                Contact us today to discuss your transportation requirements and get a customized solution.
              </p>
              <a href="/#contact">
                <Button size="lg" className="gap-2">
                  <Phone className="w-5 h-5" />
                  Contact Us Now
                </Button>
              </a>
            </motion.div>
          </div>
        </section>

        {/* Lightbox */}
        <AnimatePresence>
          {lightboxOpen && allImages.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-center justify-center p-4"
              onClick={() => setLightboxOpen(false)}
            >
              <button
                className="absolute top-4 right-4 w-12 h-12 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                onClick={() => setLightboxOpen(false)}
              >
                <X className="w-6 h-6" />
              </button>
              <button
                className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                onClick={(e) => { e.stopPropagation(); handlePrevImage(); }}
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
                onClick={(e) => { e.stopPropagation(); handleNextImage(); }}
              >
                <ChevronRight className="w-6 h-6" />
              </button>
              <img
                src={allImages[selectedImageIndex]}
                alt={product.name}
                className="max-w-full max-h-[80vh] object-contain rounded-xl"
                onClick={(e) => e.stopPropagation()}
              />
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {allImages.map((_, index) => (
                  <button
                    key={index}
                    onClick={(e) => { e.stopPropagation(); setSelectedImageIndex(index); }}
                    className={`w-2 h-2 rounded-full transition-all ${
                      selectedImageIndex === index ? "bg-primary w-6" : "bg-muted-foreground/50"
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  );
};

export default ServiceDetail;
