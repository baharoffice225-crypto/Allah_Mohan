import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Bus, Package, MapPin, Clock, CheckCircle, Phone, ArrowRight, Shield, Truck, Users, Boxes, Scissors, Factory, Star, Search, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import Header from "@/components/landing/Header";
import Footer from "@/components/landing/Footer";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface BusProduct {
  id: string;
  name: string;
  short_description: string | null;
  features: string[];
  price: number;
  price_unit: string;
  category: string;
  is_featured: boolean;
  image_url: string | null;
}

interface GarmentProduct {
  id: string;
  name: string;
  short_description: string | null;
  features: string[];
  price: number;
  price_unit: string;
  category: string;
  is_featured: boolean;
  image_url: string | null;
}

const busFaqs = [
  {
    question: "What is the minimum contract period for bus services?",
    answer: "Our standard contract is for a minimum of 1 month (26 working days). We also offer quarterly and annual contracts with special discounts for long-term partnerships.",
  },
  {
    question: "How do you handle bus breakdowns or emergencies?",
    answer: "We maintain backup buses for emergencies. In case of any breakdown, we immediately deploy a replacement bus to ensure your employees are not stranded. Our team is available 24/7 for emergency support.",
  },
  {
    question: "Can we customize the pickup and drop routes?",
    answer: "Yes, absolutely! We work with you to design custom routes based on your employees' locations and your factory/office address. Routes can be modified with prior notice.",
  },
  {
    question: "What safety measures do you have in place?",
    answer: "All our buses are GPS-tracked, regularly maintained, and driven by licensed, experienced drivers. We also have insurance coverage for all passengers and conduct regular safety training for our drivers.",
  },
  {
    question: "How is the billing done for bus services?",
    answer: "Billing is done monthly based on the agreed service days (typically 26 days). We provide detailed invoices with service logs. Payment can be made via bank transfer or check within 15 days of invoice.",
  },
];

const garmentsFaqs = [
  {
    question: "What types of garments materials do you supply?",
    answer: "We supply a wide range including yarn (cotton, polyester, mixed), buttons (plastic, metal, shell), zippers, jhut (fabric waste), thread, buckles, hooks, and other garments accessories.",
  },
  {
    question: "Do you offer bulk discounts for large orders?",
    answer: "Yes, we offer competitive wholesale prices for bulk orders. The discount percentage increases with order volume. Contact us for a customized quote based on your requirements.",
  },
  {
    question: "Where do you source your materials from?",
    answer: "Our materials are sourced directly from reputable garments factories in Bangladesh. We have long-standing relationships with major factories which allows us to get quality surplus materials at competitive prices.",
  },
  {
    question: "What is your return/exchange policy?",
    answer: "We accept returns or exchanges within 7 days of delivery if the materials don't match the agreed specifications. Quality inspection is done before dispatch, but we stand behind our products.",
  },
  {
    question: "Do you provide delivery services?",
    answer: "Yes, we provide delivery within Dhaka and nearby industrial areas. Delivery charges may apply based on location and order size. For large orders, we offer free delivery.",
  },
];

const ServicesPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedBusCategory, setSelectedBusCategory] = useState<string>("all");
  const [selectedGarmentCategory, setSelectedGarmentCategory] = useState<string>("all");

  // Fetch bus products from database
  const { data: busProducts = [], isLoading: busLoading } = useQuery({
    queryKey: ["bus-products-public"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bus_products")
        .select("id, name, short_description, features, price, price_unit, category, is_featured, image_url")
        .eq("is_active", true)
        .order("display_order", { ascending: true });
      
      if (error) throw error;
      return data as BusProduct[];
    },
  });

  // Fetch garment products from database
  const { data: garmentProducts = [], isLoading: garmentLoading } = useQuery({
    queryKey: ["garment-products-public"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("garment_website_products")
        .select("id, name, short_description, features, price, price_unit, category, is_featured, image_url")
        .eq("is_active", true)
        .order("display_order", { ascending: true });
      
      if (error) throw error;
      return data as GarmentProduct[];
    },
  });

  // Get unique categories
  const busCategories = useMemo(() => {
    const cats = new Set(busProducts.map(p => p.category));
    return ["all", ...Array.from(cats)];
  }, [busProducts]);

  const garmentCategories = useMemo(() => {
    const cats = new Set(garmentProducts.map(p => p.category));
    return ["all", ...Array.from(cats)];
  }, [garmentProducts]);

  // Filter products based on search and category
  const filteredBusProducts = useMemo(() => {
    return busProducts.filter(product => {
      const matchesSearch = searchQuery === "" || 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.short_description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedBusCategory === "all" || product.category === selectedBusCategory;
      return matchesSearch && matchesCategory;
    });
  }, [busProducts, searchQuery, selectedBusCategory]);

  const filteredGarmentProducts = useMemo(() => {
    return garmentProducts.filter(product => {
      const matchesSearch = searchQuery === "" || 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.short_description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedGarmentCategory === "all" || product.category === selectedGarmentCategory;
      return matchesSearch && matchesCategory;
    });
  }, [garmentProducts, searchQuery, selectedGarmentCategory]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-24 pb-20">
        {/* Page Header */}
        <section className="py-12 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                Our Services
              </span>
              <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
                Comprehensive Business Solutions
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                From corporate transportation to garments material trading, we provide reliable and efficient services for your business needs.
              </p>
            </motion.div>

            {/* Search Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="max-w-xl mx-auto mt-8"
            >
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-10 py-6 text-base rounded-full border-border focus:border-primary"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-5 h-5" />
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Bus Services Section */}
        <section id="bus-service" className="py-16">
          <div className="container mx-auto px-4">
            {/* Section Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center gap-4 mb-8"
            >
              <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center shadow-lg">
                <Bus className="w-8 h-8 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
                  Bus Transportation Services
                </h2>
                <p className="text-muted-foreground">
                  Professional corporate transportation solutions
                </p>
              </div>
            </motion.div>

            {/* Category Filter */}
            {busCategories.length > 2 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="flex flex-wrap gap-2 mb-8"
              >
                {busCategories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedBusCategory(category)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      selectedBusCategory === category
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    }`}
                  >
                    {category === "all" ? "All" : category.charAt(0).toUpperCase() + category.slice(1)}
                  </button>
                ))}
              </motion.div>
            )}

            {/* Products Grid */}
            {busLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : filteredBusProducts.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredBusProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-lg hover:border-primary/50 transition-all duration-300 group relative overflow-hidden">
                      {product.is_featured && (
                        <div className="absolute top-3 right-3 z-10">
                          <Badge className="gap-1 bg-warning text-warning-foreground">
                            <Star className="w-3 h-3" />
                            Featured
                          </Badge>
                        </div>
                      )}
                      <CardContent className="p-6">
                        <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                          <Bus className="w-6 h-6 text-primary-foreground" />
                        </div>
                        <Badge variant="secondary" className="mb-3 capitalize">
                          {product.category}
                        </Badge>
                        <h3 className="font-display text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                          {product.name}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {product.short_description}
                        </p>
                        
                        {/* Features preview */}
                        <div className="space-y-2 mb-4">
                          {product.features.slice(0, 3).map((feature, i) => (
                            <div key={i} className="flex items-center gap-2 text-sm">
                              <CheckCircle className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                              <span className="text-muted-foreground truncate">{feature}</span>
                            </div>
                          ))}
                          {product.features.length > 3 && (
                            <span className="text-xs text-muted-foreground">
                              +{product.features.length - 3} more features
                            </span>
                          )}
                        </div>

                        {/* Price */}
                        <div className="flex items-baseline gap-1 mb-4">
                          <span className="text-2xl font-bold text-primary">
                            ৳{product.price.toLocaleString()}
                          </span>
                          <span className="text-sm text-muted-foreground">
                            /{product.price_unit}
                          </span>
                        </div>

                        <Link to={`/services/bus/${product.id}`}>
                          <Button className="w-full gap-2 group-hover:bg-primary/90">
                            Learn More
                            <ArrowRight className="w-4 h-4" />
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              /* Fallback static content when no products in DB */
              <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
                {/* Bus Service Card */}
                <motion.div
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                  className="group"
                >
                  <div className="h-full p-8 lg:p-10 rounded-3xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-elegant overflow-hidden relative">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-primary/10 to-transparent rounded-bl-full" />
                    <div className="flex items-center gap-4 mb-6 relative">
                      <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                        <Bus className="w-8 h-8 text-primary-foreground" />
                      </div>
                    </div>
                    <h2 className="font-display text-2xl lg:text-3xl font-bold text-foreground mb-4">
                      Bus Transportation Service
                    </h2>
                    <p className="text-muted-foreground mb-6 leading-relaxed">
                      Reliable corporate bus transportation services with monthly contracts.
                    </p>
                    <div className="flex flex-wrap gap-2 mb-8">
                      {["GPS Tracking", "AC/Non-AC Options", "Monthly Billing", "Dedicated Support"].map((item) => (
                        <span key={item} className="px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground text-xs font-medium">
                          {item}
                        </span>
                      ))}
                    </div>
                    <a href="#contact">
                      <Button className="gap-2">
                        <Phone className="w-4 h-4" />
                        Inquire Now
                      </Button>
                    </a>
                  </div>
                </motion.div>

                {/* Info card */}
                <motion.div
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="p-8 rounded-3xl bg-primary/5 border border-primary/20 flex flex-col justify-center"
                >
                  <h3 className="font-display text-xl font-bold text-foreground mb-4">
                    No products listed yet
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    Bus service products will appear here once they are added through the admin portal.
                    Contact us for more information about our services.
                  </p>
                  <a href="/#contact">
                    <Button variant="outline" className="gap-2">
                      <Phone className="w-4 h-4" />
                      Contact Us
                    </Button>
                  </a>
                </motion.div>
              </div>
            )}
          </div>
        </section>

        {/* Garments Service Section */}
        <section id="garments-service" className="py-16 bg-gradient-to-b from-background to-secondary/10">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center gap-4 mb-8"
            >
              <div className="w-16 h-16 rounded-2xl gradient-accent flex items-center justify-center shadow-lg">
                <Package className="w-8 h-8 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-display text-2xl lg:text-3xl font-bold text-foreground">
                  Garments Product Trading
                </h2>
                <p className="text-muted-foreground">
                  Quality materials at wholesale prices
                </p>
              </div>
            </motion.div>

            {/* Category Filter */}
            {garmentCategories.length > 2 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="flex flex-wrap gap-2 mb-8"
              >
                {garmentCategories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedGarmentCategory(category)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      selectedGarmentCategory === category
                        ? "bg-accent text-white"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    }`}
                  >
                    {category === "all" ? "All" : category.charAt(0).toUpperCase() + category.slice(1)}
                  </button>
                ))}
              </motion.div>
            )}

            {/* Products Grid */}
            {garmentLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : filteredGarmentProducts.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredGarmentProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-lg hover:border-accent/50 transition-all duration-300 group relative overflow-hidden">
                      {product.is_featured && (
                        <div className="absolute top-3 right-3 z-10">
                          <Badge className="gap-1 bg-warning text-warning-foreground">
                            <Star className="w-3 h-3" />
                            Featured
                          </Badge>
                        </div>
                      )}
                      <CardContent className="p-6">
                        {product.image_url ? (
                          <div className="w-full h-32 rounded-xl overflow-hidden mb-4 bg-muted">
                            <img
                              src={product.image_url}
                              alt={product.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          </div>
                        ) : (
                          <div className="w-12 h-12 rounded-xl gradient-accent flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                            <Package className="w-6 h-6 text-primary-foreground" />
                          </div>
                        )}
                        <Badge variant="secondary" className="mb-3 capitalize">
                          {product.category}
                        </Badge>
                        <h3 className="font-display text-lg font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                          {product.name}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {product.short_description}
                        </p>
                        
                        {/* Features preview */}
                        <div className="space-y-2 mb-4">
                          {product.features.slice(0, 3).map((feature, i) => (
                            <div key={i} className="flex items-center gap-2 text-sm">
                              <CheckCircle className="w-3.5 h-3.5 text-accent flex-shrink-0" />
                              <span className="text-muted-foreground truncate">{feature}</span>
                            </div>
                          ))}
                          {product.features.length > 3 && (
                            <span className="text-xs text-muted-foreground">
                              +{product.features.length - 3} more features
                            </span>
                          )}
                        </div>

                        {/* Price */}
                        <div className="flex items-baseline gap-1 mb-4">
                          <span className="text-2xl font-bold text-accent">
                            ৳{product.price.toLocaleString()}
                          </span>
                          <span className="text-sm text-muted-foreground">
                            /{product.price_unit}
                          </span>
                        </div>

                        <Link to={`/services/garment/${product.id}`}>
                          <Button variant="outline" className="w-full gap-2 group-hover:border-accent group-hover:text-accent">
                            Learn More
                            <ArrowRight className="w-4 h-4" />
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              /* Fallback static content when no products in DB */
              <div className="p-8 lg:p-10 rounded-3xl bg-card border border-border hover:border-accent/30 transition-all duration-300 hover:shadow-elegant overflow-hidden relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-accent/10 to-transparent rounded-bl-full" />
                
                <div className="grid lg:grid-cols-2 gap-8">
                  <div>
                    <p className="text-muted-foreground mb-6 leading-relaxed">
                      Quality garments materials sourced directly from factories. We trade in yarn, 
                      buttons, jhut, fabric, and other textile materials at competitive wholesale prices.
                    </p>

                    <div className="space-y-4 mb-8">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                          <Package className="w-4 h-4 text-accent" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">Yarn & Thread</h4>
                          <p className="text-sm text-muted-foreground">Cotton, polyester, and mixed yarn in various counts</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                          <Boxes className="w-4 h-4 text-accent" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">Buttons & Accessories</h4>
                          <p className="text-sm text-muted-foreground">Zippers, buttons, buckles, and other trims</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                          <Scissors className="w-4 h-4 text-accent" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">Fabric & Jhut</h4>
                          <p className="text-sm text-muted-foreground">Quality fabric waste and surplus materials</p>
                        </div>
                      </div>
                    </div>

                    <a href="/#contact">
                      <Button className="gap-2">
                        <Phone className="w-4 h-4" />
                        Inquire Now
                      </Button>
                    </a>
                  </div>

                  <div className="flex flex-col gap-4">
                    <div className="p-4 rounded-xl bg-accent/5 border border-accent/10">
                      <div className="flex items-center gap-2 mb-2">
                        <Factory className="w-5 h-5 text-accent" />
                        <span className="font-semibold text-foreground">Factory Direct</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Materials sourced directly from reputable garments factories
                      </p>
                    </div>
                    <div className="p-4 rounded-xl bg-accent/5 border border-accent/10">
                      <div className="flex items-center gap-2 mb-2">
                        <Truck className="w-5 h-5 text-accent" />
                        <span className="font-semibold text-foreground">Delivery Available</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Delivery within Dhaka and nearby industrial areas
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>


        {/* FAQ Section */}
        <section className="py-16 bg-gradient-to-b from-secondary/10 to-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center max-w-3xl mx-auto mb-12"
            >
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                FAQ
              </span>
              <h2 className="font-display text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-muted-foreground">
                Find answers to common questions about our services.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-8 lg:gap-12 max-w-6xl mx-auto">
              {/* Bus Service FAQs */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
                    <Bus className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <h3 className="font-display text-xl font-bold text-foreground">
                    Bus Service FAQs
                  </h3>
                </div>
                <Accordion type="single" collapsible className="space-y-3">
                  {busFaqs.map((faq, index) => (
                    <AccordionItem
                      key={index}
                      value={`bus-${index}`}
                      className="border border-border rounded-xl px-4 bg-card hover:border-primary/30 transition-colors"
                    >
                      <AccordionTrigger className="text-left text-foreground hover:text-primary py-4">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground pb-4">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </motion.div>

              {/* Garments FAQs */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl gradient-accent flex items-center justify-center">
                    <Package className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <h3 className="font-display text-xl font-bold text-foreground">
                    Garments Product FAQs
                  </h3>
                </div>
                <Accordion type="single" collapsible className="space-y-3">
                  {garmentsFaqs.map((faq, index) => (
                    <AccordionItem
                      key={index}
                      value={`garments-${index}`}
                      className="border border-border rounded-xl px-4 bg-card hover:border-accent/30 transition-colors"
                    >
                      <AccordionTrigger className="text-left text-foreground hover:text-accent py-4">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground pb-4">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </motion.div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-b from-background to-primary/5">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-4">
                Ready to Get Started?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                Contact us today to discuss your requirements and get a customized solution for your business.
              </p>
              <a href="/#contact">
                <Button size="lg" className="gap-2">
                  <Phone className="w-5 h-5" />
                  Contact Us Now
                </Button>
              </a>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ServicesPage;
