import { AppRole } from "@/contexts/AuthContext";

// Define permissions for each module/action
export interface ModulePermissions {
  canView: boolean;
  canCreate: boolean;
  canEdit: boolean;
  canDelete: boolean;
}

// Bus Service Sub-module permissions by role
export const busServicePermissions: Record<string, AppRole[]> = {
  // Bus Categories - Super Admin, Admin and Manager only
  busCategories: ["super_admin", "admin", "manager"],
  // Add Bus - Super Admin, Admin and Manager only
  addBus: ["super_admin", "admin", "manager"],
  // Bus List - All roles can view
  busList: ["super_admin", "admin", "manager", "staff"],
  // Driver List - All roles can view
  driverList: ["super_admin", "admin", "manager", "staff"],
  // Assign Bus - Super Admin, Admin and Manager only
  assignBus: ["super_admin", "admin", "manager"],
  // Daily Service Entry - All roles
  dailyEntry: ["super_admin", "admin", "manager", "staff"],
  // Monthly Summary - Super Admin, Admin and Manager
  monthlySummary: ["super_admin", "admin", "manager"],
  // Billing & Invoice - Super Admin, Admin and Manager
  billing: ["super_admin", "admin", "manager"],
  // Payment Status - Super Admin and Admin only
  paymentStatus: ["super_admin", "admin"],
};

// Main module permissions
export const modulePermissions: Record<string, AppRole[]> = {
  dashboard: ["super_admin", "admin", "manager", "staff"],
  busServices: ["super_admin", "admin", "manager", "staff"],
  garments: ["super_admin", "admin", "manager"],
  clients: ["super_admin", "admin", "manager", "staff"],
  inventory: ["super_admin", "admin", "manager", "staff"],
  sales: ["super_admin", "admin", "manager"],
  staff: ["super_admin", "admin"],
  invoices: ["super_admin", "admin", "manager"],
  reports: ["super_admin", "admin", "manager"],
  website: ["super_admin", "admin"],
  settings: ["super_admin", "admin"],
  userManagement: ["super_admin"], // Only super_admin can manage all users including admins
};

// Website sub-module permissions
export const websitePermissions: Record<string, AppRole[]> = {
  websiteSettings: ["super_admin", "admin"],
  websitePages: ["super_admin", "admin"],
  websiteSliders: ["super_admin", "admin"],
  websiteSections: ["super_admin", "admin"],
  websiteSEO: ["super_admin", "admin"],
};

// Garment sub-module permissions
export const garmentPermissions: Record<string, AppRole[]> = {
  garmentCategories: ["super_admin", "admin", "manager"],
  garmentProducts: ["super_admin", "admin", "manager"],
  garmentPurchases: ["super_admin", "admin", "manager"],
  garmentStock: ["super_admin", "admin", "manager"],
  garmentSales: ["super_admin", "admin", "manager"],
  garmentInvoices: ["super_admin", "admin", "manager"],
  garmentReports: ["super_admin", "admin", "manager"],
};

// Action permissions
// Action permissions
export const actionPermissions: Record<string, Record<string, AppRole[]>> = {
  busServices: {
    create: ["super_admin", "admin", "manager"],
    edit: ["super_admin", "admin", "manager"],
    delete: ["super_admin", "admin"],
    view: ["super_admin", "admin", "manager", "staff"],
  },
  clients: {
    create: ["super_admin", "admin", "manager"],
    edit: ["super_admin", "admin", "manager"],
    delete: ["super_admin", "admin"],
    view: ["super_admin", "admin", "manager", "staff"],
  },
  inventory: {
    create: ["super_admin", "admin", "manager"],
    edit: ["super_admin", "admin", "manager", "staff"],
    delete: ["super_admin", "admin"],
    view: ["super_admin", "admin", "manager", "staff"],
  },
  staff: {
    create: ["super_admin", "admin"],
    edit: ["super_admin", "admin"],
    delete: ["super_admin", "admin"],
    view: ["super_admin", "admin"],
  },
  userManagement: {
    create: ["super_admin"],
    edit: ["super_admin", "admin"], // Super admin can edit all, admin can edit non-admins
    delete: ["super_admin"],
    view: ["super_admin", "admin"],
  },
};

export const usePermissions = (userRole: AppRole | null) => {
  // Super admin always has full access to everything
  const isSuperAdmin = userRole === "super_admin";

  const canAccessModule = (module: string): boolean => {
    if (!userRole) return false;
    if (isSuperAdmin) return true; // Super admin has access to all modules
    const allowedRoles = modulePermissions[module];
    return allowedRoles ? allowedRoles.includes(userRole) : false;
  };

  const canAccessBusSubModule = (subModule: string): boolean => {
    if (!userRole) return false;
    if (isSuperAdmin) return true; // Super admin has access to all sub-modules
    const allowedRoles = busServicePermissions[subModule];
    return allowedRoles ? allowedRoles.includes(userRole) : false;
  };

  const canAccessGarmentSubModule = (subModule: string): boolean => {
    if (!userRole) return false;
    if (isSuperAdmin) return true;
    const allowedRoles = garmentPermissions[subModule];
    return allowedRoles ? allowedRoles.includes(userRole) : false;
  };

  const canAccessWebsiteSubModule = (subModule: string): boolean => {
    if (!userRole) return false;
    if (isSuperAdmin) return true;
    const allowedRoles = websitePermissions[subModule];
    return allowedRoles ? allowedRoles.includes(userRole) : false;
  };

  const canPerformAction = (module: string, action: string): boolean => {
    if (!userRole) return false;
    if (isSuperAdmin) return true; // Super admin can perform all actions
    const moduleActions = actionPermissions[module];
    if (!moduleActions) return false;
    const allowedRoles = moduleActions[action];
    return allowedRoles ? allowedRoles.includes(userRole) : false;
  };

  const getModulePermissions = (module: string): ModulePermissions => {
    if (isSuperAdmin) {
      // Super admin has all permissions
      return {
        canView: true,
        canCreate: true,
        canEdit: true,
        canDelete: true,
      };
    }
    return {
      canView: canPerformAction(module, "view"),
      canCreate: canPerformAction(module, "create"),
      canEdit: canPerformAction(module, "edit"),
      canDelete: canPerformAction(module, "delete"),
    };
  };

  return {
    canAccessModule,
    canAccessBusSubModule,
    canAccessGarmentSubModule,
    canAccessWebsiteSubModule,
    canPerformAction,
    getModulePermissions,
    role: userRole,
    isSuperAdmin,
  };
};
