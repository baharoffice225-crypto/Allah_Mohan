import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import ResetPassword from "./pages/ResetPassword";
import Dashboard from "./pages/Dashboard";
import DashboardHome from "./pages/dashboard/DashboardHome";
import BusServices from "./pages/dashboard/BusServices";
import AddBus from "./pages/dashboard/bus-services/AddBus";
import BusList from "./pages/dashboard/bus-services/BusList";
import DriverList from "./pages/dashboard/bus-services/DriverList";
import AssignBus from "./pages/dashboard/bus-services/AssignBus";
import DailyServiceEntry from "./pages/dashboard/bus-services/DailyServiceEntry";
import MonthlyServiceSummary from "./pages/dashboard/bus-services/MonthlyServiceSummary";
import BillingInvoice from "./pages/dashboard/bus-services/BillingInvoice";
import PaymentStatus from "./pages/dashboard/bus-services/PaymentStatus";
import BusCategories from "./pages/dashboard/bus-services/BusCategories";
import BusProducts from "./pages/dashboard/bus-services/BusProducts";
import ServiceDetail from "./pages/ServiceDetail";
import GarmentCategories from "./pages/dashboard/garments/GarmentCategories";
import GarmentProducts from "./pages/dashboard/garments/GarmentProducts";
import GarmentPurchases from "./pages/dashboard/garments/GarmentPurchases";
import GarmentStock from "./pages/dashboard/garments/GarmentStock";
import GarmentSales from "./pages/dashboard/garments/GarmentSales";
import GarmentInvoices from "./pages/dashboard/garments/GarmentInvoices";
import GarmentReports from "./pages/dashboard/garments/GarmentReports";
import GarmentWebsiteProducts from "./pages/dashboard/garments/GarmentWebsiteProducts";
import GarmentServiceDetail from "./pages/GarmentServiceDetail";
import Clients from "./pages/dashboard/Clients";
import Inventory from "./pages/dashboard/Inventory";
import Sales from "./pages/dashboard/Sales";
import Staff from "./pages/dashboard/Staff";
import UserManagement from "./pages/dashboard/UserManagement";
import AuditLogs from "./pages/dashboard/AuditLogs";
import Invoices from "./pages/dashboard/Invoices";
import Reports from "./pages/dashboard/Reports";
import Settings from "./pages/dashboard/Settings";
import NotFound from "./pages/NotFound";
import ServicesPage from "./pages/ServicesPage";
import Profile from "./pages/dashboard/Profile";
import WebsiteSettings from "./pages/dashboard/website/WebsiteSettings";
import WebsitePages from "./pages/dashboard/website/WebsitePages";
import WebsiteSliders from "./pages/dashboard/website/WebsiteSliders";
import WebsiteSections from "./pages/dashboard/website/WebsiteSections";
import WebsiteSEO from "./pages/dashboard/website/WebsiteSEO";

const queryClient = new QueryClient();

function App() {
  return (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/services/bus/:id" element={<ServiceDetail />} />
            <Route path="/services/garment/:id" element={<GarmentServiceDetail />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            >
              <Route index element={<DashboardHome />} />
              <Route path="bus-services" element={<BusServices />} />
              <Route path="bus-services/categories" element={<BusCategories />} />
              <Route path="bus-services/add" element={<AddBus />} />
              <Route path="bus-services/list" element={<BusList />} />
              <Route path="bus-services/drivers" element={<DriverList />} />
              <Route path="bus-services/assign" element={<AssignBus />} />
              <Route path="bus-services/daily-entry" element={<DailyServiceEntry />} />
              <Route path="bus-services/monthly-summary" element={<MonthlyServiceSummary />} />
              <Route path="bus-services/billing" element={<BillingInvoice />} />
              <Route path="bus-services/payment-status" element={<PaymentStatus />} />
              <Route path="bus-services/products" element={<BusProducts />} />
              <Route path="garments/categories" element={<GarmentCategories />} />
              <Route path="garments/products" element={<GarmentProducts />} />
              <Route path="garments/purchases" element={<GarmentPurchases />} />
              <Route path="garments/stock" element={<GarmentStock />} />
              <Route path="garments/sales" element={<GarmentSales />} />
              <Route path="garments/invoices" element={<GarmentInvoices />} />
              <Route path="garments/reports" element={<GarmentReports />} />
              <Route path="garments/website-products" element={<GarmentWebsiteProducts />} />
              <Route path="clients" element={<Clients />} />
              <Route path="inventory" element={<Inventory />} />
              <Route path="sales" element={<Sales />} />
              <Route path="staff" element={<Staff />} />
              <Route path="user-management" element={<UserManagement />} />
              <Route path="audit-logs" element={<AuditLogs />} />
              <Route path="invoices" element={<Invoices />} />
              <Route path="reports" element={<Reports />} />
              <Route path="profile" element={<Profile />} />
              <Route path="website/settings" element={<WebsiteSettings />} />
              <Route path="website/pages" element={<WebsitePages />} />
              <Route path="website/sliders" element={<WebsiteSliders />} />
              <Route path="website/sections" element={<WebsiteSections />} />
              <Route path="website/seo" element={<WebsiteSEO />} />
              <Route path="settings" element={<Settings />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
  );
}

export default App;
