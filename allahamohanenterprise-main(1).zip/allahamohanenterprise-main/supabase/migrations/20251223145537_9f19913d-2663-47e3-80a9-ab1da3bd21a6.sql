-- Fix drivers table PII exposure - restrict SELECT to admins and managers only
DROP POLICY IF EXISTS "Authenticated users can view drivers" ON public.drivers;

CREATE POLICY "Admins and managers can view drivers"
ON public.drivers
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'super_admin') OR 
  has_role(auth.uid(), 'admin') OR 
  has_role(auth.uid(), 'manager')
);