-- Website Settings Table
CREATE TABLE public.website_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  site_name TEXT DEFAULT 'Business Portal',
  logo_url TEXT,
  favicon_url TEXT,
  primary_color TEXT DEFAULT '#3B82F6',
  secondary_color TEXT DEFAULT '#10B981',
  accent_color TEXT DEFAULT '#F59E0B',
  font_family TEXT DEFAULT 'Inter',
  meta_title TEXT,
  meta_description TEXT,
  meta_keywords TEXT,
  header_text TEXT,
  footer_text TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  contact_address TEXT,
  social_facebook TEXT,
  social_twitter TEXT,
  social_linkedin TEXT,
  social_youtube TEXT,
  social_instagram TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Website Pages Table
CREATE TABLE public.website_pages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  page_slug TEXT UNIQUE NOT NULL,
  page_title TEXT NOT NULL,
  page_description TEXT,
  content JSONB DEFAULT '{}',
  is_visible BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Website Sliders Table
CREATE TABLE public.website_sliders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT,
  subtitle TEXT,
  description TEXT,
  image_url TEXT,
  cta_text TEXT,
  cta_link TEXT,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Website Sections Table
CREATE TABLE public.website_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_key TEXT UNIQUE NOT NULL,
  section_name TEXT NOT NULL,
  is_visible BOOLEAN DEFAULT true,
  content JSONB DEFAULT '{}',
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_sliders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_sections ENABLE ROW LEVEL SECURITY;

-- RLS Policies for website_settings
CREATE POLICY "Anyone can view website settings"
ON public.website_settings FOR SELECT
USING (true);

CREATE POLICY "Super admins and admins can update website settings"
ON public.website_settings FOR UPDATE
USING (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Super admins and admins can insert website settings"
ON public.website_settings FOR INSERT
WITH CHECK (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Only super admins can delete website settings"
ON public.website_settings FOR DELETE
USING (has_role(auth.uid(), 'super_admin'));

-- RLS Policies for website_pages
CREATE POLICY "Anyone can view visible pages"
ON public.website_pages FOR SELECT
USING (is_visible = true OR has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Super admins and admins can insert pages"
ON public.website_pages FOR INSERT
WITH CHECK (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Super admins and admins can update pages"
ON public.website_pages FOR UPDATE
USING (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Only super admins can delete pages"
ON public.website_pages FOR DELETE
USING (has_role(auth.uid(), 'super_admin'));

-- RLS Policies for website_sliders
CREATE POLICY "Anyone can view active sliders"
ON public.website_sliders FOR SELECT
USING (is_active = true OR has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Super admins and admins can insert sliders"
ON public.website_sliders FOR INSERT
WITH CHECK (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Super admins and admins can update sliders"
ON public.website_sliders FOR UPDATE
USING (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Only super admins can delete sliders"
ON public.website_sliders FOR DELETE
USING (has_role(auth.uid(), 'super_admin'));

-- RLS Policies for website_sections
CREATE POLICY "Anyone can view visible sections"
ON public.website_sections FOR SELECT
USING (is_visible = true OR has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Super admins and admins can insert sections"
ON public.website_sections FOR INSERT
WITH CHECK (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Super admins and admins can update sections"
ON public.website_sections FOR UPDATE
USING (has_role(auth.uid(), 'super_admin') OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Only super admins can delete sections"
ON public.website_sections FOR DELETE
USING (has_role(auth.uid(), 'super_admin'));

-- Triggers for updated_at
CREATE TRIGGER update_website_settings_updated_at
BEFORE UPDATE ON public.website_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_website_pages_updated_at
BEFORE UPDATE ON public.website_pages
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_website_sliders_updated_at
BEFORE UPDATE ON public.website_sliders
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_website_sections_updated_at
BEFORE UPDATE ON public.website_sections
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default website settings
INSERT INTO public.website_settings (site_name, meta_title, meta_description) 
VALUES ('Business Portal', 'Business Portal - Bus & Garments Services', 'Professional bus transportation and garments product services');

-- Insert default sections
INSERT INTO public.website_sections (section_key, section_name, is_visible, display_order) VALUES
('hero', 'Hero Section', true, 1),
('services', 'Services Section', true, 2),
('about', 'About Section', true, 3),
('testimonials', 'Testimonials Section', true, 4),
('contact', 'Contact Section', true, 5),
('footer', 'Footer Section', true, 6);

-- Insert default pages
INSERT INTO public.website_pages (page_slug, page_title, is_visible, display_order) VALUES
('home', 'Home', true, 1),
('about', 'About Us', true, 2),
('services', 'Services', true, 3),
('contact', 'Contact', true, 4);