-- Drop the overly permissive audit log insert policy
DROP POLICY IF EXISTS "Authenticated users can insert audit logs" ON public.audit_logs;

-- Create a more restrictive insert policy - only allow via triggers (service role)
-- Users cannot directly insert audit logs; only database triggers can
CREATE POLICY "Only system can insert audit logs"
ON public.audit_logs
FOR INSERT
WITH CHECK (false);

-- Note: The existing trigger log_role_change() uses SECURITY DEFINER 
-- which bypasses RLS and can still insert audit logs