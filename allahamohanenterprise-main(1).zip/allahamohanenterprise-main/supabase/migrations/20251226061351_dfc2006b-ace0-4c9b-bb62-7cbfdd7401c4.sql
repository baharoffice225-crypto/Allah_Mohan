-- Fix email privacy: Tighten the profiles RLS policy
-- Remove the overly permissive "Admins and managers can view all profiles" policy
-- This forces admins/managers to use the secure get_profiles_for_management() function which masks emails

DROP POLICY IF EXISTS "Admins and managers can view all profiles" ON public.profiles;

-- Create a more restrictive policy - only super_admin can view all profiles directly
-- Regular admins and managers must use the get_profiles_for_management() function
CREATE POLICY "Super admins can view all profiles directly"
ON public.profiles FOR SELECT
USING (public.is_super_admin(auth.uid()));

-- The existing "Users can view their own profile" policy remains unchanged
-- allowing users to see their own data