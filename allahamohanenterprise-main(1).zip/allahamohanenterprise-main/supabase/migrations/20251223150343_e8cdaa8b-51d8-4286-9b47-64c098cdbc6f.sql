-- Make the driver-photos bucket private
UPDATE storage.buckets 
SET public = false 
WHERE id = 'driver-photos';