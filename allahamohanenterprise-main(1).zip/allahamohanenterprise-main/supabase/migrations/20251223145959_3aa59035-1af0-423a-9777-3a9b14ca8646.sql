-- Create function to get drivers with role-based field masking
CREATE OR REPLACE FUNCTION public.get_drivers_safe()
RETURNS TABLE (
  id uuid,
  name text,
  phone text,
  license_number text,
  address text,
  photo_url text,
  status text,
  created_at timestamptz,
  updated_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Super admins and admins see everything
  IF public.is_super_admin(auth.uid()) OR public.has_role(auth.uid(), 'admin') THEN
    RETURN QUERY SELECT d.id, d.name, d.phone, d.license_number, d.address, d.photo_url, d.status, d.created_at, d.updated_at
    FROM public.drivers d
    ORDER BY d.created_at DESC;
  -- Managers see masked sensitive data
  ELSIF public.has_role(auth.uid(), 'manager') THEN
    RETURN QUERY SELECT d.id, d.name, 
      CASE WHEN d.phone IS NOT NULL THEN '●●●●●●●●●●' ELSE NULL END,
      CASE WHEN d.license_number IS NOT NULL THEN '●●●●●●●●●●' ELSE NULL END,
      CASE WHEN d.address IS NOT NULL THEN '●●●●●●●●●●' ELSE NULL END,
      d.photo_url, d.status, d.created_at, d.updated_at
    FROM public.drivers d
    ORDER BY d.created_at DESC;
  END IF;
END;
$$;

-- Create function to get profiles with role-based field masking for user management
CREATE OR REPLACE FUNCTION public.get_profiles_for_management()
RETURNS TABLE (
  id uuid,
  email text,
  full_name text,
  avatar_url text,
  created_at timestamptz,
  updated_at timestamptz,
  role app_role
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Super admins see everything
  IF public.is_super_admin(auth.uid()) THEN
    RETURN QUERY SELECT p.id, p.email, p.full_name, p.avatar_url, p.created_at, p.updated_at, ur.role
    FROM public.profiles p
    LEFT JOIN public.user_roles ur ON p.id = ur.user_id
    ORDER BY p.created_at DESC;
  -- Admins see masked emails for non-self users
  ELSIF public.has_role(auth.uid(), 'admin') THEN
    RETURN QUERY SELECT p.id, 
      CASE WHEN p.id = auth.uid() THEN p.email ELSE 
        CONCAT(LEFT(SPLIT_PART(p.email, '@', 1), 2), '●●●@', SPLIT_PART(p.email, '@', 2))
      END,
      p.full_name, p.avatar_url, p.created_at, p.updated_at, ur.role
    FROM public.profiles p
    LEFT JOIN public.user_roles ur ON p.id = ur.user_id
    ORDER BY p.created_at DESC;
  END IF;
END;
$$;