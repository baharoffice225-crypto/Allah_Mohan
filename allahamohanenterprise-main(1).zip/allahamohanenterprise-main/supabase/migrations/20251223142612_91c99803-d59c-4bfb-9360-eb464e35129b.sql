-- Drop existing restrictive policies and recreate as permissive
DROP POLICY IF EXISTS "Super admins, admins and managers can update categories" ON public.bus_categories;

-- Create permissive UPDATE policy
CREATE POLICY "Super admins, admins and managers can update categories"
ON public.bus_categories
FOR UPDATE
TO authenticated
USING (
  public.has_role(auth.uid(), 'super_admin') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'manager')
)
WITH CHECK (
  public.has_role(auth.uid(), 'super_admin') OR 
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'manager')
);