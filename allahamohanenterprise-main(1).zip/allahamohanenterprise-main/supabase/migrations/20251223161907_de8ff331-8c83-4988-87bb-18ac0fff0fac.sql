-- Create garment_categories table
CREATE TABLE public.garment_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create garment_products table
CREATE TABLE public.garment_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID NOT NULL REFERENCES public.garment_categories(id) ON DELETE RESTRICT,
  name TEXT NOT NULL,
  sku TEXT,
  description TEXT,
  unit TEXT NOT NULL DEFAULT 'pcs',
  price NUMERIC NOT NULL DEFAULT 0,
  cost_price NUMERIC NOT NULL DEFAULT 0,
  stock NUMERIC NOT NULL DEFAULT 0,
  min_stock NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create garment_purchases table (purchases from garments factories)
CREATE TABLE public.garment_purchases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  purchase_number TEXT NOT NULL UNIQUE,
  supplier_name TEXT NOT NULL,
  supplier_contact TEXT,
  purchase_date DATE NOT NULL DEFAULT CURRENT_DATE,
  total_amount NUMERIC NOT NULL DEFAULT 0,
  paid_amount NUMERIC NOT NULL DEFAULT 0,
  payment_status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create garment_purchase_items table
CREATE TABLE public.garment_purchase_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  purchase_id UUID NOT NULL REFERENCES public.garment_purchases(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.garment_products(id) ON DELETE RESTRICT,
  quantity NUMERIC NOT NULL,
  unit_price NUMERIC NOT NULL,
  total_price NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create garment_sales table (sales to local market customers)
CREATE TABLE public.garment_sales (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  invoice_number TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_contact TEXT,
  customer_address TEXT,
  sale_date DATE NOT NULL DEFAULT CURRENT_DATE,
  subtotal NUMERIC NOT NULL DEFAULT 0,
  discount NUMERIC NOT NULL DEFAULT 0,
  total_amount NUMERIC NOT NULL DEFAULT 0,
  paid_amount NUMERIC NOT NULL DEFAULT 0,
  payment_status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create garment_sale_items table
CREATE TABLE public.garment_sale_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sale_id UUID NOT NULL REFERENCES public.garment_sales(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.garment_products(id) ON DELETE RESTRICT,
  quantity NUMERIC NOT NULL,
  unit_price NUMERIC NOT NULL,
  total_price NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create garment_stock_transactions table for stock movement tracking
CREATE TABLE public.garment_stock_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.garment_products(id) ON DELETE CASCADE,
  type TEXT NOT NULL, -- 'purchase_in', 'sale_out', 'adjustment_in', 'adjustment_out'
  reference_type TEXT, -- 'purchase', 'sale', 'adjustment'
  reference_id UUID,
  quantity NUMERIC NOT NULL,
  previous_stock NUMERIC NOT NULL,
  new_stock NUMERIC NOT NULL,
  notes TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.garment_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.garment_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.garment_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.garment_purchase_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.garment_sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.garment_sale_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.garment_stock_transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for garment_categories
CREATE POLICY "Authenticated users can view categories" ON public.garment_categories
  FOR SELECT USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager') OR 
    has_role(auth.uid(), 'staff')
  );

CREATE POLICY "Admins and managers can insert categories" ON public.garment_categories
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Admins and managers can update categories" ON public.garment_categories
  FOR UPDATE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Only admins can delete categories" ON public.garment_categories
  FOR DELETE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin')
  );

-- RLS Policies for garment_products
CREATE POLICY "Authenticated users can view products" ON public.garment_products
  FOR SELECT USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager') OR 
    has_role(auth.uid(), 'staff')
  );

CREATE POLICY "Admins and managers can insert products" ON public.garment_products
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Admins and managers can update products" ON public.garment_products
  FOR UPDATE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Only admins can delete products" ON public.garment_products
  FOR DELETE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin')
  );

-- RLS Policies for garment_purchases
CREATE POLICY "Authenticated users can view purchases" ON public.garment_purchases
  FOR SELECT USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager') OR 
    has_role(auth.uid(), 'staff')
  );

CREATE POLICY "Admins and managers can insert purchases" ON public.garment_purchases
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Admins and managers can update purchases" ON public.garment_purchases
  FOR UPDATE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Only admins can delete purchases" ON public.garment_purchases
  FOR DELETE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin')
  );

-- RLS Policies for garment_purchase_items
CREATE POLICY "Authenticated users can view purchase items" ON public.garment_purchase_items
  FOR SELECT USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager') OR 
    has_role(auth.uid(), 'staff')
  );

CREATE POLICY "Admins and managers can insert purchase items" ON public.garment_purchase_items
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Admins and managers can update purchase items" ON public.garment_purchase_items
  FOR UPDATE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Only admins can delete purchase items" ON public.garment_purchase_items
  FOR DELETE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin')
  );

-- RLS Policies for garment_sales
CREATE POLICY "Authenticated users can view sales" ON public.garment_sales
  FOR SELECT USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager') OR 
    has_role(auth.uid(), 'staff')
  );

CREATE POLICY "Admins and managers can insert sales" ON public.garment_sales
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Admins and managers can update sales" ON public.garment_sales
  FOR UPDATE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Only admins can delete sales" ON public.garment_sales
  FOR DELETE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin')
  );

-- RLS Policies for garment_sale_items
CREATE POLICY "Authenticated users can view sale items" ON public.garment_sale_items
  FOR SELECT USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager') OR 
    has_role(auth.uid(), 'staff')
  );

CREATE POLICY "Admins and managers can insert sale items" ON public.garment_sale_items
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Admins and managers can update sale items" ON public.garment_sale_items
  FOR UPDATE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Only admins can delete sale items" ON public.garment_sale_items
  FOR DELETE USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin')
  );

-- RLS Policies for garment_stock_transactions
CREATE POLICY "Authenticated users can view stock transactions" ON public.garment_stock_transactions
  FOR SELECT USING (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager') OR 
    has_role(auth.uid(), 'staff')
  );

CREATE POLICY "Admins and managers can insert stock transactions" ON public.garment_stock_transactions
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'super_admin') OR 
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'manager')
  );

-- Create updated_at triggers
CREATE TRIGGER update_garment_categories_updated_at
  BEFORE UPDATE ON public.garment_categories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_garment_products_updated_at
  BEFORE UPDATE ON public.garment_products
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_garment_purchases_updated_at
  BEFORE UPDATE ON public.garment_purchases
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_garment_sales_updated_at
  BEFORE UPDATE ON public.garment_sales
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to auto-generate purchase number
CREATE OR REPLACE FUNCTION public.generate_purchase_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.purchase_number IS NULL OR NEW.purchase_number = '' THEN
    NEW.purchase_number := 'PUR-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(NEXTVAL('purchase_number_seq')::TEXT, 4, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create sequence for purchase numbers
CREATE SEQUENCE IF NOT EXISTS purchase_number_seq START 1;

CREATE TRIGGER set_purchase_number
  BEFORE INSERT ON public.garment_purchases
  FOR EACH ROW EXECUTE FUNCTION public.generate_purchase_number();

-- Create function to auto-generate invoice number
CREATE OR REPLACE FUNCTION public.generate_invoice_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.invoice_number IS NULL OR NEW.invoice_number = '' THEN
    NEW.invoice_number := 'INV-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(NEXTVAL('invoice_number_seq')::TEXT, 4, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create sequence for invoice numbers
CREATE SEQUENCE IF NOT EXISTS invoice_number_seq START 1;

CREATE TRIGGER set_invoice_number
  BEFORE INSERT ON public.garment_sales
  FOR EACH ROW EXECUTE FUNCTION public.generate_invoice_number();