-- Make driver-photos bucket private and restrict access to authenticated staff only

-- Update bucket to be private
UPDATE storage.buckets 
SET public = false 
WHERE id = 'driver-photos';

-- Drop the overly permissive public view policy
DROP POLICY IF EXISTS "Anyone can view driver photos" ON storage.objects;

-- Create restricted view policy for authenticated staff only
CREATE POLICY "Authenticated staff can view driver photos"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'driver-photos' AND
  auth.uid() IS NOT NULL AND
  (public.has_role(auth.uid(), 'super_admin') OR 
   public.has_role(auth.uid(), 'admin') OR 
   public.has_role(auth.uid(), 'manager') OR
   public.has_role(auth.uid(), 'staff'))
);