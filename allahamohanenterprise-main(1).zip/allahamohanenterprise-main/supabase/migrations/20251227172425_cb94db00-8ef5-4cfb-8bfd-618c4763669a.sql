-- Create garment_website_products table for service/product management on website
CREATE TABLE public.garment_website_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  short_description TEXT,
  features TEXT[] DEFAULT '{}',
  specifications JSONB DEFAULT '{}',
  price NUMERIC DEFAULT 0,
  price_unit TEXT DEFAULT 'per kg',
  category TEXT DEFAULT 'yarn',
  image_url TEXT,
  gallery_images TEXT[] DEFAULT '{}',
  is_featured BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.garment_website_products ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view active garment website products"
ON public.garment_website_products
FOR SELECT
USING (is_active = true OR has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'manager'::app_role));

CREATE POLICY "Admins and managers can insert garment website products"
ON public.garment_website_products
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'manager'::app_role));

CREATE POLICY "Admins and managers can update garment website products"
ON public.garment_website_products
FOR UPDATE
USING (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'manager'::app_role));

CREATE POLICY "Only admins can delete garment website products"
ON public.garment_website_products
FOR DELETE
USING (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role));

-- Update trigger
CREATE TRIGGER update_garment_website_products_updated_at
BEFORE UPDATE ON public.garment_website_products
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for product images
INSERT INTO storage.buckets (id, name, public) VALUES ('product-images', 'product-images', true);

-- Storage policies for product images
CREATE POLICY "Anyone can view product images"
ON storage.objects FOR SELECT
USING (bucket_id = 'product-images');

CREATE POLICY "Authenticated users can upload product images"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'product-images' AND auth.role() = 'authenticated');

CREATE POLICY "Authenticated users can update product images"
ON storage.objects FOR UPDATE
USING (bucket_id = 'product-images' AND auth.role() = 'authenticated');

CREATE POLICY "Admins can delete product images"
ON storage.objects FOR DELETE
USING (bucket_id = 'product-images' AND auth.role() = 'authenticated');

-- Insert sample garment website products
INSERT INTO public.garment_website_products (name, short_description, description, features, specifications, price, price_unit, category, is_featured, display_order) VALUES
('Premium Cotton Yarn', 'High-quality cotton yarn for textile manufacturing', 'Our Premium Cotton Yarn is sourced directly from leading factories. Perfect for garment manufacturing, knitting, and textile production with consistent quality and strength.',
ARRAY['100% pure cotton', 'High tensile strength', 'Color consistency', 'Factory direct pricing', 'Bulk availability'],
'{"count": "30/1 to 60/1", "composition": "100% Cotton", "twist": "TM 3.5-4.5", "strength": "High"}',
280, 'per kg', 'yarn', true, 1),

('Mixed Blend Yarn', 'Cotton-polyester blend for durability', 'Cost-effective blended yarn combining the comfort of cotton with the durability of polyester. Ideal for everyday garments and industrial textiles.',
ARRAY['Cotton-poly blend', 'Wrinkle resistant', 'Cost effective', 'Easy dyeing', 'High durability'],
'{"count": "20/1 to 40/1", "composition": "65% Cotton, 35% Polyester", "twist": "TM 3.0-4.0", "strength": "Very High"}',
220, 'per kg', 'yarn', false, 2),

('Metal Buttons Collection', 'Premium metal buttons for fashion garments', 'Wide variety of metal buttons in different sizes, finishes, and designs. Perfect for jeans, jackets, and premium fashion wear.',
ARRAY['Multiple finishes', 'Various sizes', 'Custom logo option', 'Bulk discounts', 'Quality tested'],
'{"sizes": "10mm to 25mm", "finishes": "Brass, Antique, Nickel, Gold", "moq": "1000 pcs", "lead_time": "7-10 days"}',
8, 'per piece', 'buttons', false, 3),

('Quality Jhut (Fabric Waste)', 'Clean fabric waste for recycling and stuffing', 'Sorted and cleaned fabric waste from garment factories. Available in cotton, polyester, and mixed varieties. Ideal for recycling, stuffing, and industrial use.',
ARRAY['Sorted by type', 'Clean and dry', 'Regular supply', 'Competitive rates', 'Bulk available'],
'{"types": "Cotton, Polyester, Mixed", "packing": "Bale 80-100kg", "source": "Garment factories", "use": "Recycling, Stuffing, Industrial"}',
45, 'per kg', 'jhut', false, 4);