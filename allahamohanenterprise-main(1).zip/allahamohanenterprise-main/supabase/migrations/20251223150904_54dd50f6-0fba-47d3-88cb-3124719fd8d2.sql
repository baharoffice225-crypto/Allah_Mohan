-- Add DELETE policy for chat_messages so users can remove their own messages
CREATE POLICY "Users can delete messages from their conversations"
ON public.chat_messages
FOR DELETE
USING (
  EXISTS (
    SELECT 1
    FROM chat_conversations
    WHERE chat_conversations.id = chat_messages.conversation_id
    AND chat_conversations.user_id = auth.uid()
  )
);