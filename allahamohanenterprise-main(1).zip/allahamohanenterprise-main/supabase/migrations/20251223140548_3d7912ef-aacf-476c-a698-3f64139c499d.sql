-- Drop existing restrictive policies for bus_categories
DROP POLICY IF EXISTS "Admins and managers can insert categories" ON public.bus_categories;
DROP POLICY IF EXISTS "Admins and managers can update categories" ON public.bus_categories;
DROP POLICY IF EXISTS "Admins can delete categories" ON public.bus_categories;

-- Create new policies that include super_admin
CREATE POLICY "Super admins, admins and managers can insert categories"
ON public.bus_categories
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'super_admin'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'manager'::app_role)
);

CREATE POLICY "Super admins, admins and managers can update categories"
ON public.bus_categories
FOR UPDATE
TO authenticated
USING (
  has_role(auth.uid(), 'super_admin'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'manager'::app_role)
);

CREATE POLICY "Super admins and admins can delete categories"
ON public.bus_categories
FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'super_admin'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role)
);

-- Also fix bus table policies
DROP POLICY IF EXISTS "Admins and managers can insert buses" ON public.buses;
DROP POLICY IF EXISTS "Admins and managers can update buses" ON public.buses;
DROP POLICY IF EXISTS "Admins can delete buses" ON public.buses;

CREATE POLICY "Super admins, admins and managers can insert buses"
ON public.buses
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'super_admin'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'manager'::app_role)
);

CREATE POLICY "Super admins, admins and managers can update buses"
ON public.buses
FOR UPDATE
TO authenticated
USING (
  has_role(auth.uid(), 'super_admin'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'manager'::app_role)
);

CREATE POLICY "Super admins and admins can delete buses"
ON public.buses
FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'super_admin'::app_role) OR 
  has_role(auth.uid(), 'admin'::app_role)
);