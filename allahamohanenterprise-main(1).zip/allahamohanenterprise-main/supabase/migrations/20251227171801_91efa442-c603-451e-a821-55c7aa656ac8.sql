-- Create bus_products table for service/product management
CREATE TABLE public.bus_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  short_description TEXT,
  features TEXT[] DEFAULT '{}',
  specifications JSONB DEFAULT '{}',
  price NUMERIC DEFAULT 0,
  price_unit TEXT DEFAULT 'per trip',
  category TEXT DEFAULT 'standard',
  image_url TEXT,
  gallery_images TEXT[] DEFAULT '{}',
  is_featured BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.bus_products ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view active bus products"
ON public.bus_products
FOR SELECT
USING (is_active = true OR has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'manager'::app_role));

CREATE POLICY "Admins and managers can insert bus products"
ON public.bus_products
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'manager'::app_role));

CREATE POLICY "Admins and managers can update bus products"
ON public.bus_products
FOR UPDATE
USING (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'manager'::app_role));

CREATE POLICY "Only admins can delete bus products"
ON public.bus_products
FOR DELETE
USING (has_role(auth.uid(), 'super_admin'::app_role) OR has_role(auth.uid(), 'admin'::app_role));

-- Update trigger
CREATE TRIGGER update_bus_products_updated_at
BEFORE UPDATE ON public.bus_products
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample data
INSERT INTO public.bus_products (name, short_description, description, features, specifications, price, price_unit, category, is_featured, display_order) VALUES
('Standard Bus Service', 'Reliable daily transportation for corporate teams', 'Our Standard Bus Service provides comfortable and reliable transportation for corporate employees. Ideal for daily commutes and regular office transportation needs.', 
ARRAY['Air-conditioned buses', 'GPS tracking', 'Professional drivers', 'Flexible scheduling', 'Door-to-door pickup'],
'{"capacity": "40-50 passengers", "ac_type": "Central AC", "seats": "Push-back seats", "amenities": "WiFi, USB charging"}',
15000, 'per month', 'standard', false, 1),

('Premium Bus Service', 'Executive-class transportation with premium amenities', 'Experience luxury travel with our Premium Bus Service. Features executive seating, premium amenities, and dedicated support for your transportation needs.',
ARRAY['Executive seating', 'Onboard WiFi', 'USB charging ports', 'Entertainment system', 'Refreshments included', 'Priority support'],
'{"capacity": "25-30 passengers", "ac_type": "Dual zone AC", "seats": "Leather recliners", "amenities": "WiFi, TV, Mini fridge"}',
35000, 'per month', 'premium', true, 2),

('Event & Tour Bus', 'Specialized buses for events, tours, and special occasions', 'Perfect for corporate events, team outings, and special occasions. Our Event buses come with customizable interiors and professional event support.',
ARRAY['Customizable interiors', 'PA system', 'Large luggage space', 'Tour guide support', 'Flexible routes', 'Event coordination'],
'{"capacity": "45-55 passengers", "ac_type": "Central AC", "seats": "Comfortable touring seats", "amenities": "Microphone, Speakers, Large windows"}',
8000, 'per day', 'event', false, 3),

('Shuttle Service', 'Compact shuttle for small teams and regular routes', 'Efficient shuttle service for smaller teams. Perfect for office-to-office transfers, airport pickups, and short-distance regular routes.',
ARRAY['Compact and efficient', 'Regular schedules', 'Multiple stops', 'Cost-effective', 'Quick boarding'],
'{"capacity": "12-18 passengers", "ac_type": "AC", "seats": "Standard", "amenities": "AC, Clean interior"}',
8000, 'per month', 'shuttle', false, 4);