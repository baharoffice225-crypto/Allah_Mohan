-- Add photo_url column to drivers table
ALTER TABLE public.drivers ADD COLUMN photo_url TEXT;

-- Create storage bucket for driver photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('driver-photos', 'driver-photos', true);

-- Storage policies for driver photos
CREATE POLICY "Anyone can view driver photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'driver-photos');

CREATE POLICY "Authenticated users can upload driver photos"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'driver-photos' AND
  auth.uid() IS NOT NULL
);

CREATE POLICY "Admins and managers can update driver photos"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'driver-photos' AND
  (has_role(auth.uid(), 'super_admin') OR 
   has_role(auth.uid(), 'admin') OR 
   has_role(auth.uid(), 'manager'))
);

CREATE POLICY "Admins can delete driver photos"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'driver-photos' AND
  (has_role(auth.uid(), 'super_admin') OR 
   has_role(auth.uid(), 'admin'))
);